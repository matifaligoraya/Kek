/**
 * cwpfTabs v1.0.0
 */


var global_cwpf_tabs = false;

;
(function ($, window) {

    'use strict';

    $.fn.cwpfTabs = function (options) {

	if (!this.length)
	    return;

	return this.each(function () {

	    var $this = $(this);

	    ({
		init: function () {
		    this.tabsNav = $this.children('nav');
		    this.items = $this.children('.content-wrap').children('section');
		    this._show();
		    this._initEvents();
		},
		_initEvents: function () {
		    var self = this;
		    this.tabsNav.on('click', 'a', function (e) {
			e.preventDefault();
			self._show($(this));
		    });
		},
		_show: function (element) {

		    if (element == undefined) {
			this.firsTab = this.tabsNav.find('li').first();
			this.firstSection = this.items.first();

			if (!this.firsTab.hasClass('tab-current')) {
			    this.firsTab.addClass('tab-current');
			}

			if (!this.firstSection.hasClass('content-current')) {
			    this.firstSection.addClass('content-current');
			}
		    }

		    var $this = $(element),
			    $to = $($this.attr('href'));

		    if ($to.length) {
			$this.parent('li').siblings().removeClass().end().addClass('tab-current');
			$to.siblings().removeClass().end().addClass('content-current');
		    }

		}

	    }).init();

	});
    };

})(jQuery, window);


/*	Popup
 /* --------------------------------------------- */

/**
 * cwpfPopupPrepare v1.0.0
 */
(function ($) {

    $.cwpf_popup_prepare = function (el, options) {
	this.el = el;
	this.options = $.extend({}, $.cwpf_popup_prepare.DEFAULTS, options);
	this.init();
    };

    $.cwpf_popup_prepare.DEFAULTS = {};
    $.cwpf_popup_prepare.openInstance = [];

    $.cwpf_popup_prepare.prototype = {
	init: function () {

	    $.cwpf_popup_prepare.openInstance.unshift(this);

	    var base = this;
	    base.scope = false;
	    base.body = $('body');
	    base.wrap = $('#wpwrap');
	    base.modal = $('<div class="cwpf-modal cwpf-style"></div>');
	    base.overlay = $('<div class="cwpf-modal-backdrop"></div>');
	    base.container = $('.cwpf-tabs');
	    base.instance = $.cwpf_popup_prepare.openInstance.length;
	    base.namespace = '.popup_modal_' + base.instance;

	    base.support = {
		touch: Modernizr.touch
	    };
	   // base.eventtype = base.support.touch ? 'touchstart' : 'click';
            base.eventtype='click';
	    base.loadPopup();
	},
	loadPopup: function () {
	    this.container.on(this.eventtype, this.el, $.proxy(function (e) {
		if (!this.scope) {
		    this.body.addClass('cwpf-noscroll');
		    this.openPopup(e);
		}
		this.scope = true;
	    }, this));
	},
	openPopup: function (e) {
	    e.preventDefault();

	    var base = this,
		    el = $(e.target),
		    data = el.data();

	    if (el.hasClass('js_cwpf_options')) {
		//for 'by-' items
		var key = data['key'],
			name = data['name'] + ' [' + data['key'] + ']',
			type = false,
			info = $("#cwpf-modal-content-" + key),
			content = info.html();
	    } else {
		//for taxonomies
		var type = el.parent().find('.cwpf_select_tax_type').val();
		var key = data['taxonomy'];
		var name = data['taxonomyName'] + ' [' + key + ']';
		var info = $("#cwpf-modal-content");
		info.find('.cwpf_option_container').hide();
		info.find('.cwpf_option_all').show();
		info.find('.cwpf_option_' + type).show();
		var content = info.html();
	    }

	    base.create_html(key, name, content, info, type);
	    base.add_behavior(key, name, content, info, type);
	},
	create_html: function (key, name, content, info, type) {

	    var base = this,
		    title = name ? '<h3 class="cwpf-modal-title"> ' + name + '</h3>' : '',
		    loading = ' preloading ',
		    output = '<div class="cwpf-modal-inner">';
	    output += '<div class="cwpf-modal-inner-header">' + title + '<a href="javascript:void(0)" class="cwpf-modal-close"></a></div>';
	    output += '<div class="cwpf-modal-inner-content ' + loading + '">' + content + '</div>';
	    output += '<div class="cwpf-modal-inner-footer">';
	    output += '<a href="javascript:void(0)" class="cwpf-modal-save button button-primary button-large">Apply</a>';
	    output += '</div>';
	    output += '</div>';

	    base.wrap.append(base.modal).append(base.overlay);
	    base.modal.html(output);
	    base.modal.find('.cwpf-modal-inner-content').removeClass('preloading');

	    var multiplier = base.instance - 1,
		    old = parseInt(base.modal.css('zIndex'), 10);
	    base.modal.css({margin: (30 * multiplier), zIndex: (old + multiplier + 1)});
	    base.overlay.css({zIndex: (old + multiplier)});

	    base.on_load_callback(key, name, content, info, type);
	},
	closeModal: function () {
	    var base = this;

	    $.cwpf_popup_prepare.openInstance.shift();

	    base.modal.remove();
	    base.overlay.remove();

	    base.body.removeClass('cwpf-noscroll');
	    base.scope = false;
	},
	add_behavior: function (key, name, content, info, type) {
	    var base = this;

	    base.modal.on(base.eventtype + base.namespace, '.cwpf-modal-save', function (e) {
		e.preventDefault();
		base.on_close_callback(key, name, content, info, type);
		base.closeModal();
	    });
             $(document).keydown(function(e) {
                // ESCAPE key pressed
                if (e.keyCode == 27) {
                    base.closeModal();
                }
            });

	    base.modal.on(base.eventtype + base.namespace, '.cwpf-modal-close', function (e) {
                console.log(key);
		e.preventDefault();
		base.closeModal();
	    });

	    base.overlay.on(base.eventtype + base.namespace, function (e) {
		e.preventDefault();
		base.closeModal();
	    });

	},
	on_load_callback: function (key, name, content, info, type) {

	    if (type) {

		info.find('.cwpf_option_container').hide();
		info.find('.cwpf_option_all').show();
		info.find('.cwpf_option_' + type).show();

		$.each($('.cwpf_popup_option', this.modal), function () {
		    var option = $(this).data('option'),
			    val = $('input[name="cwpf_settings[' + option + '][' + key + ']"]').val();
		    $(this).val(val);
		});

	    } else {

		$.each($('.cwpf_popup_option', this.modal), function () {
		    var option = $(this).data('option'),
			    val = $('input[name="cwpf_settings[' + key + '][' + option + ']"]').val();
		    $(this).val(val);
		});

	    }

	},
	on_close_callback: function (key, name, content, info, type) {

	    if (type) {

		$.each($('.cwpf_popup_option', this.modal), function () {
		    var option = $(this).data('option'), val = $(this).val();
		    $('input[name="cwpf_settings[' + option + '][' + key + ']"]').val(val);
		});

	    } else {

		$.each($('.cwpf_popup_option', this.modal), function () {
		    var option = $(this).data('option'), val = $(this).val();
		    $('input[name="cwpf_settings[' + key + '][' + option + ']"]').val(val);
		});

	    }

	}
    };

})(jQuery);

/*	Expand
 /* --------------------------------------------- */

/**
 * cwpfExpandPrepare v1.0.0
 */
(function ($) {

  $.cwpf_expand_prepare = function (el, options) {
    this.el = el;
    this.options = $.extend({}, $.cwpf_expand_prepare.DEFAULTS, options);
    this.init();
  };
  $.cwpf_expand_prepare.DEFAULTS = {};
  $.cwpf_expand_prepare.openInstance = [];
  $.cwpf_expand_prepare.prototype = {
    init: function () {
      $.cwpf_expand_prepare.openInstance.unshift(this);
      var base = this;

      base.scope = false;
      base.container = $('.cwpf-tabs');

      base.support = {
        touch: Modernizr.touch
      };
      base.eventtype='click';
      base.loadExpand();
    },
    loadExpand: function () {
      this.container.on(this.eventtype, this.el, $.proxy(function (e) {
        var el = $(e.target),
            key = el.data()['key'];
        if (!this.scope) {
    		    this.openExpand(e);
        		this.scope = el.data()['key'];
            global_cwpf_tabs = this.scope;
    		} else if (this.scope == key) {
            this.closeExpand(e);
            this.scope = false;
            global_cwpf_tabs = this.scope;
        } else {
            this.closeExpand(e, this.scope);
        		this.openExpand(e);
        		this.scope = el.data()['key'];
            global_cwpf_tabs = this.scope;
        }
      }, this));
  	},
    openExpand: function (e) {
	    e.preventDefault();
      var base = this,
        el = $(e.target),
        data = el.data(),
        key = data['key'];
      if (el.hasClass('js_cwpf_expand_add_options')) {
  		  var type = el.parent().find('.cwpf_select_tax_type').val();
      } else {
        var type = false;
      }
      info = $("#cwpf-modal-content-" + key);
      if (type) {
    		info.find('.cwpf_option_all').show();
    		info.find('.cwpf_option_' + type).show();
      }
      info.show(250);
      el.addClass('cwpf-active');
      base.on_load_callback(key, type, info);
    },
    closeExpand: function (e, close_key = false) {
	    e.preventDefault();
      var base = this,
        el = $(e.target),
        data = el.data(),
        key = data['key'],
        type = false;
      if (!close_key) {
        info = $("#cwpf-modal-content-" + key);
      } else {
        el = $('.js_cwpf_expand_options_' + close_key);
        info = $("#cwpf-modal-content-" + close_key);
        key = close_key;
      }
      if (el.hasClass('js_cwpf_expand_add_options')) {
        var type = el.parent().find('.cwpf_select_tax_type').val();
      } else {
        var type = false;
      }
      info.hide(250);
      el.removeClass('cwpf-active');
      base.on_close_callback(key, type, info);
    },
  	on_load_callback: function (key, type, info) {
      if (type) {
        info.find('.cwpf_option_all').show();
        info.find('.cwpf_option_' + type).show();
        $.each($('#cwpf-modal-content-' + key + ' .cwpf_popup_option'), function () {
          var option = $(this).data('option'),
          val = $('input[name="cwpf_settings[' + option + '][' + key + ']"]').val();
          $(this).val(val);
        });
      } else {
          $.each($('#cwpf-modal-content-' + key + ' .cwpf_popup_option'), function () {
          var option = $(this).data('option'),
          val = $('input[name="cwpf_settings[' + key + '][' + option + ']"]').val();
          $(this).val(val);
        });
      }
    },
  	on_close_callback: function (key, type, info) {
      if (type) {
        $.each($('#cwpf-modal-content-' + key + ' .cwpf_popup_option'), function () {
          var option = $(this).data('option'), val = $(this).val();
          $('.cwpf-additional-options-' + key + ' input[name="cwpf_settings[' + option + '][' + key + ']"]').attr('value', val);
        });
      } else {
        $.each($('#cwpf-modal-content-' + key + ' .cwpf_popup_option'), function () {
          var option = $(this).data('option'), val = $(this).val();
          $('input[name="cwpf_settings[' + key + '][' + option + ']"]').val(val);
        });
      }
    },
    add_behavior: function (key, name, content, info, type, base) {
    }
  };

})(jQuery);

var cwpf_sort_order = [];

(function ($) {


    jQuery.fn.life = function (types, data, fn) {
	jQuery(this.context).on(types, this.selector, data, fn);
	return this;
    };

    $.cwpf_mod = $.cwpf_mod || {};

    $.cwpf_mod.popup_prepare = function () {
	new $.cwpf_popup_prepare('.js_cwpf_options');
	new $.cwpf_popup_prepare('.js_cwpf_add_options');
    };

    $.cwpf_mod.expand_prepare = function () {
      new $.cwpf_expand_prepare('.js_cwpf_expand_options');
    };

    $(function () {

	$('.cwpf-tabs').cwpfTabs();

	$.cwpf_mod.popup_prepare();
  $.cwpf_mod.expand_prepare();

	try {
	    $('.cwpf-color-picker').wpColorPicker();
	} catch (e) {
	    console.log(e);
	}

	$("#cwpf_options").sortable({
	    update: function (event, ui) {
		cwpf_sort_order = [];
		$.each($('#cwpf_options').children('li'), function (index, value) {
		    var key = $(this).data('key');
		    cwpf_sort_order.push(key);
		});
		$('input[name="cwpf_settings[items_order]"]').val(cwpf_sort_order.toString());
	    },
	    opacity: 0.8,
	    cursor: "crosshair",
	    handle: '.cwpf_drag_and_drope',
	    placeholder: 'cwpf-options-highlight'
	});


	//options saving
	$('#mainform').submit(function () {
    $('.js_cwpf_expand_options_' + global_cwpf_tabs).click();
	    $('input[name=save]').hide();
	    cwpf_show_info_popup(cwpf_lang_saving);
	    var data = {
		action: "cwpf_save_options",
		formdata: $(this).serialize()
	    };
	    $.post(ajaxurl, data, function () {
		window.location = cwpf_save_link;
	    });

	    return false;
	});


	$('.cwpf_reset_order').click(function () {
	    if (prompt('To reset order of items write word "reset". The page will be reloaded!') == 'reset') {
		$('input[name="cwpf_settings[items_order]"]').val('');
		$('#mainform').submit();
	    }
	});


	$('.js_cache_count_data_clear').click(function () {
	    $(this).next('span').html('clearing ...');
	    var _this = this;
	    var data = {
		action: "cwpf_cache_count_data_clear"
	    };
	    $.post(ajaxurl, data, function () {
		$(_this).next('span').html('cleared!');
	    });

	    return false;
	});


	$('.js_cache_terms_clear').click(function () {
	    $(this).next('span').html('clearing ...');
	    var _this = this;
	    var data = {
		action: "cwpf_cache_terms_clear"
	    };
	    $.post(ajaxurl, data, function () {
		$(_this).next('span').html('cleared!');
	    });

	    return false;
	});

	//in extension tab
	$('#cwpf_manipulate_with_ext').change(function () {
	    var val = parseInt($(this).val(), 10);
	    switch (val) {
		case 1:
		    $('ul.cwpf_extensions li').hide();
		    $('ul.cwpf_extensions li.is_enabled').show();
		    break;
		case 2:
		    $('ul.cwpf_extensions li').hide();
		    $('ul.cwpf_extensions li.is_disabled').show();
		    break;
		default:
		    $('ul.cwpf_extensions li').show();
		    break;
	    }
	});

	//***

	jQuery(document).on('click','.cwpf_select_image',function(){
	    var input_object = jQuery(this).prev('input[type=text]');
	    window.send_to_editor = function (html){
			jQuery('#cwpf_buffer').html(html);
			var imgurl = jQuery('#cwpf_buffer').find('a').eq(0).attr('href');
			jQuery('#cwpf_buffer').html("");
			jQuery(input_object).val(imgurl);
			jQuery(input_object).trigger('change');
			tb_remove();
	    };
	    tb_show('', 'media-upload.php?post_id=0&type=image&TB_iframe=true');

	    return false;
	});

	//***

	jQuery(document).on('click','.cwpf_ext_remove',function(){

	    if (confirm('Sure?')) {
			cwpf_show_info_popup('Extension removing ...');
			var _this = this;
			var data = {
			    action: "cwpf_remove_ext",
			    idx: $(this).data('idx'),
	                    rm_ext_nonce: $('#rm-ext-nonce').val(),
			};
			$.post(ajaxurl, data, function (e) {
	                    //console.log(e);
			    cwpf_show_info_popup('Extension is removed!');
			    $(_this).parents('.cwpf_ext_li').remove();
			    cwpf_hide_info_popup();
			});
	    }

	    return false;
	});

	//***

	$('#toggle_type').change(function () {
	    if ($(this).val() == 'text') {
		$('.toggle_type_text').show(200);
		$('.toggle_type_image').hide(200);
	    } else {
		$('.toggle_type_image').show(200);
		$('.toggle_type_text').hide(200);
	    }
	});

	//***
	//to avoid logic errors with the count options
	$('#cwpf_hide_dynamic_empty_pos').change(function () {
	    if ($(this).val() == 1) {
		$('#cwpf_show_count').val(1);
		$('#cwpf_show_count_dynamic').val(1);
	    }
	});

	$('#cwpf_show_count_dynamic').change(function () {
	    if ($(this).val() == 1) {
		$('#cwpf_show_count').val(1);
	    } else {
		$('#cwpf_hide_dynamic_empty_pos').val(0);
	    }
	});

	$('#cwpf_show_count').change(function () {
	    if ($(this).val() == 0) {
		$('#cwpf_show_count_dynamic').val(0);
		$('#cwpf_hide_dynamic_empty_pos').val(0);
	    }
	});

	//***


	//loader
	$(".cwpf-admin-preloader").fadeOut("slow");

    });

    $('select[name="cwpf_settings[show_images_by_attr_show]"]').change(function () {

        if ($(this).val() == 0) {
            $('select[name="cwpf_settings[show_images_by_attr][]"]').parents('.select-wrap').hide();
        }else{
            $('select[name="cwpf_settings[show_images_by_attr][]"]').parents('.select-wrap').show();
        }
    });

})(jQuery);


function cwpf_show_info_popup(text) {
    jQuery("#cwpf_html_buffer").text(text);
    jQuery("#cwpf_html_buffer").fadeTo(333, 0.9);
}

function cwpf_hide_info_popup() {
    window.setTimeout(function () {
	jQuery("#cwpf_html_buffer").fadeOut(500);
    }, 333);
}
