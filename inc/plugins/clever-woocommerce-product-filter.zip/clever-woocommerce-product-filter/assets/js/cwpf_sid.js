var cwpf_edit_view = false;
var cwpf_current_conatiner_class = '';
var cwpf_current_containers_data = {};

jQuery(function () {
    jQuery('.cwpf_edit_view').click(function () {
        cwpf_edit_view = true;
        var sid = jQuery(this).data('sid');
        var sid_tmp = sid.substring(0, sid.indexOf(' '));
        if(sid_tmp){
           sid=sid_tmp; 
        }
        var css_class = 'cwpf_sid_' + sid;
        jQuery(this).next('div').html(css_class);
        
        //+++
        jQuery("." + css_class + " .cwpf_container_overlay_item").show();
        jQuery("." + css_class + " .cwpf_container").addClass('cwpf_container_overlay');
        jQuery.each(jQuery("." + css_class + " .cwpf_container_overlay_item"), function (index, ul) {
            jQuery(this).html(jQuery(this).parents('.cwpf_container').data('css-class'));
        });

        return false;
    });
    
    
    cwpf_init_masonry();
    
});

function cwpf_init_masonry() {
    return;
    /*
    var $container = jQuery('.cwpf_sid');
    $container.imagesLoaded(function () {
        $container.masonry({
            itemSelector: '.cwpf_container',
            columnWidth: 300
        });
    });
    */
}


/*
function cwpf_change_cont_width(select) {
    var width = parseFloat(jQuery(select).val()) * 100;
    jQuery('.' + cwpf_current_conatiner_class).css('width', width + '%');
}
*/

