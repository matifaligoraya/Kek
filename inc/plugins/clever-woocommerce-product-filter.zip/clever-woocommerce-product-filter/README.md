# Clever WooCommerce Product Filter

CWPF is product search plugin for WooCommerce that allows your site customers filter products by categories, attributes, products tags, products custom taxonomies and price.

# Change log

## Version 1.0.6 - Feb 17, 2021

- Fixed clear filter.
- Fixed dropdown button.
- Fixed ajax pagination.
- Fixed error js open tabs panel.

## Version 1.0.5 - Feb 08, 2021

- Fixed event click for all buttons.


## Version 1.0.4 - Dec 09, 2020

- Correct columns follow woocommerce setting.
- Compatible with pop-up of Elementor Pro.
- Fixed undefined some variables.
