jQuery(function ($) {    
    $('.cwpf_toggle_colors').click(function () {
        $(this).parent().find('ul.cwpf_color_list').toggle();
    });
});
