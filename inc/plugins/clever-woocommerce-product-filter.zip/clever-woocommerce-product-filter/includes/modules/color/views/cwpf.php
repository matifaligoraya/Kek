<?php if (!defined('ABSPATH')) die('No direct access allowed'); ?>

<?php
global $CWPF;
//http://code.tutsplus.com/articles/how-to-use-wordpress-color-picker-api--wp-33067
$colors = isset($cwpf_settings['color'][$tax_slug]) ? $cwpf_settings['color'][$tax_slug] : array();
$colors_imgs = isset($cwpf_settings['color_img'][$tax_slug]) ? $cwpf_settings['color_img'][$tax_slug] : array();
$show_count = get_option('cwpf_show_count', 0);
$show_count_dynamic = get_option('cwpf_show_count_dynamic', 0);
$hide_dynamic_empty_pos = get_option('cwpf_hide_dynamic_empty_pos', 0);
$cwpf_autosubmit = get_option('cwpf_autosubmit', 0);
//********************
$show_tooltip =  $this->settings['show_tooltip'][$tax_slug];

$show_title = 0;
if(isset($this->settings['show_title_attr'][$tax_slug])){
    $show_title = (int)$this->settings['show_title_attr'][$tax_slug];
}
$show_title_class = "";
if($this->settings['show_column'][$tax_slug]){
   $show_title_class = "cwpf_color_title_col";
}

?>

<ul class = "cwpf_list cwpf_list_color <?php echo $show_title_class ?>">
    <?php
    $cwpf_tax_values = array();
    $current_request = array();
    $request = $CWPF->get_request_data();
    $_REQUEST['additional_taxes'] = $additional_taxes;
    $_REQUEST['hide_terms_count_txt'] = isset($CWPF->settings['hide_terms_count_txt']) ? $CWPF->settings['hide_terms_count_txt'] : 0;
    //***
    if(isset($_REQUEST['hide_terms_count_txt_short']) AND $_REQUEST['hide_terms_count_txt_short']!=-1){
        if((int)$_REQUEST['hide_terms_count_txt_short']==1){
            $_REQUEST['hide_terms_count_txt']=1;
        }else{
            $_REQUEST['hide_terms_count_txt']=0;
        }
    }
    //***
    if ($CWPF->is_isset_in_request_data($CWPF->check_slug($tax_slug)))
    {
        $current_request = $request[$CWPF->check_slug($tax_slug)];
        $current_request = explode(',', urldecode($current_request));
    }
//excluding hidden terms
    $hidden_terms = array();
    if (!isset($_REQUEST['cwpf_shortcode_excluded_terms']))
    {
        if (isset($CWPF->settings['excluded_terms'][$tax_slug]))
        {
            $hidden_terms = explode(',', $CWPF->settings['excluded_terms'][$tax_slug]);
        }
    } else
    {
        $hidden_terms = explode(',', $_REQUEST['cwpf_shortcode_excluded_terms']);
    }


    //***

    $not_toggled_terms_count = 0;
    if (isset($CWPF->settings['not_toggled_terms_count'][$tax_slug]))
    {
        $not_toggled_terms_count = intval($CWPF->settings['not_toggled_terms_count'][$tax_slug]);
    }
    //***

    $terms = apply_filters('cwpf_sort_terms_before_out', $terms, 'color');
    $terms_count_printed = 0;
    $hide_next_term_li = false;
    ?>
    <?php if (!empty($terms)): ?>
        <?php foreach ($terms as $term) : $inique_id = uniqid(); ?>
            <?php
            $count_string = "";
            $count = 0;
            if (!in_array($term['slug'], $current_request))
            {
                if ($show_count)
                {
                    if ($show_count_dynamic)
                    {
                        $count = $CWPF->dynamic_count($term, 'multi', $_REQUEST['additional_taxes']);
                    } else
                    {
                        $count = $term['count'];
                    }
                    $count_string = '<span class="count">' . $count . '</span>';
                }
                //+++
                if ($hide_dynamic_empty_pos AND $count == 0)
                {
                    continue;
                }
            }

            if ($_REQUEST['hide_terms_count_txt'])
            {
                $count_string = "";
            }

            $color = '#000000';
            if (isset($colors[$term['slug']]))
            {
                $color = $colors[$term['slug']];
            }

            $color_img = '';
            if (isset($colors_imgs[$term['slug']]) AND ! empty($colors_imgs[$term['slug']]))
            {
                $color_img = $colors_imgs[$term['slug']];
            }

            //excluding hidden terms
            $inreverse=true;
            if (isset($CWPF->settings['excluded_terms_reverse'][$tax_slug]) AND $CWPF->settings['excluded_terms_reverse'][$tax_slug])
            {
                 $inreverse=!$inreverse;
            }  
            if (in_array($term['term_id'], $hidden_terms)==$inreverse)
            {
                continue;
            }


            if ($not_toggled_terms_count > 0 AND $terms_count_printed === $not_toggled_terms_count)
            {
                $hide_next_term_li = true;
            }


            $term_desc = strip_tags(term_description($term['term_id'], $term['taxonomy']));
            ?>
            <li class="cwpf_color_term_<?php echo sanitize_title($color) ?> cwpf_color_term_<?php echo $term['term_id'] ?> <?php if ($hide_next_term_li): ?>cwpf_hidden_term<?php endif; ?>">
                <p class="cwpf_tooltip" <?php echo $show_tooltip && $count? 'data-tooltip="'.$count.'"': ''; ?>>
                    <input type="checkbox" <?php checked(in_array($term['slug'], $current_request)) ?> id="<?php echo 'cwpf_' . $term['term_id'] . '_' . $inique_id ?>" class="cwpf_color_term cwpf_color_term_<?php echo $term['term_id'] ?> <?php if (in_array($term['slug'], $current_request)): ?>checked<?php endif; ?>" data-color="<?php echo $color ?>" data-img="<?php echo $color_img ?>" data-tax="<?php echo $CWPF->check_slug($tax_slug) ?>" name="<?php echo $term['slug'] ?>" data-term-id="<?php echo $term['term_id'] ?>" value="<?php echo $term['term_id'] ?>" <?php echo checked(in_array($term['slug'], $current_request)) ?> /></p>

                <input type="hidden" value="<?php echo $term['name'] ?>" data-anchor="cwpf_n_<?php echo $CWPF->check_slug($tax_slug) ?>_<?php echo $term['slug'] ?>" />
            
                <?php
                if($show_title){ ?>
                    <span class="cwpf_color_title <?php echo (in_array($term['slug'], $current_request))?"cwpf_checkbox_label_selected":"" ?>"><?php echo $term['name'] ?></span>
                <?php } ?>
            </li>
            <?php
            $terms_count_printed++;
        endforeach;
        ?>

        <?php
        if ($not_toggled_terms_count > 0 AND $terms_count_printed > $not_toggled_terms_count):
            ?>
            <li class="cwpf_open_hidden_li"><?php CWPF_HELPER::draw_more_less_button('color') ?></li>
        <?php endif; ?>
    <?php endif; ?>
</ul>
<?php
//we need it only here, and keep it in $_REQUEST for using in function for child items
unset($_REQUEST['additional_taxes']);

