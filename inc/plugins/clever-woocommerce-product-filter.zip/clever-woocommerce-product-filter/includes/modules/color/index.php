<?php
if (!defined('ABSPATH'))
    die('No direct access allowed');

final class CWPF_EXT_COLOR extends CWPF_EXT
{

    public $type = 'html_type';
    public $html_type = 'color'; //your custom key here
    public $html_type_dynamic_recount_behavior = 'multi';

    public function __construct()
    {
	parent::__construct();
	$this->init();
    }

    public function get_ext_path()
    {
	return plugin_dir_path(__FILE__);
    }
    public function get_ext_override_path()
    {
        return get_stylesheet_directory(). DIRECTORY_SEPARATOR ."cwpf". DIRECTORY_SEPARATOR ."ext". DIRECTORY_SEPARATOR .$this->html_type. DIRECTORY_SEPARATOR;
    }
    public function get_ext_link()
    {
	return plugin_dir_url(__FILE__);
    }

    public function init()
    {
	add_filter('cwpf_add_html_types', array($this, 'cwpf_add_html_types'));
	add_action('wp_head', array($this, 'wp_head'), 999);
	add_action('woocommerce_settings_tabs_cwpf', array($this, 'woocommerce_settings_tabs_cwpf'), 51);
	add_action('cwpf_print_tax_additional_options_color', array($this, 'print_additional_options'), 10, 1);
	add_action('cwpf_print_design_additional_options', array($this, 'cwpf_print_design_additional_options'), 10, 1);
	self::$includes['js']['cwpf_' . $this->html_type . '_html_items'] = $this->get_ext_link() . 'js/html_types/' . $this->html_type . '.js';
	self::$includes['css']['cwpf_' . $this->html_type . '_html_items'] = $this->get_ext_link() . 'css/html_types/' . $this->html_type . '.css';
	self::$includes['js_init_functions'][$this->html_type] = 'cwpf_init_colors';

	add_action('admin_head', array($this, 'admin_head'), 50);

	$this->taxonomy_type_additional_options = array(
	    'show_tooltip' => array(
			'title' => __('Tooltip text', 'cwpfilter'),
			'tip' => __('Show tooltip text for attribute', 'cwpfilter'),
			'type' => 'select',
			'options' => array(
			    1 => __('Yes', 'cwpfilter'),
			    0 => __('No', 'cwpfilter')		    
			)
	    ),
        'show_title_attr' => array(
			'title' => __('Show title attribute', 'cwpfilter'),
			'tip' => __('Show title attribute', 'cwpfilter'),
			'type' => 'select',
			'options' => array(
			    1 => __('Yes', 'cwpfilter'),
			    0 => __('No', 'cwpfilter')		    
			)
	    ),
	    'show_column' => array(
			'title' => __('Show one column', 'cwpfilter'),
			'tip' => __('Show one attribute for one row', 'cwpfilter'),
			'type' => 'select',
			'options' => array(
			    1 => __('Yes', 'cwpfilter'),
			    0 => __('No', 'cwpfilter')		    
			)
	    ),
	);
    }

    public function admin_head()
    {
	if (isset($_GET['tab']) AND $_GET['tab'] == 'cwpf')
	{
	    wp_enqueue_style('cwpf_color', $this->get_ext_link() . 'css/admin.css',array(),CWPF_VERSION);
	    wp_enqueue_script('cwpf_color', $this->get_ext_link() . 'js/html_types/plugin_options.js', array('jquery'),CWPF_VERSION);
	}
    }

    public function cwpf_add_html_types($types)
    {
	$types[$this->html_type] = __('Color', 'cwpfilter');
	return $types;
    }

    public function woocommerce_settings_tabs_cwpf()
    {
	wp_enqueue_style('wp-color-picker');
	wp_enqueue_script('wp-color-picker');
    }

    public function wp_head()
    {
	global $CWPF;
	?>
	<style type="text/css">
	<?php
	if (isset($CWPF->settings['checked_color_img']))
	{
	    if (!empty($CWPF->settings['checked_color_img']))
	    {
		?>
		    .checked .cwpf_color_checked{
			background: url(<?php echo $CWPF->settings['checked_color_img'] ?>) !important;
		    }             
		<?php
	    }
	}
	?>
	</style>
	<?php
    }

    public function print_additional_options($key)
    {
	global $CWPF;
	$cwpf_settings = $CWPF->settings;
	$terms = CWPF_HELPER::get_terms($key, 0, 0, 0, 0);
	if (!empty($terms))
	{
	    ?>
	<br /><a href="javascript:void(0);" class="button cwpf_toggle_colors"><?php _e('toggle color terms', 'cwpfilter') ?></a><br />
	    <ul class="cwpf_color_list">
		<?php
		foreach ($terms as $t)
		{
		    $color = '#000000';
		    if (isset($cwpf_settings['color'][$key][$t['slug']]))
		    {
			$color = $cwpf_settings['color'][$key][$t['slug']];
		    }

		    $color_img = '';
		    if (isset($cwpf_settings['color_img'][$key][$t['slug']]))
		    {
			$color_img = $cwpf_settings['color_img'][$key][$t['slug']];
		    }
		    ?>
		    <li>
			<table>
			    <tr>
				<td valign="top">
				    <input type="text" name="cwpf_settings[color][<?php echo $key ?>][<?php echo $t['slug'] ?>]" value="<?php echo $color ?>" id="cwpf_color_picker_<?php echo $t['slug'] ?>" class="cwpf-color-picker" >
				</td>
				<td>
				    <input type="text" name="cwpf_settings[color_img][<?php echo $key ?>][<?php echo $t['slug'] ?>]" value="<?php echo $color_img ?>" placeholder="<?php _e('background image url 25x25', 'cwpfilter') ?>" class="text" style="width: 600px;" />
				    <a href="#" class="cwpf-button cwpf_select_image"><?php _e('Select Image', 'cwpfilter') ?></a>
				</td>
				<td valign="top" style="padding: 4px 0 0 0;">
				    <p class="description"> [ <?php echo CWPF_HELPER::strtolower($t['name']) ?> ]</p>
				</td>
			    </tr>
			</table>
		    </li>
		    <?php
		}
		echo '</ul>';
	    }
	}

	public function cwpf_print_design_additional_options()
	{
	    global $CWPF;
	    $cwpf_settings = $CWPF->settings;

	    if (!isset($cwpf_settings['checked_color_img']))
	    {
		$cwpf_settings['checked_color_img'] = '';
	    }
	    ?>

	    <!--<div class="cwpf-control-section">

			    <<?php echo apply_filters('cwpf_title_tag', 'h4'); ?>><?php _e('Image for checked color type checkbox', 'cwpfilter') ?></<?php echo apply_filters('cwpf_title_tag', 'h4'); ?>>

		<div class="cwpf-control-container">
		    <div class="cwpf-control cwpf-upload-style-wrap">
					    <input type="text" name="cwpf_settings[checked_color_img]" value="<?php //echo $cwpf_settings['checked_color_img']          ?>" />
					    <a href="#" class="cwpf-button cwpf_select_image"><?php _e('Select Image', 'cwpfilter') ?></a>
		    </div>
		    <div class="cwpf-description">
					    <p class="description"><?php _e('Image for color checkboxes when its checked. Better use png. Size is: 25x25 px.', 'cwpfilter') ?></p>
		    </div>
		</div>

	    </div> -->

	    <?php
	}

    }

    CWPF_EXT::$includes['taxonomy_type_objects']['color'] = new CWPF_EXT_COLOR();
    