<?php if (!defined('ABSPATH')) die('No direct access allowed'); ?>
<?php global $CWPF; ?>
<div data-css-class="cwpf_author_search_container" class="cwpf_author_search_container cwpf_container cwpf_container_cwpf_author">
    <div class="cwpf_container_overlay_item"></div>
    <div class="cwpf_container_inner">

	<?php
	if (!isset($view) OR empty($view)) {
	    $view = (isset($CWPF->settings['by_author']['view'])) ? $CWPF->settings['by_author']['view'] : 'drop-down';
	}

	$args = array(
	    'role' => '',
	    'meta_key' => '',
	    'meta_value' => '',
	    'meta_compare' => '',
	    'meta_query' => array(),
	    'date_query' => array(),
	    'include' => array(),
	    'exclude' => array(),
	    'orderby' => 'login',
	    'order' => 'ASC',
	    'offset' => '',
	    'search' => '',
	    'number' => '',
	    'count_total' => false,
	    'fields' => 'all',
	    'who' => ''
	);

	if (isset($role) AND ! empty($role)) {
	    $args['role'] = $role;
	}
        $authors_title=array();
	$authors = get_users($args);
	$request = $CWPF->get_request_data();
	$cwpf_author = '';
	if (isset($request['cwpf_author'])) {
	    $cwpf_author = $request['cwpf_author'];
	}
	//+++
	$p = __('Select a product author', 'cwpfilter');

	if (isset($placeholder) AND ! empty($placeholder)) {
	    $p = $placeholder;
	} else {
	    if (isset($CWPF->settings['by_author']['placeholder'])) {
		if (!empty($CWPF->settings['by_author']['placeholder'])) {
		    $p = $CWPF->settings['by_author']['placeholder'];
		    $p = CWPF_HELPER::wpml_translate(null, $p);
		    $p = __($p, 'cwpfilter');
		}
	    }
	}



	//***
	$unique_id = uniqid('cwpf_author_search_');


	switch ($view) {
	    case 'checkbox':
		?>
		<?php $cwpf_author = explode(",", $cwpf_author); ?>
		<<?php echo apply_filters('cwpf_title_tag', 'h4'); ?>><?php echo $p ?></<?php echo apply_filters('cwpf_title_tag', 'h4'); ?>>
		<div data-css-class="cwpf_checkbox_authors_container" class="cwpf_checkbox_authors_container cwpf_container">
		    <div class="cwpf_container_overlay_item"></div>
		    <div class="cwpf_container_inner">
			<ul class='cwpf_authors '>
			    <?php foreach ($authors as $user): ?>
	    		    <li>
	    			<input type="checkbox" class="cwpf_checkbox_author" id="cwpf_checkbox_author_<?php echo $user->data->ID ?>" name="cwpf_author[]" value="<?php echo $user->data->ID ?>" <?php if (in_array($user->data->ID, $cwpf_author)) echo "checked"; ?> />&nbsp;&nbsp;<label for="cwpf_checkbox_author_<?php echo $user->data->ID ?>"><?php echo $user->data->display_name ?></label>
	    		        <?php
                                if (in_array($user->data->ID, $cwpf_author)){
                                    $authors_title[]=$user;
                                }
                                ?>
                            </li>
			    <?php endforeach; ?>
			</ul>
		    </div>
		</div>
		<?php
		break;
	    default :
		?>
		<select name="cwpf_author" class="cwpf_select cwpf_show_author_search <?php echo $unique_id ?>" data-uid="<?php echo $unique_id ?>">
		    <option value="0"><?php echo $p ?></option>
		    <?php if (!empty($authors)): ?>
			<?php foreach ($authors as $user): ?>
			    <option <?php echo selected($cwpf_author, $user->data->ID); ?> value="<?php echo $user->data->ID ?>"><?php echo $user->data->display_name ?></option>
                            <?php
                            if ($user->data->ID == $cwpf_author){
                                $authors_title[]=$user;
                            }
                            ?>
                        <?php endforeach; ?>
		    <?php endif; ?>
		</select>
		<?php
		break;
	}
        if(!empty($authors_title)){
           foreach($authors_title as $user){
            ?>
            <input type="hidden" value="<?php echo __('Author:', 'cwpfilter'), $user->data->display_name;?>" data-anchor="cwpf_n_<?php echo "cwpf_author" ?>_<?php echo $user->data->ID ?>" />
            <?php  
           }
        }
	?>               
    </div>
</div>
