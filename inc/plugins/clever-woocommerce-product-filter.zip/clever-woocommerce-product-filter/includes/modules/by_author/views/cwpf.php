<?php

if (!defined('ABSPATH'))
    die('No direct access allowed');

global $CWPF;
if (isset($CWPF->settings['by_author']))
{
    if ($CWPF->settings['by_author']['show'])
    {
        $placeholder = '';
        $role = '';
        if (isset($CWPF->settings['by_author']['placeholder']))
        {
            CWPF_HELPER::wpml_translate(null, $CWPF->settings['by_author']['placeholder']);
        }

        if (isset($CWPF->settings['by_author']['role']))
        {
            $role = $CWPF->settings['by_author']['role'];
        }

        echo do_shortcode('[cwpf_author_filter role="' . $role . '" placeholder="' . $placeholder . '"]');
    }
}

