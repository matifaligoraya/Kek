function cwpf_init_author() {
 
    if (icheck_skin != 'none') {
        
        jQuery('.cwpf_checkbox_author').iCheck({
            checkboxClass: 'icheckbox_' + icheck_skin.skin + '-' + icheck_skin.color,
            //checkboxClass: 'icheckbox_square-green'
        });
        
        jQuery('.cwpf_checkbox_author').on('ifChecked', function (event) {
            jQuery(this).attr("checked", true);
            
            cwpf_current_values.cwpf_author = get_current_checked();
            cwpf_ajax_page_num = 1;
            if (cwpf_autosubmit) {
                cwpf_submit_link(cwpf_get_submit_link());
            }
        });

        jQuery('.cwpf_checkbox_author').on('ifUnchecked', function (event) {
            jQuery(this).attr("checked", false);
            cwpf_current_values.cwpf_author =get_current_checked();
            cwpf_ajax_page_num = 1;
            if (cwpf_autosubmit) {
                cwpf_submit_link(cwpf_get_submit_link());
            }
        });

    } else {
        jQuery('.cwpf_checkbox_author').on('change', function (event) {
            if (jQuery(this).is(':checked')) {
                jQuery(this).attr("checked", true);
                cwpf_current_values.cwpf_author= get_current_checked();
                cwpf_ajax_page_num = 1;
                if (cwpf_autosubmit) {
                    cwpf_submit_link(cwpf_get_submit_link());
                }
            } else {
                jQuery(this).attr("checked", false);
                cwpf_current_values.cwpf_author=get_current_checked();
                cwpf_ajax_page_num = 1;
                if (cwpf_autosubmit) {
                    cwpf_submit_link(cwpf_get_submit_link());
                }
            }
        });
    }
    
    
    function get_current_checked(){
        var values=[];
        jQuery('.cwpf_checkbox_author').each(function(i,el){
            if(jQuery(this).attr("checked") == 'checked'){
                values.push(jQuery(this).val());
            }
         
        });
        return values.join(',');
    }
    
}
