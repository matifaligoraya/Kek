<?php
if (!defined('ABSPATH'))
    die('No direct access allowed');

global $CWPF;
$cwpf_ext_featured_label=apply_filters('cwpf_ext_custom_title_by_featured',__('Featured product', 'cwpfilter'));
if (isset($CWPF->settings['by_featured']) AND $CWPF->settings['by_featured']['show'])
{
    ?>
    <div data-css-class="cwpf_checkbox_featured_container" class="cwpf_checkbox_featured_container cwpf_container cwpf_container_product_visibility">
        <div class="cwpf_container_overlay_item"></div>
        <div class="cwpf_container_inner">
            <input type="checkbox" class="cwpf_checkbox_featured" id="cwpf_checkbox_featured" name="product_visibility" value="0" <?php checked('featured', $CWPF->is_isset_in_request_data('product_visibility') ? 'featured' : '', true) ?> />&nbsp;&nbsp;<label for="cwpf_checkbox_featured"><?php echo $cwpf_ext_featured_label ?></label><br />
        </div>
    </div>
    <?php
}


