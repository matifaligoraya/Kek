<?php
if (!defined('ABSPATH'))
    die('No direct access allowed');
?>

<li data-key="<?php echo $key ?>" class="cwpf_options_li">

    <?php
    $show = 0;
    if (isset($cwpf_settings[$key]['show']))
    {
        $show = (int) $cwpf_settings[$key]['show'];
    }
    ?>

    <a href="#" class="help_tip cwpf_drag_and_drope" data-tip="<?php _e("drag and drope", 'cwpfilter'); ?>"><span class="cwpf-list-icons cwpf-list-move-button"></span></a>

    <strong style="display: inline-block; width: 176px;"><?php _e("Featured checkbox", 'cwpfilter'); ?>:</strong>

    <img class="help_tip" data-tip="<?php _e('Show Featured products checkbox inside CWPF search form', 'cwpfilter') ?>" src="<?php echo WP_PLUGIN_URL ?>/woocommerce/assets/images/help.png" height="16" width="16" />

    <div class="select-wrap">
        <select name="cwpf_settings[<?php echo $key ?>][show]" class="cwpf_setting_select">
            <option value="0" <?php echo selected($show, 0) ?>><?php _e('No', 'cwpfilter') ?></option>
            <option value="1" <?php echo selected($show, 1) ?>><?php _e('Yes', 'cwpfilter') ?></option>
        </select>
    </div>


    <!-- <input type="button" value="<?php _e('additional options', 'cwpfilter') ?>" data-key="<?php echo $key ?>" data-name="<?php _e("Search by featured", 'cwpfilter'); ?>" class="cwpf-button js_cwpf_options js_cwpf_options_<?php echo $key ?>" /> -->

    <div id="cwpf-modal-content-<?php echo $key ?>" style="display: none;">



    </div>


</li>
