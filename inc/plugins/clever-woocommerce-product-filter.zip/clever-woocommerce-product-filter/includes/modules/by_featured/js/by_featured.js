function cwpf_init_featured() {
   
    if (icheck_skin != 'none') {
        
        jQuery('.cwpf_checkbox_featured').iCheck({
            checkboxClass: 'icheckbox_' + icheck_skin.skin + '-' + icheck_skin.color,
            //checkboxClass: 'icheckbox_square-green'
        });
        
        jQuery('.cwpf_checkbox_featured').on('ifChecked', function (event) {
            jQuery(this).attr("checked", true);
            cwpf_current_values.product_visibility= 'featured';
            cwpf_ajax_page_num = 1;
            if (cwpf_autosubmit) {
                cwpf_submit_link(cwpf_get_submit_link());
            }
        });

        jQuery('.cwpf_checkbox_featured').on('ifUnchecked', function (event) {
            jQuery(this).attr("checked", false);
            delete cwpf_current_values.product_visibility;
            cwpf_ajax_page_num = 1;
            if (cwpf_autosubmit) {
                cwpf_submit_link(cwpf_get_submit_link());
            }
        });

    } else {
        jQuery('.cwpf_checkbox_featured').on('change', function (event) {
            if (jQuery(this).is(':checked')) {
                jQuery(this).attr("checked", true);
                cwpf_current_values.product_visibility = 'featured';
                cwpf_ajax_page_num = 1;
                if (cwpf_autosubmit) {
                    cwpf_submit_link(cwpf_get_submit_link());
                }
            } else {
                jQuery(this).attr("checked", false);
                delete cwpf_current_values.product_visibility;
                cwpf_ajax_page_num = 1;
                if (cwpf_autosubmit) {
                    cwpf_submit_link(cwpf_get_submit_link());
                }
            }
        });
    }
}
