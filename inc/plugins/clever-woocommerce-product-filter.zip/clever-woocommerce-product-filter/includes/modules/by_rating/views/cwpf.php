<?php
if (!defined('ABSPATH'))
    die('No direct access allowed');

global $CWPF;
if (isset($CWPF->settings['by_rating']) AND $CWPF->settings['by_rating']['show']) {
    ?>
    <div data-css-class="cwpf_by_rating_container" class="cwpf_by_rating_container cwpf_container">
        <div class="cwpf_container_overlay_item"></div>
        <div class="cwpf_container_inner">
            <select class="cwpf_by_rating_dropdown cwpf_select" name="min_rating">
                <?php
                $vals = array(
                    0 => __('Filter by rating', 'cwpfilter'),
                    4 => __('average rating between 4 to 5', 'cwpfilter'),
                    3 => __('average rating between 3 to 4-', 'cwpfilter'),
                    2 => __('average rating between 2 to 3-', 'cwpfilter'),
                    1 => __('average rating between 1 to 2-', 'cwpfilter')
                );
                $request = $CWPF->get_request_data();
                $selected = $CWPF->is_isset_in_request_data('min_rating') ? $request['min_rating'] : 0;
                ?>
                <?php foreach ($vals as $key => $value): ?>
                    <option <?php echo selected($selected, $key); ?> value="<?php echo $key ?>"><?php echo $value ?></option>
                <?php endforeach; ?>
            </select>
            <input type="hidden" value="<?php echo __('Min rating: ', 'cwpfilter'), $selected ?>" data-anchor="cwpf_n_<?php echo "min_rating" ?>_<?php echo $selected ?>" />
        </div>
    </div>
    <?php
}


