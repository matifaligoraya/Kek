function cwpf_init_image() {
    //http://jsfiddle.net/jtbowden/xP2Ns/
    jQuery('.cwpf_image_term').each(function () {
        //title: jQuery(this).prev('.cwpf_tooltip_data').html().replace(/(<([^>]+)>)/ig, "")
        var image = jQuery(this).data('image');
        var styles = jQuery(this).data('styles');
        if (image.length > 0) {
            styles += '; background-image: url(' + image + '); ';
        } else {
            styles += '; background-color: #ffffff;';
        }

        var span = jQuery('<span style="' + styles + '" class="' + jQuery(this).attr('type') + ' ' + jQuery(this).attr('class') + '" title=""></span>').click(cwpf_image_do_check).mousedown(cwpf_image_do_down).mouseup(cwpf_image_do_up);
        if (jQuery(this).is(':checked')) {
            span.addClass('checked');
        }
        jQuery(this).wrap(span).hide();
        jQuery(this).after('<span class="cwpf_image_checked"></span>');//for checking
    });

    function cwpf_image_do_check() {
        var is_checked = false;
        var radio=false;
        if(jQuery(this).parents(".cwpf_list_image").data("type")=="radio"){
            radio=true;
        }
        if(radio){
            var elements=jQuery(this).parents(".cwpf_list_image").find(".cwpf_image_term");
            jQuery(elements).removeClass('checked');
            jQuery(elements).children().prop("checked", false);
        }
           
        if (jQuery(this).hasClass('checked')) {
            jQuery(this).removeClass('checked');
            jQuery(this).children().prop("checked", false);
        } else {
            jQuery(this).addClass('checked');
            jQuery(this).children().prop("checked", true);
            is_checked = true;
        }

        cwpf_image_process_data(this, is_checked,radio);
    }

    function cwpf_image_do_down() {
        jQuery(this).addClass('clicked');
    }

    function cwpf_image_do_up() {
        jQuery(this).removeClass('clicked');
    }
}

function cwpf_image_process_data(_this, is_checked,radio) {
    var tax = jQuery(_this).find('input[type=checkbox]').data('tax');
    var name = jQuery(_this).find('input[type=checkbox]').attr('name');
    var term_id = jQuery(_this).find('input[type=checkbox]').data('term-id');
    cwpf_image_direct_search(term_id, name, tax, is_checked,radio);
}

function cwpf_image_direct_search(term_id, name, tax, is_checked,radio) {

    var values = '';
    var checked = true;
    if (is_checked) {
        if(!radio){
            if (tax in cwpf_current_values) {
                cwpf_current_values[tax] = cwpf_current_values[tax] + ',' + name;
            } else {
                cwpf_current_values[tax] = name;
            }            
        }else{
            cwpf_current_values[tax] = name;
        }

        checked = true;
    } else {
        if(!radio){
            values = cwpf_current_values[tax];
            values = values.split(',');
            var tmp = [];
            jQuery.each(values, function (index, value) {
                if (value != name) {
                    tmp.push(value);
                }
            });
            values = tmp;
            if (values.length) {
                cwpf_current_values[tax] = values.join(',');
            } else {
                delete cwpf_current_values[tax];
            }            
        }else{
            delete cwpf_current_values[tax];
        }
        
        checked = false;
    }
    jQuery('.cwpf_image_term_' + term_id).attr('checked', checked);
    cwpf_ajax_page_num = 1;
    if (cwpf_autosubmit) {
        cwpf_submit_link(cwpf_get_submit_link());
    }
}


