jQuery(function ($) {
    $('.cwpf_toggle_images').click(function () {
        $(this).parent().find('ul.cwpf_image_list').toggle();
    });
});
