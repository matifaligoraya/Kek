<?php if (!defined('ABSPATH')) die('No direct access allowed'); ?>
<div data-css-class="cwpf_text_search_container" class="cwpf_text_search_container cwpf_container cwpf_container_cwpf_text">
    <div class="cwpf_container_overlay_item"></div>
    <div class="cwpf_container_inner">
        <?php
        global $CWPF;
        $cwpf_text = '';
        $request = $CWPF->get_request_data();

        if (isset($request['cwpf_text']))
        {
            $cwpf_text = $request['cwpf_text'];
        }
        //+++
        if (!isset($placeholder))
        {
            $p = __('enter a product title here ...', 'cwpfilter');
        }

        if (isset($CWPF->settings['by_text']['placeholder']) AND ! isset($placeholder))
        {
            if (!empty($CWPF->settings['by_text']['placeholder']))
            {
                $p = $CWPF->settings['by_text']['placeholder'];
                $p = CWPF_HELPER::wpml_translate(null, $p);
                $p = __($p, 'cwpfilter');
            }


            if ($CWPF->settings['by_text']['placeholder'] == 'none')
            {
                $p = '';
            }
        }
        //***
        $unique_id = uniqid('cwpf_text_search_');
        ?>

        <div class="cwpf_show_text_search_container">
            <img width="36" class="cwpf_show_text_search_loader" style="display: none;" src="<?php echo $loader_img ?>" alt="loader" />
            <a href="javascript:void(0);" data-uid="<?php echo $unique_id ?>" class="cwpf_text_search_go <?php echo $unique_id ?>"></a>
            <input type="search" class="cwpf_show_text_search <?php echo $unique_id ?>" id="<?php echo $unique_id ?>" data-uid="<?php echo $unique_id ?>" data-auto_res_count="<?php echo(isset($auto_res_count) ? $auto_res_count : 0) ?>" data-auto_search_by="<?php echo(isset($auto_search_by) ? $auto_search_by : "") ?>" placeholder="<?php echo(isset($placeholder) ? $placeholder : $p) ?>" name="cwpf_text" value="<?php echo $cwpf_text ?>" />
            
            <?php if (isset($CWPF->settings['by_text']['notes_for_customer']) AND ! empty($CWPF->settings['by_text']['notes_for_customer'])): ?>
                <span class="cwpf_text_notes_for_customer"><?php echo stripcslashes($CWPF->settings['by_text']['notes_for_customer']); ?></span>
            <?php endif; ?>        
        </div>


    </div>
</div>