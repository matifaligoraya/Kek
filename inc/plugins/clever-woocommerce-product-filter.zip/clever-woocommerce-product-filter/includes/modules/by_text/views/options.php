<?php
if (!defined('ABSPATH'))
    die('No direct access allowed');
?>

<li data-key="<?php echo $key ?>" class="cwpf_options_li">

    <?php
    $show = 0;
    if (isset($cwpf_settings[$key]['show']))
    {
        $show = $cwpf_settings[$key]['show'];
    }
    ?>

    <a href="#" class="help_tip cwpf_drag_and_drope" data-tip="<?php _e("drag and drope", 'cwpfilter'); ?>"><span class="cwpf-list-icons cwpf-list-move-button"></span></a>

    <strong style="display: inline-block; width: 176px;"><?php _e("Search by Text", 'cwpfilter'); ?>:</strong>

    <img class="help_tip" data-tip="<?php _e('Show textinput for searching by products title', 'cwpfilter') ?>" src="<?php echo WP_PLUGIN_URL ?>/woocommerce/assets/images/help.png" height="16" width="16" />

    <div class="select-wrap">
        <select name="cwpf_settings[<?php echo $key ?>][show]" class="cwpf_setting_select">
            <option value="0" <?php echo selected($show, 0) ?>><?php _e('No', 'cwpfilter') ?></option>
            <option value="1" <?php echo selected($show, 1) ?>><?php _e('Yes', 'cwpfilter') ?></option>
        </select>
    </div>

    <span value="<?php _e('additional options', 'cwpfilter') ?>" data-key="<?php echo $key ?>" data-name="<?php _e("Search by text", 'cwpfilter'); ?>" class="cwpf-list-icons js_cwpf_expand_options js_cwpf_expand_options_<?php echo $key ?>"></span>

    <?php
    if (!isset($cwpf_settings[$key]['title']))
    {
        $cwpf_settings[$key]['title'] = '';
    }

    if (!isset($cwpf_settings[$key]['placeholder']))
    {
        $cwpf_settings[$key]['placeholder'] = '';
    }

    if (!isset($cwpf_settings[$key]['behavior']))
    {
        $cwpf_settings[$key]['behavior'] = 'title';
    }
     if (!isset($cwpf_settings[$key]['search_by_full_word']))
    {
        $cwpf_settings[$key]['search_by_full_word'] = 0;
    }
     if (!isset($cwpf_settings[$key]['search_desc_variant']))
    {
        $cwpf_settings[$key]['search_desc_variant'] = 0;
    }
         if (!isset($cwpf_settings[$key]['sku_compatibility']))
    {
        $cwpf_settings[$key]['sku_compatibility'] = 0;
    }
    if (!isset($cwpf_settings[$key]['autocomplete']))
    {
        $cwpf_settings[$key]['autocomplete'] = 0;
    }

    if (!isset($cwpf_settings[$key]['post_links_in_autocomplete']))
    {
        $cwpf_settings[$key]['post_links_in_autocomplete'] = 0;
    }

    if (!isset($cwpf_settings[$key]['how_to_open_links']))
    {
        $cwpf_settings[$key]['how_to_open_links'] = 0;
    }


    if (!isset($cwpf_settings[$key]['image']))
    {
        $cwpf_settings[$key]['image'] = '';
    }

    if (!isset($cwpf_settings[$key]['notes_for_customer']))
    {
        $cwpf_settings[$key]['notes_for_customer'] = '';
    }
    ?>

    <input type="hidden" name="cwpf_settings[<?php echo $key ?>][title]" value="<?php echo $cwpf_settings[$key]['title'] ?>" />
    <input type="hidden" name="cwpf_settings[<?php echo $key ?>][placeholder]" value="<?php echo $cwpf_settings[$key]['placeholder'] ?>" />
    <input type="hidden" name="cwpf_settings[<?php echo $key ?>][behavior]" value="<?php echo $cwpf_settings[$key]['behavior'] ?>" />
    <input type="hidden" name="cwpf_settings[<?php echo $key ?>][search_by_full_word]" value="<?php echo $cwpf_settings[$key]['search_by_full_word'] ?>" />
    <input type="hidden" name="cwpf_settings[<?php echo $key ?>][search_desc_variant]" value="<?php echo $cwpf_settings[$key]['search_desc_variant'] ?>" />
    <input type="hidden" name="cwpf_settings[<?php echo $key ?>][autocomplete]" value="<?php echo $cwpf_settings[$key]['autocomplete'] ?>" />
    <input type="hidden" name="cwpf_settings[<?php echo $key ?>][post_links_in_autocomplete]" value="<?php echo $cwpf_settings[$key]['post_links_in_autocomplete'] ?>" />
    <input type="hidden" name="cwpf_settings[<?php echo $key ?>][how_to_open_links]" value="<?php echo $cwpf_settings[$key]['how_to_open_links'] ?>" />
    <input type="hidden" name="cwpf_settings[<?php echo $key ?>][image]" value="<?php echo $cwpf_settings[$key]['image'] ?>" />
    <input type="hidden" name="cwpf_settings[<?php echo $key ?>][sku_compatibility]" value="<?php echo $cwpf_settings[$key]['sku_compatibility'] ?>" />
    <input type="hidden" name="cwpf_settings[<?php echo $key ?>][notes_for_customer]" value="<?php echo stripcslashes($cwpf_settings[$key]['notes_for_customer']); ?>" />

    <div id="cwpf-modal-content-by_text" style="display: none;">

        <div style="display: none;">
            <div class="cwpf-form-element-container">

                <div class="cwpf-name-description">
                    <strong><?php _e('Title text', 'cwpfilter') ?></strong>
                    <span><?php _e('Leave it empty if you not need this', 'cwpfilter') ?></span>
                </div>

                <div class="cwpf-form-element">
                    <input type="text" class="cwpf_popup_option" data-option="title" placeholder="" value="" />
                </div>

            </div>
        </div>

        <div class="cwpf-form-element-container">

            <div class="cwpf-name-description">
                <strong><?php _e('Placeholder text', 'cwpfilter') ?></strong>
                <span><?php _e('Leave it empty if you not need this', 'cwpfilter') ?></span>
                <span><?php _e('Set "none" to disable placeholder for this textinput', 'cwpfilter') ?></span>
            </div>

            <div class="cwpf-form-element">
                <input type="text" class="cwpf_popup_option" data-option="placeholder" placeholder="" value="" />
            </div>

        </div>


        <div class="cwpf-form-element-container">

            <div class="cwpf-name-description">
                <strong><?php _e('Behavior', 'cwpfilter') ?></strong>
                <span><?php _e('behavior of the text searching', 'cwpfilter') ?></span>
            </div>

            <div class="cwpf-form-element">

                <?php
                $behavior = array(
                    'title' => __("Search by title", 'cwpfilter'),
                    'content' => __("Search by content", 'cwpfilter'),
                    'excerpt' => __("Search by excerpt", 'cwpfilter'),
                    'content_or_excerpt' => __("Search by content OR excerpt", 'cwpfilter'),
                    'title_or_content_or_excerpt' => __("Search by title OR content OR excerpt", 'cwpfilter'),
                    'title_or_content' => __("Search by title OR content", 'cwpfilter'),
                    'title_and_content' => __("Search by title AND content", 'cwpfilter')
                );
                ?>

                <div class="select-wrap">
                    <select class="cwpf_popup_option" data-option="behavior">
                        <?php foreach ($behavior as $_behavior_key => $_behavior_value) : ?>
                            <option value="<?php echo $_behavior_key; ?>"><?php echo $_behavior_value; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

            </div>

        </div>
 <div class="cwpf-form-element-container">

            <div class="cwpf-name-description">
                <strong><?php _e('Search by full word only', 'cwpfilter') ?></strong>
                <span><?php _e('The result is only with the full coincidence of words', 'cwpfilter') ?></span>
            </div>

            <div class="cwpf-form-element">
                <?php
                $autocomplete = array(
                    0 => __('No', 'cwpfilter'),
                    1 => __('Yes', 'cwpfilter')
                );
                ?>

                <div class="select-wrap">
                    <select class="cwpf_popup_option" data-option="search_by_full_word">
                        <?php foreach ($autocomplete as $_autocomplete_key => $_autocomplete_value) : ?>
                            <option value="<?php echo $_autocomplete_key; ?>"><?php echo $_autocomplete_value; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

            </div>

        </div>


        <div class="cwpf-form-element-container">

            <div class="cwpf-name-description">
                <strong><?php _e('Autocomplete', 'cwpfilter') ?></strong>
                <span><?php _e('Autocomplete relevant variants in by_text textinput', 'cwpfilter') ?></span>
            </div>

            <div class="cwpf-form-element">
                <?php
                $autocomplete = array(
                    0 => __('No', 'cwpfilter'),
                    1 => __('Yes', 'cwpfilter')
                );
                ?>

                <div class="select-wrap">
                    <select class="cwpf_popup_option" data-option="autocomplete">
                        <?php foreach ($autocomplete as $_autocomplete_key => $_autocomplete_value) : ?>
                            <option value="<?php echo $_autocomplete_key; ?>"><?php echo $_autocomplete_value; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

            </div>

        </div>


        <div class="cwpf-form-element-container">

            <div class="cwpf-name-description">
                <strong><?php _e('Links to posts in suggestion', 'cwpfilter') ?></strong>
                <span><?php _e('Direct links to posts in autocomplete suggestion', 'cwpfilter') ?></span>
            </div>

            <div class="cwpf-form-element">
                <?php
                $post_links_in_autocomplete = array(
                    0 => __('No', 'cwpfilter'),
                    1 => __('Yes', 'cwpfilter')
                );
                ?>

                <div class="select-wrap">
                    <select class="cwpf_popup_option" data-option="post_links_in_autocomplete">
                        <?php foreach ($post_links_in_autocomplete as $_post_links_in_autocomplete_key => $_post_links_in_autocomplete_value) : ?>
                            <option value="<?php echo $_post_links_in_autocomplete_key; ?>"><?php echo $_post_links_in_autocomplete_value; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

            </div>

        </div>

        <div class="cwpf-form-element-container">

            <div class="cwpf-name-description">
                <strong><?php _e('How to open links with posts in suggestion', 'cwpfilter') ?></strong>
                <span><?php _e('In the same window (_self) or in the new one (_blank)', 'cwpfilter') ?></span>
            </div>

            <div class="cwpf-form-element">
                <?php
                $how_to_open_links = array(
                    0 => __('new window', 'cwpfilter'),
                    1 => __('the same window', 'cwpfilter')
                );
                ?>

                <div class="select-wrap">
                    <select class="cwpf_popup_option" data-option="how_to_open_links">
                        <?php foreach ($how_to_open_links as $_how_to_open_links_key => $_how_to_open_links_value) : ?>
                            <option value="<?php echo $_how_to_open_links_key; ?>"><?php echo $_how_to_open_links_value; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

            </div>

        </div>

	<div class="cwpf-form-element-container">

            <div class="cwpf-name-description">
                <strong><?php _e('+SKU ', 'cwpfilter') ?></strong>
                <span><?php _e('Activates the ability to search by SKU from the same text-input', 'cwpfilter') ?></span>
            </div>

            <div class="cwpf-form-element">
                <?php
                $autocomplete = array(
                    0 => __('No', 'cwpfilter'),
                    1 => __('Yes', 'cwpfilter')
                );
                ?>

                <div class="select-wrap">
                    <select class="cwpf_popup_option" data-option="sku_compatibility">
                        <?php foreach ($autocomplete as $_autocomplete_key => $_autocomplete_value) : ?>
                            <option value="<?php echo $_autocomplete_key; ?>"><?php echo $_autocomplete_value; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

            </div>

        </div>
	<div class="cwpf-form-element-container">

            <div class="cwpf-name-description">
                <strong><?php _e('Search by description in variations', 'cwpfilter') ?></strong>
                <span><?php _e('Ability to search by the description of the any variation in the variable product', 'cwpfilter') ?></span>
            </div>

            <div class="cwpf-form-element">
                <?php
                $desc_var = array(
                    0 => __('No', 'cwpfilter'),
                    1 => __('Yes', 'cwpfilter')
                );
                ?>

                <div class="select-wrap">
                    <select class="cwpf_popup_option" data-option="search_desc_variant">
                        <?php foreach ($desc_var as $_desc_var_key => $_desc_var_value) : ?>
                            <option value="<?php echo $_desc_var_key; ?>"><?php echo $_desc_var_value; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

            </div>

        </div>
            <div class="cwpf-form-element-container">

            <div class="cwpf-name-description">
                <strong><?php _e('Notes for customer', 'cwpfilter') ?></strong>
                <span><?php _e('Any notes for customer.', 'cwpfilter') ?></span>
            </div>

            <div class="cwpf-form-element">
                <textarea class="cwpf_popup_option" data-option="notes_for_customer"></textarea>
            </div>

        </div>
        <div class="cwpf-form-element-container">

            <div class="cwpf-name-description">
                <strong><?php _e('Image', 'cwpfilter') ?></strong>
                <span><?php _e('Image for text search button which appears near input when users typing there any symbols. Better use png. Size is: 20x20 px.', 'cwpfilter') ?></span>
                <span><?php _e('Example', 'cwpfilter') ?>: <?php echo CWPF_IMG_LINK ?>eye-icon1.png</span>
            </div>

            <div class="cwpf-form-element">
                <input type="text" class="cwpf_popup_option" data-option="image" placeholder="" value="" />
                <a href="#" style="margin: 5px 0 0 0; clear: both;" class="cwpf-button cwpf_select_image"><?php _e('Select Image', 'cwpfilter') ?></a>
            </div>

        </div>
    </div>

</li>
