<?php
if (!defined('ABSPATH'))
    die('No direct access allowed');

global $CWPF;
if (isset($CWPF->settings['by_text']) AND $CWPF->settings['by_text']['show'])
{
    if (isset($CWPF->settings['by_text']['title']) AND ! empty($CWPF->settings['by_text']['title']))
    {
        ?>
        <!-- <<?php echo apply_filters('cwpf_title_tag', 'h4'); ?>><?php echo $CWPF->settings['by_text']['title']; ?></<?php echo apply_filters('cwpf_title_tag', 'h4'); ?>> -->
        <?php
    }
    echo do_shortcode('[cwpf_text_filter]');
}


