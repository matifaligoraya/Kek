<?php

if (!defined('ABSPATH'))
    die('No direct access allowed');

//need  $orderby = apply_filters('cwpf_get_terms_orderby', $taxonomy);
final class CWPF_EXT_SLIDER extends CWPF_EXT {

    public $type = 'html_type';
    public $html_type = 'slider'; //your custom key here
    public $html_type_dynamic_recount_behavior = 'multi';

    public function __construct()
    {
        parent::__construct();
        $this->init();
    }

    public function get_ext_path()
    {
        return plugin_dir_path(__FILE__);
    }
    public function get_ext_override_path()
    {
        return get_stylesheet_directory(). DIRECTORY_SEPARATOR ."cwpf". DIRECTORY_SEPARATOR ."ext". DIRECTORY_SEPARATOR .$this->html_type. DIRECTORY_SEPARATOR;
    }
    public function get_ext_link()
    {
        return plugin_dir_url(__FILE__);
    }

    public function cwpf_add_html_types($types)
    {
        $types[$this->html_type] = __('Slider', 'cwpfilter');
        return $types;
    }

    public function init()
    {
        add_filter('cwpf_add_html_types', array($this, 'cwpf_add_html_types'));
        add_action('wp_head', array($this, 'wp_head'), 999);
        self::$includes['js']['cwpf_' . $this->html_type . '_html_items'] = $this->get_ext_link() . 'js/html_types/slider.js';
        self::$includes['css']['cwpf_' . $this->html_type . '_html_items'] = $this->get_ext_link() . 'css/html_types/slider.css';
        self::$includes['js_init_functions'][$this->html_type] = 'cwpf_init_sliders';


        $this->taxonomy_type_additional_options = array(
            'slider_dynamic_recount' => array(
                'title' => __('Enable dynamic recount', 'cwpfilter'),
                'tip' => __('Activates dynamic recount for each term in the the range. If you have very long range (a lot of terms) this feature will generate additional MySQL queries which will create additional loading on the server!', 'cwpfilter'),
                'type' => 'select',
                'options' => array(
                    0 => __('No', 'cwpfilter'),
                    1 => __('Yes', 'cwpfilter')
                )
            ),
            'slider_grid_step' => array(
                'title' => __('Grig step', 'cwpfilter'),
                'tip' => __('Hide each Nth grid label. -1 hide all labels, 1 show all labels, 2n show each second label, 3n show each third label, etc...', 'cwpfilter'),
                'type' => 'text',

            )
        );
    }

    public function wp_head()
    {
        global $CWPF;
        wp_enqueue_script('ion.range-slider', CWPF_JS_LINK . 'ion.range-slider/js/ion-rangeSlider/ion.rangeSlider.min.js', array('jquery'),CWPF_VERSION);
        wp_enqueue_style('ion.range-slider', CWPF_JS_LINK . 'ion.range-slider/css/ion.rangeSlider.css',array(),CWPF_VERSION);
        $ion_slider_skin = 'skinNice';
        if (isset($CWPF->settings['ion_slider_skin']))
        {
            $ion_slider_skin = $CWPF->settings['ion_slider_skin'];
        }
        wp_enqueue_style('ion.range-slider-skin', CWPF_JS_LINK . 'ion.range-slider/css/ion.rangeSlider.' . $ion_slider_skin . '.css',array(),CWPF_VERSION);
    }

}

CWPF_EXT::$includes['taxonomy_type_objects']['slider'] = new CWPF_EXT_SLIDER();
