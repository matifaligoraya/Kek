var cwpf_sku_do_submit = false;
function cwpf_init_sku() {
    jQuery('.cwpf_show_sku_search').keyup(function (e) {
        var val = jQuery(this).val();
        val = val.replace(' ', '');
        var uid = jQuery(this).data('uid');

        if (e.keyCode == 13 /*&& val.length > 0*/) {
            cwpf_sku_do_submit = true;
            cwpf_sku_direct_search('cwpf_sku', val);
            return true;
        }

        //save new word into cwpf_current_values
        if (cwpf_autosubmit) {
            cwpf_current_values['cwpf_sku'] = val;
        } else {
            cwpf_sku_direct_search('cwpf_sku', val);
        }


        //if (cwpf_is_mobile == 1) {
        if (val.length > 0) {
            jQuery('.cwpf_sku_search_go.' + uid).show(222);
        } else {
            jQuery('.cwpf_sku_search_go.' + uid).hide();
        }
        //}

        //http://easyautocomplete.com/examples
        if (val.length >= 3 && cwpf_sku_autocomplete) {
            var input_id = jQuery(this).attr('id');
            var options = {
                url: function (phrase) {
                    return cwpf_ajaxurl;
                },
                //theme: "square",
                getValue: function (element) {
                    return element.name;
                },
                ajaxSettings: {
                    dataType: "json",
                    method: "POST",
                    data: {
                        action: "cwpf_sku_autocomplete",
                        dataType: "json"
                    }
                },
                preparePostData: function (data) {
                    data.phrase = jQuery("#" + input_id).val();
                    return data;
                },
                template: {
                    type: "description",
                    fields: {
                        //iconSrc: "icon",
                        description: "type"
                    }
                },
                list: {
                    maxNumberOfElements: cwpf_sku_autocomplete_items,
                    onChooseEvent: function () {
                        cwpf_sku_do_submit = true;
                        cwpf_sku_direct_search('cwpf_sku', jQuery("#" + input_id).val());
                        return true;
                    },
                    showAnimation: {
                        type: "fade", //normal|slide|fade
                        time: 333,
                        callback: function () {
                        }
                    },
                    hideAnimation: {
                        type: "slide", //normal|slide|fade
                        time: 333,
                        callback: function () {
                        }
                    }

                },
                requestDelay: 400
            };
            try {
                jQuery("#" + input_id).easyAutocomplete(options);
            } catch (e) {
                console.log(e);
            }
            jQuery("#" + input_id).focus();
        }
    });
    //+++
    jQuery(document).on('click','.cwpf_sku_search_go',function(){
        var uid = jQuery(this).data('uid');
        cwpf_sku_do_submit = true;
        var val = jQuery('.cwpf_show_sku_search.' + uid).val();
        val = val.replace(' ', '');
        cwpf_sku_direct_search('cwpf_sku', val);
    });
}

function cwpf_sku_direct_search(name, slug) {

    jQuery.each(cwpf_current_values, function (index, value) {
        if (index == name) {
            delete cwpf_current_values[name];
            return;
        }
    });

    if (slug != 0) {
        cwpf_current_values[name] = slug;
    }

    cwpf_ajax_page_num = 1;
    if (cwpf_autosubmit || cwpf_sku_do_submit) {
        cwpf_sku_do_submit = false;
        cwpf_submit_link(cwpf_get_submit_link());
    }
}


