<?php
if (!defined('ABSPATH'))
    die('No direct access allowed');
?>

<li data-key="<?php echo $key ?>" class="cwpf_options_li">

    <?php
    $show = 0;
    if (isset($cwpf_settings[$key]['show']))
    {
        $show = (int) $cwpf_settings[$key]['show'];
    }
    ?>

    <a href="#" class="help_tip cwpf_drag_and_drope" data-tip="<?php _e("drag and drope", 'cwpfilter'); ?>"><span class="cwpf-list-icons cwpf-list-move-button"></span></a>

    <strong style="display: inline-block; width: 176px;"><?php _e("Search by SKU", 'cwpfilter'); ?>:</strong>

    <img class="help_tip" data-tip="<?php _e('Show textinput for searching by products sku', 'cwpfilter') ?>" src="<?php echo WP_PLUGIN_URL ?>/woocommerce/assets/images/help.png" height="16" width="16" />

    <div class="select-wrap">
        <select name="cwpf_settings[<?php echo $key ?>][show]" class="cwpf_setting_select">
            <option value="0" <?php echo selected($show, 0) ?>><?php _e('No', 'cwpfilter') ?></option>
            <option value="1" <?php echo selected($show, 1) ?>><?php _e('Yes', 'cwpfilter') ?></option>
        </select>
    </div>

    <span value="<?php _e('additional options', 'cwpfilter') ?>" data-key="<?php echo $key ?>" data-name="<?php _e("Search by SKU", 'cwpfilter'); ?>" class="cwpf-list-icons js_cwpf_expand_options js_cwpf_expand_options_<?php echo $key ?>"></span>
    <?php
    if (!isset($cwpf_settings[$key]['logic']) OR empty($cwpf_settings[$key]['logic']))
    {
        $cwpf_settings[$key]['logic'] = 'LIKE';
    }

    if (!isset($cwpf_settings[$key]['autocomplete']) OR empty($cwpf_settings[$key]['autocomplete']))
    {
        $cwpf_settings[$key]['autocomplete'] = 0;
    }

     if (!isset($cwpf_settings[$key]['autocomplete_items']) OR empty($cwpf_settings[$key]['autocomplete_items']))
    {
        $cwpf_settings[$key]['autocomplete_items'] = 10;
    }

    if (!isset($cwpf_settings[$key]['use_for']) OR empty($cwpf_settings[$key]['use_for']))
    {
        $cwpf_settings[$key]['use_for'] = 'simple';
    }


    if (!isset($cwpf_settings[$key]['title']))
    {
        $cwpf_settings[$key]['title'] = '';
    }

    if (!isset($cwpf_settings[$key]['placeholder']))
    {
        $cwpf_settings[$key]['placeholder'] = '';
    }

    if (!isset($cwpf_settings[$key]['image']))
    {
        $cwpf_settings[$key]['image'] = '';
    }

    if (!isset($cwpf_settings[$key]['notes_for_customer']))
    {
        $cwpf_settings[$key]['notes_for_customer'] = '';
    }
    ?>

    <input type="hidden" name="cwpf_settings[<?php echo $key ?>][logic]" value="<?php echo $cwpf_settings[$key]['logic'] ?>" />
    <input type="hidden" name="cwpf_settings[<?php echo $key ?>][autocomplete]" value="<?php echo $cwpf_settings[$key]['autocomplete'] ?>" />
    <input type="hidden" name="cwpf_settings[<?php echo $key ?>][autocomplete_items]" value="<?php echo $cwpf_settings[$key]['autocomplete_items'] ?>" />
    <input type="hidden" name="cwpf_settings[<?php echo $key ?>][use_for]" value="<?php echo $cwpf_settings[$key]['use_for'] ?>" />
    <input type="hidden" name="cwpf_settings[<?php echo $key ?>][title]" value="<?php echo $cwpf_settings[$key]['title'] ?>" />
    <input type="hidden" name="cwpf_settings[<?php echo $key ?>][placeholder]" value="<?php echo $cwpf_settings[$key]['placeholder'] ?>" />
    <input type="hidden" name="cwpf_settings[<?php echo $key ?>][image]" value="<?php echo $cwpf_settings[$key]['image'] ?>" />
    <input type="hidden" name="cwpf_settings[<?php echo $key ?>][notes_for_customer]" value="<?php echo stripcslashes($cwpf_settings[$key]['notes_for_customer']) ?>" />

    <div id="cwpf-modal-content-<?php echo $key ?>" style="display: none;">

        <div style="display: none;">
            <div class="cwpf-form-element-container">

                <div class="cwpf-name-description">
                    <strong><?php _e('Title text', 'cwpfilter') ?></strong>
                    <span><?php _e('Leave it empty if you not need this', 'cwpfilter') ?></span>
                </div>

                <div class="cwpf-form-element">
                    <input type="text" class="cwpf_popup_option" data-option="title" placeholder="" value="" />
                </div>

            </div>
        </div>

        <div class="cwpf-form-element-container">

            <div class="cwpf-name-description">
                <strong><?php _e('Placeholder text', 'cwpfilter') ?></strong>
                <span><?php _e('Leave it empty if you not need this', 'cwpfilter') ?></span>
                <span><?php _e('SKU textinput placeholder. Set "none" if you want leave it empty on the front.', 'cwpfilter') ?></span>
            </div>

            <div class="cwpf-form-element">
                <input type="text" class="cwpf_popup_option" data-option="placeholder" placeholder="" value="" />
            </div>

        </div>

        <div class="cwpf-form-element-container">

            <div class="cwpf-name-description">
                <strong><?php _e('Conditions logic', 'cwpfilter') ?></strong>
                <span><?php _e('LIKE or Equally', 'cwpfilter') ?></span>
            </div>

            <div class="cwpf-form-element">
                <?php
                $logic = array(
                    '=' => __('Exact match', 'cwpfilter'),
                    'LIKE' => __('LIKE', 'cwpfilter')
                );
                ?>

                <div class="select-wrap">
                    <select class="cwpf_popup_option" data-option="logic">
                        <?php foreach ($logic as $_logic_key => $_logic_value) : ?>
                            <option value="<?php echo $_logic_key; ?>"><?php echo $_logic_value; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

            </div>

        </div>


        <div class="cwpf-form-element-container">

            <div class="cwpf-name-description">
                <strong><?php _e('Autocomplete', 'cwpfilter') ?></strong>
                <span><?php _e('Autocomplete relevant variants in SKU textinput', 'cwpfilter') ?></span>
            </div>

            <div class="cwpf-form-element">
                <?php
                $autocomplete = array(
                    0 => __('No', 'cwpfilter'),
                    1 => __('Yes', 'cwpfilter')
                );
                ?>

                <div class="select-wrap">
                    <select class="cwpf_popup_option" data-option="autocomplete">
                        <?php foreach ($autocomplete as $_autocomplete_key => $_autocomplete_value) : ?>
                            <option value="<?php echo $_autocomplete_key; ?>"><?php echo $_autocomplete_value; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

            </div>

        </div>


	<div class="cwpf-form-element-container">

            <div class="cwpf-name-description">
                <strong><?php _e('Autocomplete products count', 'cwpfilter') ?></strong>
                <span><?php _e('How many show products in the autocomplete list', 'cwpfilter') ?></span>
            </div>

            <div class="cwpf-form-element">
                <input type="text" class="cwpf_popup_option" data-option="autocomplete_items" placeholder="" value="" />
            </div>

        </div>


        <div class="cwpf-form-element-container">

            <div class="cwpf-name-description">
                <strong><?php _e('Use for', 'cwpfilter') ?></strong>
                <span><?php _e('For which type of products will be realized searching by SKU. Request for variables products creates more mysql queries in database ...', 'cwpfilter') ?></span>
            </div>

            <div class="cwpf-form-element">
                <?php
                $use_for = array(
                    'simple' => __('For simple products only', 'cwpfilter'),
                    'both' => __('For simple and for variables products', 'cwpfilter')
                );
                ?>

                <div class="select-wrap">
                    <select class="cwpf_popup_option" data-option="use_for">
                        <?php foreach ($use_for as $_use_for_key => $_use_for_value) : ?>
                            <option value="<?php echo $_use_for_key; ?>"><?php echo $_use_for_value; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

            </div>

        </div>


        <div class="cwpf-form-element-container">

            <div class="cwpf-name-description">
                <strong><?php _e('Notes for customer', 'cwpfilter') ?></strong>
                <span><?php _e('Any notes for customer.<br /><b>Example</b>: use comma for searching by more than 1 SKU!', 'cwpfilter') ?></span>
            </div>

            <div class="cwpf-form-element">
                <textarea class="cwpf_popup_option" data-option="notes_for_customer"></textarea>
            </div>

        </div>

        <div class="cwpf-form-element-container">

            <div class="cwpf-name-description">
                <strong><?php _e('Image', 'cwpfilter') ?></strong>
                <span><?php _e('Image for sku search button which appears near input when users typing there any symbols. Better use png. Size is: 20x20 px.', 'cwpfilter') ?></span>
                <span><?php _e('Example', 'cwpfilter') ?>: <?php echo CWPF_IMG_LINK ?>eye-icon1.png</span>
            </div>

            <div class="cwpf-form-element">
                <input type="text" class="cwpf_popup_option" data-option="image" placeholder="" value="" />
                <a href="#" style="margin: 5px 0 0 0; clear: both;" class="cwpf-button cwpf_select_image"><?php _e('Select Image', 'cwpfilter') ?></a>
            </div>

        </div>
    </div>

</li>
