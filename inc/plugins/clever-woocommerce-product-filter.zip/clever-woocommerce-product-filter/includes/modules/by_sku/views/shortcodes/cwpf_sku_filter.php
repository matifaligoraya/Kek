<?php if (!defined('ABSPATH')) die('No direct access allowed'); ?>
<div data-css-class="cwpf_sku_search_container" class="cwpf_sku_search_container cwpf_container cwpf_container_cwpf_sku">
    <div class="cwpf_container_overlay_item"></div>
    <div class="cwpf_container_inner">
        <?php
        $cwpf_sku = '';
        $request = $this->get_request_data();

        if (isset($request['cwpf_sku']))
        {
            $cwpf_sku = $request['cwpf_sku'];
        }
        //+++
        if (!isset($placeholder))
        {
            $p = __('enter a product sku here ...', 'cwpfilter');
        }


        if (isset($this->settings['by_sku']['placeholder']) AND ! isset($placeholder))
        {
            if (!empty($this->settings['by_sku']['placeholder']))
            {
                $p = $this->settings['by_sku']['placeholder'];
                $p = CWPF_HELPER::wpml_translate(null, $p);
                $p = __($p, 'cwpfilter');
            }


            if ($this->settings['by_sku']['placeholder'] == 'none')
            {
                $p = '';
            }
        }
        //***
        $unique_id = uniqid('cwpf_sku_search_');
        ?>

        <div class="cwpf_show_sku_search_container">
            <a href="javascript:void(0);" data-uid="<?php echo $unique_id ?>" class="cwpf_sku_search_go <?php echo $unique_id ?>"></a>
            <input type="search" class="cwpf_show_sku_search <?php echo $unique_id ?>" id="<?php echo $unique_id ?>" data-uid="<?php echo $unique_id ?>" placeholder="<?php echo(isset($placeholder) ? $placeholder : $p) ?>" name="cwpf_sku" value="<?php echo $cwpf_sku ?>" /><br />
            <?php if (isset($this->settings['by_sku']['notes_for_customer']) AND ! empty($this->settings['by_sku']['notes_for_customer'])): ?>
                <span class="cwpf_sku_notes_for_customer"><?php echo stripcslashes($this->settings['by_sku']['notes_for_customer']); ?></span>
            <?php endif; ?>
        </div>

    </div>
</div>