<?php
if (!defined('ABSPATH'))
    die('No direct access allowed');

global $CWPF;
if (isset($CWPF->settings['by_sku']) AND $CWPF->settings['by_sku']['show'])
{
    if (isset($CWPF->settings['by_sku']['title']) AND ! empty($CWPF->settings['by_sku']['title']))
    {
        ?>
        <!-- <<?php echo apply_filters('cwpf_title_tag', 'h4'); ?>><?php echo $CWPF->settings['by_sku']['title']; ?></<?php echo apply_filters('cwpf_title_tag', 'h4'); ?>> -->
        <?php
    }
    echo do_shortcode('[cwpf_sku_filter]');
}

