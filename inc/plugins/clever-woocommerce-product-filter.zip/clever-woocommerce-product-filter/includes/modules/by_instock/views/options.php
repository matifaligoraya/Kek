<?php
if (!defined('ABSPATH'))
    die('No direct access allowed');
?>

<li data-key="<?php echo $key ?>" class="cwpf_options_li">

    <?php
    $show = 0;
    if (isset($cwpf_settings[$key]['show']))
    {
        $show = (int) $cwpf_settings[$key]['show'];
    }
    ?>

    <a href="#" class="help_tip cwpf_drag_and_drope" data-tip="<?php _e("drag and drope", 'cwpfilter'); ?>"><span class="cwpf-list-icons cwpf-list-move-button"></span></a>

    <strong style="display: inline-block; width: 176px;"><?php _e("In stock checkbox", 'cwpfilter'); ?>:</strong>

    <img class="help_tip" data-tip="<?php _e('Show In stock only checkbox inside cwpf search form', 'cwpfilter') ?>" src="<?php echo WP_PLUGIN_URL ?>/woocommerce/assets/images/help.png" height="16" width="16" />

    <div class="select-wrap">
        <select name="cwpf_settings[<?php echo $key ?>][show]" class="cwpf_setting_select">
            <option value="0" <?php echo selected($show, 0) ?>><?php _e('No', 'cwpfilter') ?></option>
            <option value="1" <?php echo selected($show, 1) ?>><?php _e('Yes', 'cwpfilter') ?></option>
        </select>
    </div>


    <span value="<?php _e('additional options', 'cwpfilter') ?>" data-key="<?php echo $key ?>" data-name="<?php _e("Search by InStock", 'cwpfilter'); ?>" class="cwpf-list-icons js_cwpf_expand_options js_cwpf_expand_options_<?php echo $key ?>"></span>


    <?php
    if (!isset($cwpf_settings[$key]['use_for']))
    {
        $cwpf_settings[$key]['use_for'] = 'simple';
    }
    ?>

    <input type="hidden" name="cwpf_settings[<?php echo $key ?>][use_for]" value="<?php echo $cwpf_settings[$key]['use_for'] ?>" />


    <div id="cwpf-modal-content-<?php echo $key ?>" style="display: none;">

        <div class="cwpf-form-element-container">

            <div class="cwpf-name-description">
                <strong><?php _e('Search in variable produts', 'cwpfilter') ?></strong>
                <span><?php _e('Will the plugin look in each variable of variable products. Request for variables products creates more mysql queries in database ...', 'cwpfilter') ?></span>
            </div>

            <div class="cwpf-form-element">
                <?php
                $use_for = array(
                    'simple' => __('Simple products only', 'cwpfilter'),
                    'both' => __('Search in products and their variations', 'cwpfilter')
                );
                ?>
                <div class="select-wrap">
                    <select class="cwpf_popup_option" data-option="use_for">
                        <?php foreach ($use_for as $use_for_key => $use_for_value) : ?>
                            <option value="<?php echo $use_for_key; ?>"><?php echo $use_for_value; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

            </div>

        </div>

    </div>


</li>
