<?php
if (!defined('ABSPATH'))
    die('No direct access allowed');

global $CWPF;
$cwpf_ext_instock_label=apply_filters('cwpf_ext_custom_title_by_instock',__('In stock', 'cwpfilter'));
if (isset($CWPF->settings['by_instock']) AND $CWPF->settings['by_instock']['show'])
{
    ?>
    <div data-css-class="cwpf_checkbox_instock_container" class="cwpf_checkbox_instock_container cwpf_container cwpf_container_stock">
        <div class="cwpf_container_overlay_item"></div>
        <div class="cwpf_container_inner">
            <input type="checkbox" class="cwpf_checkbox_instock" id="cwpf_checkbox_instock" name="stock" value="0" <?php checked('instock', $CWPF->is_isset_in_request_data('stock') ? 'instock' : '', true) ?> />&nbsp;&nbsp;<label for="cwpf_checkbox_instock"><?php echo $cwpf_ext_instock_label ?></label><br />
        </div>
    </div>
    <?php
}


