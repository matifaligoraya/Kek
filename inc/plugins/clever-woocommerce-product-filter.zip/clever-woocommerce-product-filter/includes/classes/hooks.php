<?php

if (!defined('ABSPATH'))
    die('No direct access allowed');

final class CWPF_HOOKS
{

    public static function cwpf_get_front_css_file_link()
    {
        return apply_filters('cwpf_get_front_css_file_link', CWPF_CSS_LINK . 'front.css');
    }

}
