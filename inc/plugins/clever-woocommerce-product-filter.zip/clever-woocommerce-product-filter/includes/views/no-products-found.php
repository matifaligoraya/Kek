<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
global $CWPF;
echo do_shortcode(stripcslashes($CWPF->settings['override_no_products']));
