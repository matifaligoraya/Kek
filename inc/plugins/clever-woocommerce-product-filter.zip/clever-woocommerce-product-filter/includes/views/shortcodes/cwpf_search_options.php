<?php if (!defined('ABSPATH')) die('No direct access allowed'); ?>

<div class="cwpf_products_top_panel_content">
    <?php do_action('cwpf_products_top_panel_content') ?>
</div>
<div class="cwpf_products_top_panel"></div>