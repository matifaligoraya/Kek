<?php if (!defined('ABSPATH')) die('No direct access allowed'); ?>
<?php
if (!isset($additional_taxes)) {
    $additional_taxes = '';
}
$price2_filter_data = CWPF_HELPER::get_price2_filter_data($additional_taxes);

$show_count = get_option('cwpf_show_count', 0);
$show_count_dynamic = get_option('cwpf_show_count_dynamic', 0);
$hide_dynamic_empty_pos = get_option('cwpf_hide_dynamic_empty_pos', 0);
$hide_count_text = isset($this->settings['hide_terms_count_txt']) ? $this->settings['hide_terms_count_txt'] : 0;
//***
if (isset($_REQUEST['hide_terms_count_txt_short']) AND $_REQUEST['hide_terms_count_txt_short'] != -1) {
    if ((int) $_REQUEST['hide_terms_count_txt_short'] == 1) {
        $hide_count_text = 1;
    } else {
        $hide_count_text = 0;
    }
}
//***
?>


<div data-css-class="cwpf_price_filter_radio_container" class="cwpf_checkbox_authors_container ">
    <div class="cwpf_container_overlay_item"></div>
    <div class="cwpf_container_inner">
        <ul class='cwpf_authors '>
            <?php
            if (!isset($price2_filter_data['ranges']['options']) OR ! is_array($price2_filter_data['ranges']['options'])) {
                _e('Not possible. Enter options ranges in the plugin settings -> tab Filters -> Search by price -> additional options', 'cwpfilter');
            } else {
                foreach ($price2_filter_data['ranges']['options'] as $k => $value): $value = trim($value);
                    ?>
                    <?php
                    $c = 0;
                    $cs = '';
                    if ($show_count) {
                        $c = (int) $price2_filter_data['ranges']['count'][$k];
                        $cs = '(' . $c . ')';
                    }
                    if ($hide_count_text) {
                        $cs = '';
                    }

                    if ($show_count_dynamic AND $c == 0) {
                        if ($hide_dynamic_empty_pos) {
                            continue;
                        }
                    }
                    //***

                    $unique_id = uniqid('wr_');
                    ?>
                    <li class="cwpf_list">
                        <input type="radio" <?php if ($c == 0 AND $show_count): ?>disabled=""<?php endif; ?> class="cwpf_price_filter_radio"  <?php echo checked($price2_filter_data['selected'], $k); ?>  name="cwpf_price_radio" id="cwpf_price_radio_<?php echo $unique_id ?>" value="<?php echo $k ?>"  />
                        &nbsp;&nbsp;<label for="cwpf_price_radio_<?php echo $unique_id ?>"><?php echo($value) ?> <?php echo $cs ?>  </label>
                        <a href="" data-tax="price" style="display: none;" class="cwpf_radio_price_reset <?php if ($price2_filter_data['selected'] == $k): ?> cwpf_radio_term_reset_visible <?php endif; ?> cwpf_radio_term_reset_<?php echo $k ?>"><span class="cwpf-font cwpf-icon-close-1"></span></a>
                    </li>
                <?php
                endforeach;
            }
            ?>
        </ul>
    </div>
</div>


<?php


