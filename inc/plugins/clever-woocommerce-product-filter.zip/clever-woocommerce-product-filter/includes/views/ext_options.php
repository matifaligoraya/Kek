<?php
if (!defined('ABSPATH'))
    die('No direct access allowed');
//***
extract($options);
?>
<div class="cwpf-control-section-2">

    <h5><?php echo $title ?></h5>

    <div class="cwpf-control-container">
        <div class="cwpf-control">
            <?php
            if (!isset($cwpf_settings[$key]))
            {
                $cwpf_settings[$key] = $default;
            }
            //***
            switch ($type)
            {
                case 'textinput':
                    ?>
                    <input type="text" placeholder="<?php echo $placeholder ?>" name="cwpf_settings[<?php echo $key ?>]" value="<?php echo stripcslashes($cwpf_settings[$key]) ?>" id="<?php echo $key ?>" />
                    <?php
                    break;
                case 'color':
                    ?>
                    <input type="text" placeholder="<?php echo $placeholder ?>" class="cwpf-color-picker" name="cwpf_settings[<?php echo $key ?>]" value="<?php echo $cwpf_settings[$key] ?>" id="<?php echo $key ?>" />
                    <?php
                    break;
                case 'select':
                    ?>
                    <select name="cwpf_settings[<?php echo $key ?>]" id="<?php echo $key ?>">
                        <?php
                        if (!empty($select_options))
                        {
                            foreach ($select_options as $opt_key => $opt_title)
                            {
                                ?>
                                <option <?php echo selected($cwpf_settings[$key], $opt_key) ?> value="<?php echo $opt_key ?>"><?php echo $opt_title ?></option>
                                <?php
                            }
                        }
                        ?>
                    </select>
                    <?php
                    break;
                case 'image':
                    ?>
                        <input type="text" name="cwpf_settings[<?php echo $key ?>]" value="<?php echo $cwpf_settings[$key] ?>" id="<?php echo $key ?>" />
                        <a href="#" class="cwpf-button cwpf_select_image"><?php echo $placeholder ?></a>                    
                    <?php
                    break;

                default:
                    break;
            }
            ?>


        </div>
        <div class="cwpf-description">
            <p class="description"><?php echo $description ?></p>
        </div>
    </div>

</div><!--/ .cwpf-control-section-->
