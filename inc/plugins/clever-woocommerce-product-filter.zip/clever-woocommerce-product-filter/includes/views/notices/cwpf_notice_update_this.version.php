<?php
if (!defined('ABSPATH'))
{
    exit;
}
/*
?>
<div id="message" class="updated woocommerce-message">
    <p>
        <strong style="color:red;">IMPORTANT</strong>: If you migrated from from v.1.0.0 and lower to [this.version] and higher read migration article please!
    </p>
    <p class="submit"><a class="button-primary" href="https://cleveraddon.com/#migrate" target="_blank">Migration article</a> <a class="button-secondary skip" href="<?php echo esc_url(wp_nonce_url(add_query_arg('cwpf_hide_notice', 'cwpf_notice_update_[this.version]'))); ?>">Hide This Notice</a></p>
</div>