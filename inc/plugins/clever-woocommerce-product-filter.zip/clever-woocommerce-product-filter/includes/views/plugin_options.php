<?php if (!defined('ABSPATH')) die('No direct access allowed'); ?>
<?php /*
<!--<div class="cwpf-admin-preloader"></div>-->
<div class="cwpf-admin-preloader">
    <div class="cssload-loader">
        <div class="cssload-inner cssload-one"></div>
        <div class="cssload-inner cssload-two"></div>
        <div class="cssload-inner cssload-three"></div>
    </div>
</div>
*/ ?>
<div class="subsubsub_section">

    <?php
    if (!empty(CWPF_HELPER::$notices)) {
        foreach (CWPF_HELPER::$notices as $key) {
            CWPF_HELPER::show_admin_notice($key);
        }
    }
    ?>


    <?php if (isset($_GET['cwpf_hide_notice'])): ?>
        <script type="text/javascript">
            window.location = "<?php echo admin_url('admin.php?page=wc-settings&tab=cwpf'); ?>";
        </script>
    <?php endif; ?>

    <div style="height: 5px;"></div>

    <section class="cwpf-section">

        <?php if (isset($_GET['settings_saved'])): ?>
            <div class="cwpf-notice"><?php _e("Your settings have been saved.", 'cwpfilter') ?></div>
        <?php endif; ?>


        <h2><a href="http://doc.cleveraddon.com/clever-woocommerce-products-filter"><?php _e("Need help? Check documentation pages here!", 'cwpfilter') ?></a></h2>
        <br />

        <input type="hidden" name="cwpf_settings" value="" />
        <input type="hidden" name="cwpf_settings[items_order]" value="<?php echo(isset($cwpf_settings['items_order']) ? $cwpf_settings['items_order'] : '') ?>" />

        <?php if (version_compare(WOOCOMMERCE_VERSION, CWPF_MIN_WOOCOMMERCE_VERSION, '<')): ?>

            <div id="message" class="error fade"><p><strong><?php _e("ATTENTION! Your version of the woocommerce plugin is too obsolete. There is no warranty for working with CWPF!!", 'cwpfilter') ?></strong></p></div>

        <?php endif; ?>

        <div id="tabs" class="cwpf-tabs cwpf-tabs-style-shape">

            <nav>
                <ul>
                    <li class="tab-current">
                        <a href="#tabs-1">
                            <span><?php _e("Filters", 'cwpfilter') ?></span>
                        </a>
                    </li>
                    <li>
                        <a href="#tabs-2">
                            <span><?php _e("Filter Options", 'cwpfilter') ?></span>
                        </a>
                    </li>
                    <li>
                        <a href="#tabs-3">
                            <span><?php _e("Style", 'cwpfilter') ?></span>
                        </a>
                    </li>
                    <li>
                        <a href="#tabs-4">
                            <span><?php _e("Advanced", 'cwpfilter') ?></span>
                        </a>
                    </li>


                    <?php
                    if (!empty(CWPF_EXT::$includes['applications'])) {
                        foreach (CWPF_EXT::$includes['applications'] as $obj) {
                            $dir1 = $this->get_custom_ext_path() . $obj->folder_name;
                            $dir2 = CWPF_EXT_PATH . $obj->folder_name;
                            $checked1 = CWPF_EXT::is_ext_activated($dir1);
                            $checked2 = CWPF_EXT::is_ext_activated($dir2);
                            if ($checked1 OR $checked2) {
                                do_action('cwpf_print_applications_tabs_' . $obj->folder_name);
                            }
                        }
                    }
                    ?>

                    <li>
                        <a href="#tabs-6">
                            <span><?php _e("Modules", 'cwpfilter') ?></span>
                        </a>
                    </li>
                    <?php /* ?>
                    <li>
                        <a href="#tabs-7">
                            <svg viewBox="0 0 80 60" preserveAspectRatio="none"><use xlink:href="#tabshape"></use></svg>
                            <span><?php _e("Info", 'cwpfilter') ?></span>
                        </a>
                    </li>
                    <?php */ ?>
                </ul>
            </nav>

            <div class="content-wrap">

                <section id="tabs-1" class="content-current">

                    <ul id="cwpf_options">

                        <?php
                        $items_order = array();
                        $taxonomies = $this->get_taxonomies();
                        $taxonomies_keys = array_keys($taxonomies);
                        if (isset($cwpf_settings['items_order']) AND ! empty($cwpf_settings['items_order'])) {
                            $items_order = explode(',', $cwpf_settings['items_order']);
                        } else {
                            $items_order = array_merge($this->items_keys, $taxonomies_keys);
                        }

//*** lets check if we have new taxonomies added in woocommerce or new item
                        foreach (array_merge($this->items_keys, $taxonomies_keys) as $key) {
                            if (!in_array($key, $items_order)) {
                                $items_order[] = $key;
                            }
                        }

//lets print our items and taxonomies
                        foreach ($items_order as $key) {
                            if (in_array($key, $this->items_keys)) {
                                cwpf_print_item_by_key($key, $cwpf_settings);
                            } else {
                                if (isset($taxonomies[$key])) {
                                    cwpf_print_tax($key, $taxonomies[$key], $cwpf_settings);
                                }
                            }
                        }
                        ?>
                    </ul>

                    <input type="button" class="cwpf_reset_order" style="float: right;" value="<?php _e('Reset items order', 'cwpfilter') ?>" />

                    <div class="clear"></div>

                </section>

                <section id="tabs-2">

                    <?php woocommerce_admin_fields($this->get_options()); ?>

                </section>

                <section id="tabs-3">

                    <?php
                    $skins = array(
                        'none' => array('none'),
                        'flat' => array(
                            'flat_aero',
                            'flat_blue',
                            'flat_flat',
                            'flat_green',
                            'flat_grey',
                            'flat_orange',
                            'flat_pink',
                            'flat_purple',
                            'flat_red',
                            'flat_yellow'
                        ),
                        'minimal' => array(
                            'minimal_aero',
                            'minimal_blue',
                            'minimal_green',
                            'minimal_grey',
                            'minimal_minimal',
                            'minimal_orange',
                            'minimal_pink',
                            'minimal_purple',
                            'minimal_red',
                            'minimal_yellow'
                        ),
                        'square' => array(
                            'square_aero',
                            'square_blue',
                            'square_green',
                            'square_grey',
                            'square_orange',
                            'square_pink',
                            'square_purple',
                            'square_red',
                            'square_yellow',
                            'square_square'
                        )
                    );
                    $skin = 'none';
                    if (isset($cwpf_settings['icheck_skin'])) {
                        $skin = $cwpf_settings['icheck_skin'];
                    }
                    ?>

                    <div class="cwpf-control-section">

                        <h4><?php _e('Radio and checkboxes skin', 'cwpfilter') ?></h4>

                        <div class="cwpf-control-container">
                            <div class="cwpf-control">

                                <select name="cwpf_settings[icheck_skin]" class="chosen_select">
                                    <?php foreach ($skins as $key => $schemes) : ?>
                                        <optgroup label="<?php echo $key ?>">
                                            <?php foreach ($schemes as $scheme) : ?>
                                                <option value="<?php echo $scheme; ?>" <?php if ($skin == $scheme): ?>selected="selected"<?php endif; ?>><?php echo $scheme; ?></option>
                                            <?php endforeach; ?>
                                        </optgroup>
                                    <?php endforeach; ?>
                                </select>

                            </div>
                            <div class="cwpf-description"></div>
                        </div>

                    </div><!--/ .cwpf-control-section-->

                    <?php
                    $skins = array(
                        'default' => __('Default', 'cwpfilter'),
                        'plainoverlay' => __('Plainoverlay - CSS', 'cwpfilter'),
                        'loading-balls' => __('Loading balls - SVG', 'cwpfilter'),
                        'loading-bars' => __('Loading bars - SVG', 'cwpfilter'),
                        'loading-bubbles' => __('Loading bubbles - SVG', 'cwpfilter'),
                        'loading-cubes' => __('Loading cubes - SVG', 'cwpfilter'),
                        'loading-cylon' => __('Loading cyclone - SVG', 'cwpfilter'),
                        'loading-spin' => __('Loading spin - SVG', 'cwpfilter'),
                        'loading-spinning-bubbles' => __('Loading spinning bubbles - SVG', 'cwpfilter'),
                        'loading-spokes' => __('Loading spokes - SVG', 'cwpfilter'),
                    );
                    if (!isset($cwpf_settings['overlay_skin'])) {
                        $cwpf_settings['overlay_skin'] = 'default';
                    }
                    $skin = $cwpf_settings['overlay_skin'];
                    ?>


                    <div class="cwpf-control-section">

                        <h4><?php _e('Overlay skins', 'cwpfilter') ?></h4>

                        <div class="cwpf-control-container">
                            <div class="cwpf-control">

                                <select name="cwpf_settings[overlay_skin]" class="chosen_select">
                                    <?php foreach ($skins as $scheme => $title) : ?>
                                        <option value="<?php echo $scheme; ?>" <?php if ($skin == $scheme): ?>selected="selected"<?php endif; ?>><?php echo $title; ?></option>
                                    <?php endforeach; ?>
                                </select>

                            </div>
                            <div class="cwpf-description">

                            </div>
                        </div>

                    </div><!--/ .cwpf-control-section-->

                    <?php
                    if (!isset($cwpf_settings['overlay_skin_bg_img'])) {
                        $cwpf_settings['overlay_skin_bg_img'] = '';
                    }
                    $overlay_skin_bg_img = $cwpf_settings['overlay_skin_bg_img'];
                    ?>


                    <div class="cwpf-control-section" <?php if ($skin == 'default'): ?>style="display: none;"<?php endif; ?>>

                        <h4><?php _e('Overlay image background', 'cwpfilter') ?></h4>

                        <div class="cwpf-control-container">
                            <div class="cwpf-control cwpf-upload-style-wrap">

                                <input type="text" name="cwpf_settings[overlay_skin_bg_img]" value="<?php echo $overlay_skin_bg_img ?>" />

                                <a href="#" class="cwpf-button cwpf_select_image"><?php _e('Select Image', 'cwpfilter') ?></a><br />

                                <div <?php if ($skin != 'plainoverlay'): ?>style="display: none;"<?php endif; ?>>
                                    <br />
                                    <?php
                                    if (!isset($cwpf_settings['plainoverlay_color'])) {
                                        $cwpf_settings['plainoverlay_color'] = '';
                                    }
                                    $plainoverlay_color = $cwpf_settings['plainoverlay_color'];
                                    ?>

                                    <h4<?php _e('Plainoverlay color', 'cwpfilter') ?></h4>
                                    <input type="text" name="cwpf_settings[plainoverlay_color]" value="<?php echo $plainoverlay_color ?>" id="cwpf_color_picker_plainoverlay_color" class="cwpf-color-picker" />

                                </div>

                            </div>
                            <div class="cwpf-description">
                                <p class="description">
                                    <?php _e('Example', 'cwpfilter') ?>: <?php echo CWPF_IMG_LINK ?>overlay_bg.png
                                </p>
                            </div>
                        </div>

                    </div><!--/ .cwpf-control-section-->


                    <div class="cwpf-control-section" <?php if ($skin != 'default'): ?>style="display: none;"<?php endif; ?>>

                        <h4><?php _e('Loading word', 'cwpfilter') ?></h4>

                        <div class="cwpf-control-container">

                            <div class="cwpf-control cwpf-upload-style-wrap">

                                <?php
                                if (!isset($cwpf_settings['default_overlay_skin_word'])) {
                                    $cwpf_settings['default_overlay_skin_word'] = '';
                                }
                                $default_overlay_skin_word = $cwpf_settings['default_overlay_skin_word'];
                                ?>



                                <input type="text" name="cwpf_settings[default_overlay_skin_word]" value="<?php echo $default_overlay_skin_word ?>" />


                            </div>
                            <div class="cwpf-description">
                                <p class="description">
                                    <?php _e('Word while searching is going on front when "Overlay skins" is default.', 'cwpfilter') ?>
                                </p>
                            </div>
                        </div>
                    </div><!--/ .cwpf-control-section-->



                    <div class="cwpf-control-section">

                        <h4><?php _e('Use chosen', 'cwpfilter') ?></h4>

                        <div class="cwpf-control-container">

                            <div class="cwpf-control cwpf-upload-style-wrap">

                                <?php
                                $chosen_selects = array(
                                    0 => __('No', 'cwpfilter'),
                                    1 => __('Yes', 'cwpfilter')
                                );

                                if (!isset($cwpf_settings['use_chosen'])) {
                                    $cwpf_settings['use_chosen'] = 1;
                                }
                                $chosen_select = $cwpf_settings['use_chosen'];
                                ?>

                                <div class="select-wrap">
                                    <select name="cwpf_settings[use_chosen]" class="chosen_select">
                                        <?php foreach ($chosen_selects as $key => $value) : ?>
                                            <option value="<?php echo $key; ?>" <?php if ($chosen_select == $key): ?>selected="selected"<?php endif; ?>><?php echo $value; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>


                            </div>
                            <div class="cwpf-description">
                                <p class="description">
                                    <?php _e('Use chosen javascript library on the front of your site for drop-downs.', 'cwpfilter') ?>
                                </p>
                            </div>
                        </div>
                    </div><!--/ .cwpf-control-section-->


                    <div class="cwpf-control-section">

                        <h4><?php _e('Use beauty scroll', 'cwpfilter') ?></h4>

                        <div class="cwpf-control-container">

                            <div class="cwpf-control cwpf-upload-style-wrap">

                                <?php
                                $use_beauty_scroll = array(
                                    0 => __('No', 'cwpfilter'),
                                    1 => __('Yes', 'cwpfilter')
                                );

                                if (!isset($cwpf_settings['use_beauty_scroll'])) {
                                    $cwpf_settings['use_beauty_scroll'] = 0;
                                }
                                $use_scroll = $cwpf_settings['use_beauty_scroll'];
                                ?>

                                <div class="select-wrap">
                                    <select name="cwpf_settings[use_beauty_scroll]" class="chosen_select">
                                        <?php foreach ($use_beauty_scroll as $key => $value) : ?>
                                            <option value="<?php echo $key; ?>" <?php if ($use_scroll == $key): ?>selected="selected"<?php endif; ?>><?php echo $value; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>


                            </div>
                            <div class="cwpf-description">
                                <p class="description">
                                    <?php _e('Use beauty scroll when you apply max height for taxonomy block on the front', 'cwpfilter') ?>
                                </p>
                            </div>
                        </div>
                    </div><!--/ .cwpf-control-section-->


                    <div class="cwpf-control-section">

                        <h4><?php _e('Range-slider skin', 'cwpfilter') ?></h4>

                        <div class="cwpf-control-container">

                            <div class="cwpf-control cwpf-upload-style-wrap">

                                <?php
                                $skins = array(
                                    'skinNice' => 'skinNice',
                                    'skinFlat' => 'skinFlat',
                                    'skinHTML5' => 'skinHTML5',
                                    'skinModern' => 'skinModern',
                                    'skinSimple' => 'skinSimple'
                                );

                                if (!isset($cwpf_settings['ion_slider_skin'])) {
                                    $cwpf_settings['ion_slider_skin'] = 'skinNice';
                                }
                                $skin = $cwpf_settings['ion_slider_skin'];
                                ?>

                                <div class="select-wrap">
                                    <select name="cwpf_settings[ion_slider_skin]" class="chosen_select">
                                        <?php foreach ($skins as $key => $value) : ?>
                                            <option value="<?php echo $key; ?>" <?php if ($skin == $key): ?>selected="selected"<?php endif; ?>><?php echo $value; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>


                            </div>
                            <div class="cwpf-description">
                                <p class="description">
                                    <?php _e('Ion-Range slider js lib skin for range-sliders of the plugin', 'cwpfilter') ?>
                                </p>
                            </div>
                        </div>
                    </div><!--/ .cwpf-control-section-->

                    <div class="cwpf-control-section">

                        <h4><?php _e('Use tooltip', 'cwpfilter') ?></h4>

                        <div class="cwpf-control-container">

                            <div class="cwpf-control cwpf-upload-style-wrap">

                                <?php
                                $tooltip_selects = array(
                                    0 => __('No', 'cwpfilter'),
                                    1 => __('Yes', 'cwpfilter')
                                );

                                if (!isset($cwpf_settings['use_tooltip'])) {
                                    $cwpf_settings['use_tooltip'] = 1;
                                }
                                $tooltip_select = $cwpf_settings['use_tooltip'];
                                ?>

                                <div class="select-wrap">
                                    <select name="cwpf_settings[use_tooltip]" class="chosen_select">
                                        <?php foreach ($tooltip_selects as $key => $value) : ?>
                                            <option value="<?php echo $key; ?>" <?php if ($tooltip_select == $key): ?>selected="selected"<?php endif; ?>><?php echo $value; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>


                            </div>
                            <div class="cwpf-description">
                                <p class="description">
                                    <?php _e('Use tooltip library on the front of your site. Possible to disable it here if any scripts conflicts on the site front.', 'cwpfilter') ?>
                                </p>
                            </div>
                        </div>
                    </div><!--/ .cwpf-control-section-->

                    <?php if (get_option('cwpf_set_automatically')): ?>
                        <div class="cwpf-control-section">

                            <h4><?php _e('Hide auto filter by default', 'cwpfilter') ?></h4>

                            <div class="cwpf-control-container">
                                <div class="cwpf-control">

                                    <?php
                                    $cwpf_auto_hide_button = array(
                                        0 => __('No', 'cwpfilter'),
                                        1 => __('Yes', 'cwpfilter')
                                    );
                                    if (!isset($cwpf_settings['cwpf_auto_hide_button'])) {
                                        $cwpf_settings['cwpf_auto_hide_button'] = 0;
                                    }
                                    $cwpf_auto_hide_button_val = $cwpf_settings['cwpf_auto_hide_button'];
                                    ?>

                                    <select name="cwpf_settings[cwpf_auto_hide_button]" class="chosen_select">
                                        <?php foreach ($cwpf_auto_hide_button as $v => $n) : ?>
                                            <option value="<?php echo $v; ?>" <?php if ($cwpf_auto_hide_button_val == $v): ?>selected="selected"<?php endif; ?>><?php echo $n; ?></option>
                                        <?php endforeach; ?>
                                    </select>

                                </div>
                                <div class="cwpf-description">
                                    <p class="description"><?php _e('If in options tab option "Set filter automatically" is "Yes" you can hide filter and show hide/show button instead of it.', 'cwpfilter') ?></p>
                                </div>
                            </div>

                        </div><!--/ .cwpf-control-section-->

                        <div class="cwpf-control-section">

                            <h4><?php _e('Skins for the auto filter', 'cwpfilter') ?></h4>

                            <div class="cwpf-control-container">
                                <div class="cwpf-control">

                                    <?php
                                    $cwpf_auto_filter_skins = array(
                                        '' => __('Default', 'cwpfilter'),
                                        'flat_grey cwpf_auto_3_columns' => __('Flat grey (3columns)', 'cwpfilter'),
                                        'flat_dark cwpf_auto_3_columns' => __('Flat dark (3columns)', 'cwpfilter'),
                                        'flat_grey cwpf_auto_2_columns' => __('Flat grey (2columns)', 'cwpfilter'),
                                        'flat_dark cwpf_auto_2_columns' => __('Flat dark (2columns)', 'cwpfilter'),
                                        'flat_grey cwpf_auto_1_columns' => __('Flat grey (1column)', 'cwpfilter'),
                                        'flat_dark cwpf_auto_1_columns' => __('Flat dark (1column)', 'cwpfilter'),
                                        'flat_grey cwpf_auto_4_columns' => __('Flat grey (4columns) without sidebar*', 'cwpfilter'),
                                        'flat_dark cwpf_auto_4_columns' => __('Flat dark (4columns) without sidebar*', 'cwpfilter'),
                                    );
                                    if (!isset($cwpf_settings['cwpf_auto_filter_skins'])) {
                                        $cwpf_settings['cwpf_auto_filter_skins'] = "";
                                    }
                                    $cwpf_auto_filter_skins_val = $cwpf_settings['cwpf_auto_filter_skins'];
                                    ?>

                                    <select name="cwpf_settings[cwpf_auto_filter_skins]" class="chosen_select">
                                        <?php foreach ($cwpf_auto_filter_skins as $v => $n) : ?>
                                            <option value="<?php echo $v; ?>" <?php if ($cwpf_auto_filter_skins_val == $v): ?>selected="selected"<?php endif; ?>><?php echo $n; ?></option>
                                        <?php endforeach; ?>
                                    </select>

                                </div>
                                <div class="cwpf-description">
                                    <p class="description"><?php _e('Skins for the auto-filter which appears on the shop page if in tab Options enabled Set filter automatically', 'cwpfilter') ?></p>
                                </div>
                            </div>

                        </div><!--/ .cwpf-control-section-->
                    <?php endif; ?>

                    <?php
                    if (!isset($cwpf_settings['cwpf_tooltip_img'])) {
                        $cwpf_settings['cwpf_tooltip_img'] = '';
                    }
                    ?>
                    <div class="cwpf-control-section">

                        <h4><?php _e('Tooltip icon', 'cwpfilter') ?></h4>

                        <div class="cwpf-control-container">
                            <div class="cwpf-control cwpf-upload-style-wrap">
                                <input type="text" name="cwpf_settings[cwpf_tooltip_img]" value="<?php echo $cwpf_settings['cwpf_tooltip_img'] ?>" />
                                <a href="#" class="cwpf-button cwpf_select_image"><?php _e('Select Image', 'cwpfilter') ?></a>
                            </div>
                            <div class="cwpf-description">
                                <p class="description"><?php _e('Image which displayed for tooltip', 'cwpfilter') ?></p>
                            </div>
                        </div>

                    </div><!--/ .cwpf-control-section-->

                    <?php
                    if (!isset($cwpf_settings['cwpf_auto_hide_button_img'])) {
                        $cwpf_settings['cwpf_auto_hide_button_img'] = '';
                    }

                    if (!isset($cwpf_settings['cwpf_auto_hide_button_txt'])) {
                        $cwpf_settings['cwpf_auto_hide_button_txt'] = '';
                    }
                    ?>

                    <div class="cwpf-control-section">

                        <h4><?php _e('Auto filter close/open image', 'cwpfilter') ?></h4>

                        <div class="cwpf-control-container">
                            <div class="cwpf-control cwpf-upload-style-wrap">
                                <input type="text" name="cwpf_settings[cwpf_auto_hide_button_img]" value="<?php echo $cwpf_settings['cwpf_auto_hide_button_img'] ?>" />
                                <a href="#" class="cwpf-button cwpf_select_image"><?php _e('Select Image', 'cwpfilter') ?></a>
                            </div>
                            <div class="cwpf-description">
                                <p class="description"><?php _e('Image which displayed instead filter while it is closed if selected. Write "none" here if you want to use text only!', 'cwpfilter') ?></p>
                            </div>
                        </div>

                    </div><!--/ .cwpf-control-section-->


                    <div class="cwpf-control-section">

                        <h4><?php _e('Auto filter close/open text', 'cwpfilter') ?></h4>

                        <div class="cwpf-control-container">
                            <div class="cwpf-control">
                                <input type="text" name="cwpf_settings[cwpf_auto_hide_button_txt]" value="<?php echo $cwpf_settings['cwpf_auto_hide_button_txt'] ?>" />
                            </div>
                            <div class="cwpf-description">
                                <p class="description"><?php _e('Text which displayed instead filter while it is closed if selected.', 'cwpfilter') ?></p>
                            </div>
                        </div>

                    </div><!--/ .cwpf-control-section-->

                    <div class="cwpf-control-section">

                        <h4><?php _e('Image for subcategories [<i>open</i>]', 'cwpfilter') ?></h4>

                        <div class="cwpf-control-container">
                            <div class="cwpf-control cwpf-upload-style-wrap">
                                <input type="text" name="cwpf_settings[cwpf_auto_subcats_plus_img]" value="<?php echo(isset($cwpf_settings['cwpf_auto_subcats_plus_img']) ? $cwpf_settings['cwpf_auto_subcats_plus_img'] : '') ?>" />
                                <a href="#" class="cwpf-button cwpf_select_image"><?php _e('Select Image', 'cwpfilter') ?></a>
                            </div>
                            <div class="cwpf-description">
                                <p class="description"><?php _e('Image when you select in tab Options "Hide childs in checkboxes and radio". By default it is green cross.', 'cwpfilter') ?></p>
                            </div>
                        </div>

                        <h4><?php _e('Image for subcategories [<i>close</i>]', 'cwpfilter') ?></h4>

                        <div class="cwpf-control-container">
                            <div class="cwpf-control cwpf-upload-style-wrap">
                                <input type="text" name="cwpf_settings[cwpf_auto_subcats_minus_img]" value="<?php echo(isset($cwpf_settings['cwpf_auto_subcats_minus_img']) ? $cwpf_settings['cwpf_auto_subcats_minus_img'] : '') ?>" />
                                <a href="#" class="cwpf-button cwpf_select_image"><?php _e('Select Image', 'cwpfilter') ?></a>
                            </div>
                            <div class="cwpf-description">
                                <p class="description"><?php _e('Image when you select in tab Options "Hide childs in checkboxes and radio". By default it is green minus.', 'cwpfilter') ?></p>
                            </div>
                        </div>

                    </div><!--/ .cwpf-control-section-->


                    <div class="cwpf-control-section">

                        <h4><?php _e('Toggle block type', 'cwpfilter') ?></h4>

                        <div class="cwpf-control-container">

                            <div class="cwpf-control cwpf-upload-style-wrap">

                                <?php
                                $toggle_types = array(
                                    'text' => __('Text', 'cwpfilter'),
                                    'image' => __('Images', 'cwpfilter')
                                );

                                if (!isset($cwpf_settings['toggle_type'])) {
                                    $cwpf_settings['toggle_type'] = 'text';
                                }
                                $toggle_type = $cwpf_settings['toggle_type'];
                                ?>

                                <div class="select-wrap">
                                    <select name="cwpf_settings[toggle_type]" class="chosen_select" id="toggle_type">
                                        <?php foreach ($toggle_types as $key => $value) : ?>
                                            <option value="<?php echo $key; ?>" <?php if ($toggle_type == $key): ?>selected="selected"<?php endif; ?>><?php echo $value; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>


                            </div>
                            <div class="cwpf-description">
                                <p class="description">
                                    <?php _e('Type of the toogle on the front for block of html-items as: radio, checkbox .... Works only if the block title is not hidden!', 'cwpfilter') ?>
                                </p>
                            </div>
                        </div>

                        <div class="toggle_type_text" <?php if ($toggle_type == 'image'): ?>style="display: none;"<?php endif; ?>>

                            <h4><?php _e('Text for block toggle [<i>opened</i>]', 'cwpfilter') ?></h4>

                            <div class="cwpf-control-container">
                                <div class="cwpf-control cwpf-upload-style-wrap">
                                    <?php
                                    if (!isset($cwpf_settings['toggle_opened_text'])) {
                                        $cwpf_settings['toggle_opened_text'] = '';
                                    }
                                    ?>
                                    <input type="text" name="cwpf_settings[toggle_opened_text]" value="<?php echo $cwpf_settings['toggle_opened_text'] ?>" />
                                </div>
                                <div class="cwpf-description">
                                    <p class="description"><?php _e('Toggle text for opened html-items block. Example: close. By default applied sign minus "-"', 'cwpfilter') ?></p>
                                </div>
                            </div>

                            <h4><?php _e('Text for block toggle [<i>closed</i>]', 'cwpfilter') ?></h4>

                            <div class="cwpf-control-container">
                                <div class="cwpf-control cwpf-upload-style-wrap">
                                    <?php
                                    if (!isset($cwpf_settings['toggle_closed_text'])) {
                                        $cwpf_settings['toggle_closed_text'] = '';
                                    }
                                    ?>
                                    <input type="text" name="cwpf_settings[toggle_closed_text]" value="<?php echo $cwpf_settings['toggle_closed_text'] ?>" />
                                </div>
                                <div class="cwpf-description">
                                    <p class="description"><?php _e('Toggle text for closed html-items block. Example: open. By default applied sign plus "+"', 'cwpfilter') ?></p>
                                </div>
                            </div>

                        </div>


                        <div class="toggle_type_image" <?php if ($toggle_type == 'text'): ?>style="display: none;"<?php endif; ?>>
                            <h4><?php _e('Image for block toggle [<i>opened</i>]', 'cwpfilter') ?></h4>

                            <div class="cwpf-control-container">
                                <div class="cwpf-control cwpf-upload-style-wrap">
                                    <?php
                                    if (!isset($cwpf_settings['toggle_opened_image'])) {
                                        $cwpf_settings['toggle_opened_image'] = '';
                                    }
                                    ?>
                                    <input type="text" name="cwpf_settings[toggle_opened_image]" value="<?php echo(isset($cwpf_settings['toggle_opened_image']) ? $cwpf_settings['toggle_opened_image'] : '') ?>" />
                                    <a href="#" class="cwpf-button cwpf_select_image"><?php _e('Select Image', 'cwpfilter') ?></a>
                                </div>
                                <div class="cwpf-description">
                                    <p class="description"><?php _e('Any image for opened html-items block 20x20', 'cwpfilter') ?></p>
                                </div>
                            </div>


                            <h4><?php _e('Image for block toggle [<i>closed</i>]', 'cwpfilter') ?></h4>

                            <div class="cwpf-control-container">
                                <div class="cwpf-control cwpf-upload-style-wrap">
                                    <?php
                                    if (!isset($cwpf_settings['toggle_closed_image'])) {
                                        $cwpf_settings['toggle_closed_image'] = '';
                                    }
                                    ?>
                                    <input type="text" name="cwpf_settings[toggle_closed_image]" value="<?php echo(isset($cwpf_settings['toggle_closed_image']) ? $cwpf_settings['toggle_closed_image'] : '') ?>" />
                                    <a href="#" class="cwpf-button cwpf_select_image"><?php _e('Select Image', 'cwpfilter') ?></a>
                                </div>
                                <div class="cwpf-description">
                                    <p class="description"><?php _e('Any image for closed html-items block 20x20', 'cwpfilter') ?></p>
                                </div>
                            </div>
                        </div>


                    </div><!--/ .cwpf-control-section-->

                    <?php
                    if (!isset($cwpf_settings['custom_front_css'])) {
                        $cwpf_settings['custom_front_css'] = '';
                    }
                    ?>

                    <div class="cwpf-control-section">

                        <h4><?php _e('Custom front css styles file link', 'cwpfilter') ?></h4>

                        <div class="cwpf-control-container">
                            <div class="cwpf-control">
                                <input type="text" name="cwpf_settings[custom_front_css]" value="<?php echo $cwpf_settings['custom_front_css'] ?>" />
                            </div>
                            <div class="cwpf-description">
                                <p class="description"><?php _e('For developers who want to rewrite front css of the plugin front side. You are need to know CSS for this!', 'cwpfilter') ?></p>
                            </div>
                        </div>

                    </div><!--/ .cwpf-control-section-->

                    <?php do_action('cwpf_print_design_additional_options'); ?>

                </section>

                <section id="tabs-4">

                    <div class="cwpf-tabs cwpf-tabs-style-line">

                        <nav>
                            <ul>
                                <li>
                                    <a href="#tabs-41">
                                        <span><?php _e("Code", 'cwpfilter') ?></span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#tabs-42">
                                        <span><?php _e("Filter Options", 'cwpfilter') ?></span>
                                    </a>
                                </li>
                            </ul>
                        </nav>

                        <div class="content-wrap">

                            <section id="tabs-41">

                                <table class="form-table">

                                    <tr>
                                        <th scope="row"><label for="custom_css_code"><?php _e('Custom CSS code', 'cwpfilter') ?></label></th>

                                        <td>
                                            <textarea class="wide cwpf_custom_css" id="custom_css_code" style="height: 300px; width: 100%;" name="cwpf_settings[custom_css_code]"><?php echo(isset($this->settings['custom_css_code']) ? stripcslashes($this->settings['custom_css_code']) : '') ?></textarea>
                                            <p class="description"><?php _e("If you are need to customize something and you don't want to lose your changes after update", 'cwpfilter') ?></p>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row"><label for="js_after_ajax_done"><?php _e('JavaScript code after AJAX is done', 'cwpfilter') ?></label></th>
                                        <td>
                                            <textarea class="wide cwpf_custom_css" id="js_after_ajax_done" style="height: 300px; width: 100%;" name="cwpf_settings[js_after_ajax_done]"><?php echo(isset($this->settings['js_after_ajax_done']) ? stripcslashes($this->settings['js_after_ajax_done']) : '') ?></textarea>
                                            <p class="description"><?php _e('Use it when you are need additional action after AJAX redraw your products in shop page or in page with shortcode! For use when you need additional functionality after AJAX redraw of your products on the shop page or on pages with shortcodes.', 'cwpfilter') ?></p>
                                        </td>
                                    </tr>

                                    <tr>
                                        <th scope="row"><label for="init_only_on"><?php _e('Init plugin on the next site pages only ', 'cwpfilter') ?></label></th>
                                        <td>
                                            <div class="cwpf-control-section">
                                                <div class="cwpf-control-container">
                                                    <div class="cwpf-control">

                                                        <?php
                                                        $init_only_on_r = array(
                                                            0 => __("Yes", 'cwpfilter'),
                                                            1 => __("No", 'cwpfilter')
                                                        );
                                                        ?>

                                                        <?php
                                                        if (!isset($cwpf_settings['init_only_on_reverse']) OR empty($cwpf_settings['init_only_on_reverse'])) {
                                                            $cwpf_settings['init_only_on_reverse'] = 0;
                                                        }
                                                        ?>
                                                        <div class="select-wrap">
                                                            <select name="cwpf_settings[init_only_on_reverse]">
                                                                <?php foreach ($init_only_on_r as $key => $value) : ?>
                                                                    <option value="<?php echo $key; ?>" <?php if ($cwpf_settings['init_only_on_reverse'] == $key): ?>selected="selected"<?php endif; ?>><?php echo $value; ?></option>
                                                                <?php endforeach; ?>
                                                            </select>
                                                        </div>

                                                    </div>
                                                    <div class="cwpf-description" style="margin-top: 0;">
                                                        <p class="description"><?php _e("Reverse: deactivate plugin on the next site pages only", 'cwpfilter') ?></p>
                                                    </div>
                                                </div>

                                            </div><!--/ .cwpf-control-section-->



                                            <?php
                                            if (!isset($this->settings['init_only_on'])) {
                                                $this->settings['init_only_on'] = '';
                                            }
                                            ?>
                                            <textarea class="wide cwpf_custom_css" id="init_only_on" style="height: 300px; width: 100%;" name="cwpf_settings[init_only_on]"><?php echo stripcslashes(trim($this->settings['init_only_on'])) ?></textarea>
                                            <p class="description"><?php _e('This option enables or disables initialization of the plugin on all pages of the site except links and link-masks in the textarea. One row - one link (or link-mask)! Example of link: http://site.com/ajaxed-search-7. Example of link-mask: product-category! Leave it empty to allow the plugin initialization on all pages of the site!', 'cwpfilter') ?></p>
                                        </td>
                                    </tr>


                                    <?php if (class_exists('SitePress') OR class_exists('Polylang')): ?>
                                        <tr>
                                            <th scope="row"><label for="wpml_tax_labels">
                                                    <?php _e('WPML taxonomies labels translations', 'cwpfilter') ?> <img class="help_tip" data-tip="Syntax:
                                                         es:Locations^Ubicaciones
                                                         es:Size^Tamaño
                                                         de:Locations^Lage
                                                         de:Size^Größe" src="<?php echo WP_PLUGIN_URL ?>/woocommerce/assets/images/help.png" height="16" width="16" />
                                                </label></th>
                                            <td>

                                                <?php
                                                $wpml_tax_labels = "";
                                                if (isset($cwpf_settings['wpml_tax_labels']) AND is_array($cwpf_settings['wpml_tax_labels'])) {
                                                    foreach ($cwpf_settings['wpml_tax_labels'] as $lang => $words) {
                                                        if (!empty($words) AND is_array($words)) {
                                                            foreach ($words as $key_word => $translation) {
                                                                $wpml_tax_labels .= $lang . ':' . $key_word . '^' . $translation . PHP_EOL;
                                                            }
                                                        }
                                                        //$first_value = reset($value); // First Element's Value
                                                        //$first_key = key($value); // First Element's Key
                                                    }
                                                }
                                                ?>

                                                <textarea class="wide cwpf_custom_css" id="wpml_tax_labels" style="height: 300px; width: 100%;" name="cwpf_settings[wpml_tax_labels]"><?php echo $wpml_tax_labels ?></textarea>
                                                <p class="description"><?php _e('Use it if you can not translate your custom taxonomies labels and attributes labels by another plugins.', 'cwpfilter') ?></p>

                                            </td>
                                        </tr>
                                    <?php endif; ?>

                                </table>

                            </section>

                            <section id="tabs-42">

                                <div class="cwpf-control-section">

                                    <h5><?php _e('Search slug', 'cwpfilter') ?></h5>

                                    <div class="cwpf-control-container">
                                        <div class="cwpf-control">

                                            <?php
                                            if (!isset($cwpf_settings['scwpf_search_slug'])) {
                                                $cwpf_settings['scwpf_search_slug'] = '';
                                            }
                                            ?>

                                            <input placeholder="scwpf" type="text" name="cwpf_settings[scwpf_search_slug]" value="<?php echo $cwpf_settings['scwpf_search_slug'] ?>" id="scwpf_search_slug" />

                                        </div>
                                        <div class="cwpf-description">
                                            <p class="description"><?php _e('If you do not like search key "scwpf" in the search link you can replace it by your own word. But be care to avoid conflicts with any themes and plugins, + never define it as symbol "s".<br /> Not understood? Simply do not touch it!', 'cwpfilter') ?></p>
                                        </div>
                                    </div>

                                </div><!--/ .cwpf-control-section-->

                                <div class="cwpf-control-section">

                                    <h5><?php _e('Products per page', 'cwpfilter') ?></h5>

                                    <div class="cwpf-control-container">
                                        <div class="cwpf-control">
                                            <?php
                                            if (!isset($cwpf_settings['per_page'])) {
                                                $cwpf_settings['per_page'] = -1;
                                            }
                                            ?>

                                            <input type="text" name="cwpf_settings[per_page]" value="<?php echo $cwpf_settings['per_page'] ?>" id="per_page" />
                                        </div>
                                        <div class="cwpf-description">
                                            <p class="description"><?php _e('Products per page when searching is going only. Set here -1 to prevent pagination managing from here!', 'cwpfilter') ?></p>
                                        </div>
                                    </div>

                                </div><!--/ .cwpf-control-section-->

                                <div class="cwpf-control-section">

                                    <h5><?php _e("Optimize loading of CWPF JavaScript files", 'cwpfilter') ?></h5>

                                    <div class="cwpf-control-container">
                                        <div class="cwpf-control">

                                            <?php
                                            $optimize_js_files = array(
                                                0 => __("No", 'cwpfilter'),
                                                1 => __("Yes", 'cwpfilter')
                                            );
                                            ?>

                                            <?php
                                            if (!isset($cwpf_settings['optimize_js_files']) OR empty($cwpf_settings['optimize_js_files'])) {
                                                $cwpf_settings['optimize_js_files'] = 0;
                                            }
                                            ?>

                                            <select name="cwpf_settings[optimize_js_files]">
                                                <?php foreach ($optimize_js_files as $key => $value) : ?>
                                                    <option value="<?php echo $key; ?>" <?php if ($cwpf_settings['optimize_js_files'] == $key): ?>selected="selected"<?php endif; ?>><?php echo $value; ?></option>
                                                <?php endforeach; ?>
                                            </select>


                                        </div>
                                        <div class="cwpf-description">
                                            <p class="description"><?php _e("This option place CWPF JavaScript files on the site footer. Use it for page loading optimization. Be care with this option, and always after enabling of it test your site frontend!", 'cwpfilter') ?></p>
                                        </div>
                                    </div>

                                </div><!--/ .cwpf-control-section-->

                                <div class="cwpf-control-section">

                                    <h5><?php _e('Override no products found content', 'cwpfilter') ?></h5>

                                    <div class="cwpf-control-container">
                                        <div class="cwpf-control">

                                            <?php
                                            if (!isset($cwpf_settings['override_no_products'])) {
                                                $cwpf_settings['override_no_products'] = '';
                                            }
                                            ?>

                                            <textarea name="cwpf_settings[override_no_products]" id="override_no_products" ><?php echo $cwpf_settings['override_no_products'] ?></textarea>

                                        </div>
                                        <div class="cwpf-description">
                                            <p class="description"><?php _e('Place in which you can paste text or/and any shortcodes which will be displayed when customer will not find any products by his search criterias. Example:', 'cwpfilter') ?> <i style="color: orangered;">&lt;center&gt;&lt;h2>Where are the products?&lt;/h2&gt;&lt;/center&gt;&lt;h4&gt;Perhaps you will like next products&lt;/h4&gt;[recent_products limit="3" columns="4" ]</i> (<?php _e('do not use shortcodes here in turbo mode', 'cwpfilter') ?>)</p>
                                        </div>
                                    </div>

                                </div><!--/ .cwpf-control-section-->

                                <!--
                                <div class="cwpf-control-section">

                                    <h5><?php _e("Storage type", 'cwpfilter') ?></h5>

                                    <div class="cwpf-control-container">
                                        <div class="cwpf-control">

                                <?php
                                $storage_types = array(
                                    'session' => 'session',
                                    'transient' => 'transient'
                                );
                                ?>

                                <?php
                                if (!isset($cwpf_settings['storage_type']) OR empty($cwpf_settings['storage_type'])) {
                                    $cwpf_settings['storage_type'] = 'transient';
                                }
                                ?>
                                            <div class="select-wrap">
                                                <select name="cwpf_settings[storage_type]">
                                <?php foreach ($storage_types as $key => $value) : ?>
                                                                                                                                                                                                                                                                            <option value="<?php echo $key; ?>" <?php if ($cwpf_settings['storage_type'] == $key): ?>selected="selected"<?php endif; ?>><?php echo $value; ?></option>
                                <?php endforeach; ?>
                                                </select>
                                            </div>

                                        </div>
                                        <div class="cwpf-description">
                                            <p class="description"><?php _e("If you have troubles with relevant terms recount on categories pages with dynamic recount for not logged in users - select transient.", 'cwpfilter') ?></p>
                                        </div>
                                    </div>

                                </div> -->
                                <div class="cwpf-control-section cwpf_premium_only">
                                    <?php
                                    $show_images_by_attr = array(
                                        0 => __("No", 'cwpfilter'),
                                        1 => __("Yes", 'cwpfilter')
                                    );
                                    if (!isset($cwpf_settings['show_images_by_attr_show']) OR empty($cwpf_settings['show_images_by_attr_show'])) {
                                        $cwpf_settings['show_images_by_attr_show'] = 0;
                                    }
                                    ?>

                                    <h5><?php _e("Show image of variation", 'cwpfilter') ?></h5>

                                    <div class="cwpf-control-container">
                                        <div class="cwpf-control">

                                            <select name="cwpf_settings[show_images_by_attr_show]">
                                                <?php foreach ($show_images_by_attr as $key => $value) : ?>
                                                    <option value="<?php echo $key; ?>" <?php if ($cwpf_settings['show_images_by_attr_show'] == $key): ?>selected="selected"<?php endif; ?>><?php echo $value; ?></option>
                                                <?php endforeach; ?>
                                            </select>


                                            <?php
                                            $attributes = wc_get_attribute_taxonomies();
                                            ?>

                                            <?php
                                            if (!isset($cwpf_settings['show_images_by_attr']) OR empty($cwpf_settings['show_images_by_attr'])) {
                                                $cwpf_settings['show_images_by_attr'] = array();
                                            }
                                            ?>
                                            <div class="select-wrap chosen_select" <?php echo (!$cwpf_settings['show_images_by_attr_show']) ? "style='display:none;'" : ""; ?> >
                                                <select  class="chosen_select" multiple name="cwpf_settings[show_images_by_attr][]">
                                                    <?php foreach ($attributes as $attr) : ?>
                                                        <option value="pa_<?php echo $attr->attribute_name ?>" <?php if (in_array('pa_' . $attr->attribute_name, $cwpf_settings['show_images_by_attr'])): ?>selected="selected"<?php endif; ?>><?php echo $attr->attribute_label; ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>

                                        </div>


                                        <div class="cwpf-description">
                                            <p class="description"><?php _e("For variable products you can show an image depending on the current filter selection. For example you have variation with red color, and that varation has its own preview image - if on the site front user will select red color this imag will be shown. You can select attributes by which images will be selected", 'cwpfilter') ?></p>
                                        </div>

                                    </div>

                                </div><!--/ .cwpf-control-section-->

                                <div class="cwpf-control-section cwpf_premium_only">

                                    <h5><?php _e("Hide terms count text", 'cwpfilter') ?></h5>

                                    <div class="cwpf-control-container">
                                        <div class="cwpf-control">

                                            <?php
                                            $hide_terms_count_txt = array(
                                                0 => __("No", 'cwpfilter'),
                                                1 => __("Yes", 'cwpfilter')
                                            );
                                            ?>

                                            <?php
                                            if (!isset($cwpf_settings['hide_terms_count_txt']) OR empty($cwpf_settings['hide_terms_count_txt'])) {
                                                $cwpf_settings['hide_terms_count_txt'] = 0;
                                            }
                                            ?>

                                            <select name="cwpf_settings[hide_terms_count_txt]">
                                                <?php foreach ($hide_terms_count_txt as $key => $value) : ?>
                                                    <option value="<?php echo $key; ?>" <?php if ($cwpf_settings['hide_terms_count_txt'] == $key): ?>selected="selected"<?php endif; ?>><?php echo $value; ?></option>
                                                <?php endforeach; ?>
                                            </select>


                                        </div>
                                        <div class="cwpf-description">
                                            <p class="description"><?php _e("If you want show relevant tags on the categories pages you should activate show count, dynamic recount and <b>hide empty terms</b> in the tab Options. But if you do not want show count (number) text near each term - set Yes here.", 'cwpfilter') ?></p>
                                        </div>
                                    </div>

                                </div><!--/ .cwpf-control-section-->

                                <div class="cwpf-control-section">

                                    <h5><?php _e("Listen catalog visibility", 'cwpfilter') ?></h5>

                                    <div class="cwpf-control-container">
                                        <div class="cwpf-control">

                                            <?php
                                            $listen_catalog_visibility = array(
                                                0 => __("No", 'cwpfilter'),
                                                1 => __("Yes", 'cwpfilter')
                                            );
                                            ?>

                                            <?php
                                            if (!isset($cwpf_settings['listen_catalog_visibility']) OR empty($cwpf_settings['listen_catalog_visibility'])) {
                                                $cwpf_settings['listen_catalog_visibility'] = 0;
                                            }
                                            ?>

                                            <select name="cwpf_settings[listen_catalog_visibility]">
                                                <?php foreach ($listen_catalog_visibility as $key => $value) : ?>
                                                    <option value="<?php echo $key; ?>" <?php if ($cwpf_settings['listen_catalog_visibility'] == $key): ?>selected="selected"<?php endif; ?>><?php echo $value; ?></option>
                                                <?php endforeach; ?>
                                            </select>


                                        </div>
                                        <div class="cwpf-description">
                                            <p class="description">
                                                <?php _e("Listen catalog visibility - options in each product backend page in 'Publish' sidebar widget.", 'cwpfilter') ?>
                                            </p>
                                        </div>
                                    </div>

                                </div><!--/ .cwpf-control-section-->


                                <div class="cwpf-control-section">

                                    <h5><?php _e("Disable scwpf influence", 'cwpfilter') ?></h5>

                                    <div class="cwpf-control-container">
                                        <div class="cwpf-control">

                                            <?php
                                            $disable_scwpf_influence = array(
                                                0 => __("No", 'cwpfilter'),
                                                1 => __("Yes", 'cwpfilter')
                                            );
                                            ?>

                                            <?php
                                            if (!isset($cwpf_settings['disable_scwpf_influence']) OR empty($cwpf_settings['disable_scwpf_influence'])) {
                                                $cwpf_settings['disable_scwpf_influence'] = 0;
                                            }
                                            ?>

                                            <select name="cwpf_settings[disable_scwpf_influence]">
                                                <?php foreach ($disable_scwpf_influence as $key => $value) : ?>
                                                    <option value="<?php echo $key; ?>" <?php if ($cwpf_settings['disable_scwpf_influence'] == $key): ?>selected="selected"<?php endif; ?>><?php echo $value; ?></option>
                                                <?php endforeach; ?>
                                            </select>


                                        </div>
                                        <div class="cwpf-description">
                                            <p class="description"><?php _e("Sometimes code '<code>wp_query->is_post_type_archive = true</code>' does not necessary. Try to disable this and try cwpf-search on your site. If all is ok - leave its disabled. Disabled code by this option you can find in index.php by mark disable_scwpf_influence.", 'cwpfilter') ?></p>
                                        </div>
                                    </div>

                                </div><!--/ .cwpf-control-section-->

                                <?php if (!isset($cwpf_settings['cwpf_turbo_mode']['enable']) OR $cwpf_settings['cwpf_turbo_mode']['enable'] != 1 OR ! class_exists("CWPF_EXT_TURBO_MODE")) { ?>
                                    <div class="cwpf-control-section">

                                        <h5><?php _e("Cache dynamic recount number for each item in filter", 'cwpfilter') ?></h5>

                                        <div class="cwpf-control-container">
                                            <div class="cwpf-control">

                                                <?php
                                                $cache_count_data = array(
                                                    0 => __("No", 'cwpfilter'),
                                                    1 => __("Yes", 'cwpfilter')
                                                );
                                                ?>

                                                <?php
                                                if (!isset($cwpf_settings['cache_count_data']) OR empty($cwpf_settings['cache_count_data'])) {
                                                    $cwpf_settings['cache_count_data'] = 0;
                                                }
                                                ?>

                                                <select name="cwpf_settings[cache_count_data]">
                                                    <?php foreach ($cache_count_data as $key => $value) : ?>
                                                        <option value="<?php echo $key; ?>" <?php if ($cwpf_settings['cache_count_data'] == $key): ?>selected="selected"<?php endif; ?>><?php echo $value; ?></option>
                                                    <?php endforeach; ?>
                                                </select>


                                                <?php if ($cwpf_settings['cache_count_data']): ?>
                                                    <br />
                                                    <br /><a href="#" class="button js_cache_count_data_clear"><?php _e("clear cache", 'cwpfilter') ?></a>&nbsp;<span style="color: green"></span><br />
                                                    <br />
                                                    <?php
                                                    $clean_period = 'days7';
                                                    if (isset($this->settings['cache_count_data_auto_clean'])) {
                                                        $clean_period = $this->settings['cache_count_data_auto_clean'];
                                                    }
                                                    $periods = array(
                                                        0 => __("do not clean cache automatically", 'cwpfilter'),
                                                        'hourly' => __("clean cache automatically hourly", 'cwpfilter'),
                                                        'twicedaily' => __("clean cache automatically twicedaily", 'cwpfilter'),
                                                        'daily' => __("clean cache automatically daily", 'cwpfilter'),
                                                        'days2' => __("clean cache automatically each 2 days", 'cwpfilter'),
                                                        'days3' => __("clean cache automatically each 3 days", 'cwpfilter'),
                                                        'days4' => __("clean cache automatically each 4 days", 'cwpfilter'),
                                                        'days5' => __("clean cache automatically each 5 days", 'cwpfilter'),
                                                        'days6' => __("clean cache automatically each 6 days", 'cwpfilter'),
                                                        'days7' => __("clean cache automatically each 7 days", 'cwpfilter')
                                                    );
                                                    ?>

                                                    <select name="cwpf_settings[cache_count_data_auto_clean]">
                                                        <?php foreach ($periods as $key => $txt): ?>
                                                            <option <?php selected($clean_period, $key) ?> value="<?php echo $key ?>"><?php echo $txt; ?></option>
                                                        <?php endforeach; ?>
                                                    </select>


                                                <?php endif; ?>

                                            </div>
                                            <div class="cwpf-description">

                                                <?php
                                                global $wpdb;

                                                $charset_collate = '';
                                                if (method_exists($wpdb, 'has_cap') AND $wpdb->has_cap('collation')) {
                                                    if (!empty($wpdb->charset)) {
                                                        $charset_collate = "DEFAULT CHARACTER SET $wpdb->charset";
                                                    }
                                                    if (!empty($wpdb->collate)) {
                                                        $charset_collate .= " COLLATE $wpdb->collate";
                                                    }
                                                }
                                                //***
                                                $sql = "CREATE TABLE IF NOT EXISTS `" . CWPF::$query_cache_table . "` (
                                    `mkey` varchar(64) NOT NULL,
                                    `mvalue` text NOT NULL,
				    KEY `mkey` (`mkey`)
                                  ) {$charset_collate}";

                                                if ($wpdb->query($sql) === false) {
                                                    ?>
                                                    <p class="description"><?php _e("CWPF cannot create the database table! Make sure that your mysql user has the CREATE privilege! Do it manually using your host panel&phpmyadmin!", 'cwpfilter') ?></p>
                                                    <code><?php echo $sql; ?></code>
                                                    <input type="hidden" name="cwpf_settings[cache_count_data]" value="0" />
                                                    <?php
                                                    echo $wpdb->last_error;
                                                }
                                                ?>

                                                <p class="description"><?php _e("Useful thing when you already set your site IN THE PRODUCTION MODE and use dynamic recount -> it make recount very fast! Of course if you added new products which have to be in search results you have to clean this cache OR you can set time period for auto cleaning!", 'cwpfilter') ?></p>
                                            </div>
                                        </div>

                                    </div><!--/ .cwpf-control-section-->



                                    <div class="cwpf-control-section">

                                        <h5><?php _e("Cache terms", 'cwpfilter') ?></h5>

                                        <div class="cwpf-control-container">
                                            <div class="cwpf-control">

                                                <?php
                                                $cache_terms = array(
                                                    0 => __("No", 'cwpfilter'),
                                                    1 => __("Yes", 'cwpfilter')
                                                );
                                                ?>

                                                <?php
                                                if (!isset($cwpf_settings['cache_terms']) OR empty($cwpf_settings['cache_terms'])) {
                                                    $cwpf_settings['cache_terms'] = 0;
                                                }
                                                ?>

                                                <select name="cwpf_settings[cache_terms]">
                                                    <?php foreach ($cache_terms as $key => $value) : ?>
                                                        <option value="<?php echo $key; ?>" <?php if ($cwpf_settings['cache_terms'] == $key): ?>selected="selected"<?php endif; ?>><?php echo $value; ?></option>
                                                    <?php endforeach; ?>
                                                </select>


                                                <?php if ($cwpf_settings['cache_terms']): ?>
                                                    <br />
                                                    <br /><a href="#" class="button js_cache_terms_clear"><?php _e("clear terms cache", 'cwpfilter') ?></a>&nbsp;<span style="color: green"></span><br />
                                                    <br />
                                                    <?php
                                                    $clean_period = 'days7';
                                                    if (isset($this->settings['cache_terms_auto_clean'])) {
                                                        $clean_period = $this->settings['cache_terms_auto_clean'];
                                                    }
                                                    $periods = array(
                                                        0 => __("do not clean cache automatically", 'cwpfilter'),
                                                        'hourly' => __("clean cache automatically hourly", 'cwpfilter'),
                                                        'twicedaily' => __("clean cache automatically twicedaily", 'cwpfilter'),
                                                        'daily' => __("clean cache automatically daily", 'cwpfilter'),
                                                        'days2' => __("clean cache automatically each 2 days", 'cwpfilter'),
                                                        'days3' => __("clean cache automatically each 3 days", 'cwpfilter'),
                                                        'days4' => __("clean cache automatically each 4 days", 'cwpfilter'),
                                                        'days5' => __("clean cache automatically each 5 days", 'cwpfilter'),
                                                        'days6' => __("clean cache automatically each 6 days", 'cwpfilter'),
                                                        'days7' => __("clean cache automatically each 7 days", 'cwpfilter')
                                                    );
                                                    ?>
                                                    <div class="select-wrap">
                                                        <select name="cwpf_settings[cache_terms_auto_clean]">
                                                            <?php foreach ($periods as $key => $txt): ?>
                                                                <option <?php selected($clean_period, $key) ?> value="<?php echo $key ?>"><?php echo $txt; ?></option>
                                                            <?php endforeach; ?>
                                                        </select>
                                                    </div>

                                                <?php endif; ?>

                                            </div>
                                            <div class="cwpf-description">
                                                <p class="description"><?php _e("Useful thing when you already set your site IN THE PRODUCTION MODE - its getting terms for filter faster without big MySQL queries! If you actively adds new terms every day or week you can set cron period for cleaning. Another way set: '<b>not clean cache automatically</b>'!", 'cwpfilter') ?></p>
                                            </div>
                                        </div>

                                    </div><!--/ .cwpf-control-section-->
                                <?php } ?>
                                <div class="cwpf-control-section">

                                    <h5><?php _e("Show blocks helper button", 'cwpfilter') ?></h5>

                                    <div class="cwpf-control-container">
                                        <div class="cwpf-control">

                                            <?php
                                            $show_cwpf_edit_view = array(
                                                0 => __("No", 'cwpfilter'),
                                                1 => __("Yes", 'cwpfilter')
                                            );
                                            ?>

                                            <?php
                                            if (!isset($cwpf_settings['show_cwpf_edit_view'])) {
                                                $cwpf_settings['show_cwpf_edit_view'] = 1;
                                            }
                                            ?>

                                            <select id="show_cwpf_edit_view" name="cwpf_settings[show_cwpf_edit_view]">
                                                <?php foreach ($show_cwpf_edit_view as $key => $value) : ?>
                                                    <option value="<?php echo $key; ?>" <?php if ($cwpf_settings['show_cwpf_edit_view'] == $key): ?>selected="selected"<?php endif; ?>><?php echo $value; ?></option>
                                                <?php endforeach; ?>
                                            </select>


                                        </div>
                                        <div class="cwpf-description">
                                            <p class="description"><?php _e("Show helper button for shortcode [cwpf] on the front when 'Set filter automatically' is Yes", 'cwpfilter') ?></p>
                                        </div>
                                    </div>

                                </div><!--/ .cwpf-control-section-->

                                <div class="cwpf-control-section">

                                    <h5><?php _e('Custom extensions folder', 'cwpfilter') ?></h5>

                                    <div class="cwpf-control-container">
                                        <div class="cwpf-control">
                                            <?php
                                            if (!isset($cwpf_settings['custom_extensions_path'])) {
                                                $cwpf_settings['custom_extensions_path'] = '';
                                            }
                                            ?>

                                            <input type="text" name="cwpf_settings[custom_extensions_path]" value="<?php echo $cwpf_settings['custom_extensions_path'] ?>" id="custom_extensions_path" placeholder="Example: my_cwpf_extensions" />
                                        </div>
                                        <div class="cwpf-description">
                                            <p class="description"><?php printf(__('Custom extensions folder path relative to: %s', 'cwpfilter'), WP_CONTENT_DIR . DIRECTORY_SEPARATOR) ?></p>
                                        </div>
                                    </div>

                                </div><!--/ .cwpf-control-section-->

                                <div class="cwpf-control-section">

                                    <h5><?php _e('Result count css selector', 'cwpfilter') ?></h5>

                                    <div class="cwpf-control-container">
                                        <div class="cwpf-control">
                                            <?php
                                            if (!isset($cwpf_settings['result_count_redraw'])) {
                                                $cwpf_settings['result_count_redraw'] = "";
                                            }
                                            ?>

                                            <input type="text" name="cwpf_settings[result_count_redraw]" value="<?php echo $cwpf_settings['result_count_redraw'] ?>"  />
                                        </div>
                                        <div class="cwpf-description">
                                            <p class="description"><?php _e('Css class of result-count container. Is needed for ajax compatibility with wp themes. If you do not understand, leave it blank.', 'cwpfilter') ?></p>
                                        </div>
                                    </div>

                                </div><!--/ .cwpf-control-section-->

                                <div class="cwpf-control-section">

                                    <h5><?php _e('Order dropdown css selector', 'cwpfilter') ?></h5>

                                    <div class="cwpf-control-container">
                                        <div class="cwpf-control">
                                            <?php
                                            if (!isset($cwpf_settings['order_dropdown_redraw'])) {
                                                $cwpf_settings['order_dropdown_redraw'] = "";
                                            }
                                            ?>

                                            <input type="text" name="cwpf_settings[order_dropdown_redraw]" value="<?php echo $cwpf_settings['order_dropdown_redraw'] ?>"  />
                                        </div>
                                        <div class="cwpf-description">
                                            <p class="description"><?php _e('Css class of ordering dropdown container. Is needed for ajax compatibility with wp themes. If you do not understand, leave it blank.', 'cwpfilter') ?></p>
                                        </div>
                                    </div>

                                </div><!--/ .cwpf-control-section-->
                                <div class="cwpf-control-section">

                                    <h5><?php _e('Per page css selector', 'cwpfilter') ?></h5>

                                    <div class="cwpf-control-container">
                                        <div class="cwpf-control">
                                            <?php
                                            if (!isset($cwpf_settings['per_page_redraw'])) {
                                                $cwpf_settings['per_page_redraw'] = "";
                                            }
                                            ?>

                                            <input type="text" name="cwpf_settings[per_page_redraw]" value="<?php echo $cwpf_settings['per_page_redraw'] ?>"  />
                                        </div>
                                        <div class="cwpf-description">
                                            <p class="description"><?php _e('Css class of per page dropdown container. Is needed for ajax compatibility with wp themes. If you do not understand, leave it blank.', 'cwpfilter') ?></p>
                                        </div>
                                    </div>

                                </div><!--/ .cwpf-control-section-->

                            </section>

                        </div>

                    </div>

                </section>



                <?php
                if (!empty(CWPF_EXT::$includes['applications'])) {
                    foreach (CWPF_EXT::$includes['applications'] as $obj) {
                        $dir1 = $this->get_custom_ext_path() . $obj->folder_name;
                        $dir2 = CWPF_EXT_PATH . $obj->folder_name;
                        $checked1 = CWPF_EXT::is_ext_activated($dir1);
                        $checked2 = CWPF_EXT::is_ext_activated($dir2);
                        if ($checked1 OR $checked2) {
                            do_action('cwpf_print_applications_tabs_content_' . $obj->folder_name);
                        }
                    }
                }
                ?>



                <section id="tabs-6">

                    <div class="cwpf-tabs cwpf-tabs-style-line">

                        <nav>
                            <ul>
                                <li>
                                    <a href="#tabs-61">
                                        <span><?php _e("Modules", 'cwpfilter') ?></span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#tabs-62">
                                        <span><?php _e("Mod-Applications options", 'cwpfilter') ?></span>
                                    </a>
                                </li>
                            </ul>
                        </nav>

                        <div class="content-wrap">


                            <section id="tabs-61">

                                <div class="select-wrap">
                                    <select id="cwpf_manipulate_with_ext">
                                        <option value="0"><?php _e('All', 'cwpfilter') ?></option>
                                        <option value="1"><?php _e('Enabled', 'cwpfilter') ?></option>
                                        <option value="2"><?php _e('Disabled', 'cwpfilter') ?></option>
                                    </select>
                                </div>

                                <input type="hidden" name="cwpf_settings[activated_extensions]" value="" />


                                <?php if (true): ?>


                                    <!-- ----------------------------------------- -->
                                    <?php if (isset($this->settings['custom_extensions_path']) AND ! empty($this->settings['custom_extensions_path'])): ?>

                                        <br />
                                        <hr />
                                        <h3><?php _e('Custom extensions installation', 'cwpfilter') ?></h3>

                                        <?php
                                        $is_custom_extensions = false;
                                        if (is_dir($this->get_custom_ext_path())) {
                                            //$dir_writable = substr(sprintf('%o', fileperms($this->get_custom_ext_path())), -4) == "0774" ? true : false;
                                            $dir_writable = is_writable($this->get_custom_ext_path());
                                            if ($dir_writable) {
                                                $is_custom_extensions = true;
                                            }
                                        } else {
                                            if (!empty($this->settings['custom_extensions_path'])) {
                                                //ext dir auto creation
                                                $dir = $this->get_custom_ext_path();
                                                try {
                                                    mkdir($dir, 0777);
                                                    $dir_writable = is_writable($this->get_custom_ext_path());
                                                    if ($dir_writable) {
                                                        $is_custom_extensions = true;
                                                    }
                                                } catch (Exception $e) {
                                                    //***
                                                }
                                            }
                                        }
                                        //***
                                        if ($is_custom_extensions):
                                            ?>
                                            <input type="button" id="upload-btn" class="button" value="<?php _e('Choose an extension zip', 'cwpfilter') ?>">
                                            <span style="padding-left:5px;vertical-align:middle;"><i><?php _e('(zip)', 'cwpfilter') ?></i></span>

                                            <div id="errormsg" class="clearfix redtext" style="padding-top: 10px;"></div>

                                            <div id="pic-progress-wrap" class="progress-wrap" style="margin-top:10px;margin-bottom:10px;"></div>

                                            <div id="picbox" class="clear" style="padding-top:0px;padding-bottom:10px;"></div>
                                            <?php
                                            $add_ext_url = sprintf("%s?action=cwpf_upload_ext&extnonce=%s", admin_url('admin-ajax.php'), wp_create_nonce('add-ext-nonce'));
                                            ?>
                                            <script>
                                                jQuery(function ($) {
                                                    cwpf_init_ext_uploader("<?php echo ABSPATH ?>", "<?php echo $this->get_custom_ext_path() ?>", "<?php echo $add_ext_url ?>");

                                                });
                                            </script>

                                        <?php else: ?>
                                            <span style="color:orangered;"><?php printf(__('Note for admin: Folder %s for extensions is not writable OR doesn exists! Ignore this message if you not planning using CWPF custom modules!', 'cwpfilter'), $this->get_custom_ext_path()) ?></span>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <?php if (!empty($this->settings['custom_extensions_path'])): ?>
                                            <span style="color:orangered;"><?php _e('<b>Note for admin</b>: Create folder for custom modules in wp-content folder: tab Advanced -> Options -> Custom extensions folder', 'cwpfilter') ?></span>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    <!-- ----------------------------------------- -->




                                    <?php
                                    if (!isset($cwpf_settings['activated_extensions']) OR ! is_array($cwpf_settings['activated_extensions'])) {
                                        $cwpf_settings['activated_extensions'] = array();
                                    }
                                    ?>
                                    <?php if (!empty($extensions) AND is_array($extensions)): ?>

                                        <input type="hidden" id="rm-ext-nonce" value="<?php echo wp_create_nonce('rm-ext-nonce') ?>">
                                        <ul class="cwpf_extensions cwpf_custom_extensions">

                                            <?php foreach ($extensions['custom'] as $dir): ?>
                                                <?php
                                                //$idx = md5($dir);
                                                //$checked = in_array($idx, $cwpf_settings['activated_extensions']);
                                                $checked = CWPF_EXT::is_ext_activated($dir);
                                                $idx = CWPF_EXT::get_ext_idx($dir);
                                                ?>
                                                <li class="cwpf_ext_li <?php echo($checked ? 'is_enabled' : 'is_disabled'); ?>">
                                                    <?php
                                                    $info = array();
                                                    if (file_exists($dir . DIRECTORY_SEPARATOR . 'info.dat')) {
                                                        $info = CWPF_HELPER::parse_ext_data($dir . DIRECTORY_SEPARATOR . 'info.dat');
                                                    }
                                                    ?>
                                                    <table style="width: 100%;">
                                                        <tr>
                                                            <?php /* ?>
                                                            <td style="vertical-align: top;">
                                                                <img style="width: 85px;" src="<?php echo CWPF_IMG_LINK ?>cwpf_ext_cover.png" alt="ext cover" /><br />
                                                                <br />
                                                                <span class="cwpf_ext_ver"><?php
                                                                    if (isset($info['version'])) {
                                                                        printf(__('<i>ver.:</i> %s', 'cwpfilter'), $info['version']);
                                                                    }
                                                                    ?></span>
                                                            </td>
                                                            <td><div style="width:5px;"></div></td>
                                                            <?php */ ?>
                                                            <td style="width: 100%; vertical-align: top; position: relative;">
                                                                <a href="#" class="cwpf_ext_remove" data-title="" data-idx="<?php echo $idx ?>" title="<?php _e('remove extension', 'cwpfilter') ?>"><img src="<?php echo CWPF_IMG_LINK ?>delete.png" alt="<?php _e('remove extension', 'cwpfilter') ?>" /></a>
                                                                <?php
                                                                if (!empty($info)) {
                                                                    if (!empty($info) AND is_array($info)) {
                                                                        ?>
                                                                        <label for="<?php echo $idx ?>">
                                                                            <input type="checkbox" id="<?php echo $idx ?>" <?php if (isset($info['status']) AND $info['status'] == 'premium' AND $this->is_free_ver): ?>disabled="disabled"<?php endif; ?> <?php if ($checked): ?>checked=""<?php endif; ?> value="<?php echo $idx ?>" name="cwpf_settings[activated_extensions][]" />
                                                                            <?php
                                                                            if (isset($info['link'])) {
                                                                                ?>
                                                                                <a href="<?php echo $info['link'] ?>" class="cwpf_ext_title" target="_blank"><?php echo $info['title'] ?></a>
                                                                                <?php
                                                                            } else {
                                                                                echo $info['title'];
                                                                            }
                                                                            ?>
                                                                        </label><br />
                                                                        <?php
                                                                        if (isset($info['description'])) {
                                                                            echo '<br />';
                                                                            echo '<p class="description">' . $info['description'] . '</p>';
                                                                        }
                                                                    } else {
                                                                        echo $dir;
                                                                        echo '<br />';
                                                                        _e('You should write extension info in info.dat file!', 'cwpfilter');
                                                                    }
                                                                } else {
                                                                    printf(__('Looks like its not the CWPF extension here %s!', 'cwpfilter'), $dir);
                                                                }
                                                                ?>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </li>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </ul>
                                    <br />
                                    <hr />

                                    <?php if (!empty($extensions['default'])): ?>

                                        <h3><?php _e('Default modules', 'cwpfilter') ?></h3>

                                        <ul class="cwpf_extensions">
                                            <?php foreach ($extensions['default'] as $dir): ?>
                                                <?php
                                                //$idx = md5($dir);
                                                //$checked = in_array($idx, $cwpf_settings['activated_extensions']);
                                                $checked = CWPF_EXT::is_ext_activated($dir);
                                                $idx = CWPF_EXT::get_ext_idx($dir);
                                                ?>
                                                <li class="cwpf_ext_li <?php echo($checked ? 'is_enabled' : 'is_disabled'); ?>">
                                                    <?php
                                                    $info = array();
                                                    if (file_exists($dir . DIRECTORY_SEPARATOR . 'info.dat')) {
                                                        $info = CWPF_HELPER::parse_ext_data($dir . DIRECTORY_SEPARATOR . 'info.dat');
                                                    }
                                                    ?>
                                                    <table style="width: 100%;">
                                                        <tr>
                                                            <?php /* ?>
                                                            <td style="vertical-align: top;">
                                                                <img style="width: 85px;" src="<?php echo CWPF_IMG_LINK ?>cwpf_ext_cover.png" alt="ext cover" /><br />
                                                                <br />
                                                                <span class="cwpf_ext_ver"><?php
                                                                    if (isset($info['version'])) {
                                                                        printf(__('<i>ver.:</i> %s', 'cwpfilter'), $info['version']);
                                                                    }
                                                                    ?></span>
                                                            </td>
                                                            <td><div style="width:5px;"></div></td>
                                                            <?php */ ?>
                                                            <td style="width: 100%;">
                                                                <?php
                                                                if (!empty($info)) {
                                                                    $info = CWPF_HELPER::parse_ext_data($dir . DIRECTORY_SEPARATOR . 'info.dat');
                                                                    if (!empty($info) AND is_array($info)) {
                                                                        ?>
                                                                        <label for="<?php echo $idx ?>">
                                                                            <input type="checkbox" id="<?php echo $idx ?>" <?php if (isset($info['status']) AND $info['status'] == 'premium'): ?>disabled="disabled"<?php endif; ?> <?php if ($checked): ?>checked=""<?php endif; ?> value="<?php echo $idx ?>" name="cwpf_settings[activated_extensions][]" />
                                                                            <?php
                                                                            if (isset($info['link'])) {
                                                                                ?>
                                                                                <a href="<?php echo $info['link'] ?>" class="cwpf_ext_title" target="_blank"><?php echo $info['title'] ?></a>
                                                                                <?php
                                                                            } else {
                                                                                echo $info['title'];
                                                                            }
                                                                            ?>
                                                                        </label><br />
                                                                        <?php
                                                                        echo '<br />';
                                                                        echo '<p class="description">' . $info['description'] . '</p>';
                                                                    } else {
                                                                        echo $dir;
                                                                        echo '<br />';
                                                                        _e('You should write extension info in info.dat file!', 'cwpfilter');
                                                                    }
                                                                } else {
                                                                    echo $dir;
                                                                }
                                                                ?>
                                                            </td>
                                                        </tr>
                                                    </table>

                                                </li>
                                            <?php endforeach; ?>
                                        </ul>
                                    <?php endif; ?>

                                <?php endif; ?>
                                <div class="clear"></div>


                            </section>


                            <section id="tabs-62">

                                <div class="cwpf-tabs cwpf-tabs-style-line">

                                    <nav class="cwpf_ext_nav">
                                        <ul>
                                            <?php
                                            $is_custom_extensions = false;
                                            if (is_dir($this->get_custom_ext_path())) {
                                                //$dir_writable = substr(sprintf('%o', fileperms($this->get_custom_ext_path())), -4) == "0774" ? true : false;
                                                $dir_writable = is_writable($this->get_custom_ext_path());
                                                if ($dir_writable) {
                                                    $is_custom_extensions = true;
                                                }
                                            }

                                            if ($is_custom_extensions) {
                                                if (!empty(CWPF_EXT::$includes['applications'])) {
                                                    foreach (CWPF_EXT::$includes['applications'] as $obj) {

                                                        $dir = $this->get_custom_ext_path() . $obj->folder_name;
                                                        //$idx = md5($dir);
                                                        //$checked = in_array($idx, $cwpf_settings['activated_extensions']);
                                                        $checked = CWPF_EXT::is_ext_activated($dir);
                                                        if (!$checked) {
                                                            continue;
                                                        }
                                                        ?>
                                                        <li>

                                                            <?php
                                                            if (file_exists($dir . DIRECTORY_SEPARATOR . 'info.dat')) {
                                                                $info = CWPF_HELPER::parse_ext_data($dir . DIRECTORY_SEPARATOR . 'info.dat');
                                                                if (!empty($info) AND is_array($info)) {
                                                                    $name = $info['title'];
                                                                } else {
                                                                    $name = $obj->folder_name;
                                                                }
                                                            } else {
                                                                $name = $obj->folder_name;
                                                            }
                                                            ?>
                                                            <a href="#tabs-<?php echo sanitize_title($obj->folder_name) ?>" title="<?php printf(__("%s", 'cwpfilter'), $name) ?>">
                                                                <span style="font-size: 11px;"><?php printf(__("%s", 'cwpfilter'), $name) ?></span>
                                                            </a>
                                                        </li>
                                                        <?php
                                                    }
                                                }
                                            }
                                            ?>


                                        </ul>
                                    </nav>


                                    <div class="content-wrap cwpf_ext_opt">

                                        <?php
                                        if ($is_custom_extensions) {
                                            if (!empty(CWPF_EXT::$includes['applications'])) {
                                                foreach (CWPF_EXT::$includes['applications'] as $obj) {

                                                    $dir = $this->get_custom_ext_path() . $obj->folder_name;
                                                    //$idx = md5($dir);
                                                    //$checked = in_array($idx, $cwpf_settings['activated_extensions']);
                                                    $checked = CWPF_EXT::is_ext_activated($dir);
                                                    if (!$checked) {
                                                        continue;
                                                    }
                                                    do_action('cwpf_print_applications_options_' . $obj->folder_name);
                                                }
                                            }
                                        }
                                        ?>

                                    </div>


                                    <div class="clear"></div>

                                </div>




                            </section>

                        </div>

                    </div>

                </section>


<?php /*  ?>
                <section id="tabs-7">

                    <table class="form-table">
                        <tbody>
                            <tr valign="top">
                                <th scope="row"><label><?php _e("Links", 'cwpfilter') ?></label></th>
                                <td>

                                    <ul>

                                        <li>
                                            <a class="button" href="https://cleveraddon.com/documentation/" target="_blank"><?php _e("CWPF documentation", 'cwpfilter') ?></a>
                                            <a class="button" href="https://cleveraddon.com/category/faq/" target="_blank"><?php _e("FAQ", 'cwpfilter') ?></a>
                                            <a class="button" href="https://cleveraddon.com/video-tutorials/" target="_blank"><?php _e("Video tutorials", 'cwpfilter') ?></a>
                                            <a class="button" href="https://cleveraddon.com/support/" target="_blank"><?php _e("Support", 'cwpfilter') ?></a>
                                        </li>

                                    </ul>

                                </td>
                            </tr>

                            <tr valign="top">
                                <th scope="row"><label><?php _e("Demo sites", 'cwpfilter') ?></label></th>
                                <td>

                                    <ul>

                                        <li>
                                            <a href="http://demo.cleveraddon.com/" class="button" target="_blank">Demo 1</a>&nbsp;
                                            <a href="http://demo10k.cleveraddon.com/" class="button" target="_blank">Demo 2</a>&nbsp;
                                            <a href="http://turbo.cleveraddon.com/" class="button" target="_blank">Demo 3</a>&nbsp;
                                        </li>
                                        <li>
                                            <a href="https://cleveraddon.com/styles-codes-applied-on-demo-site/" class="button" target="_blank"><?php _e("Styles and codes which are applied on the demo site", 'cwpfilter') ?></a>
                                        </li>

                                    </ul>

                                </td>
                            </tr>


                            <tr valign="top">
                                <th scope="row"><label><?php _e("Quick video tutorial", 'cwpfilter') ?></label></th>
                                <td>

                                    <ul>

                                        <li>
                                            <iframe width="560" height="315" src="https://www.youtube.com/embed/jZPtdWgAxKk" frameborder="0" allowfullscreen></iframe>
                                        </li>

                                    </ul>

                                </td>
                            </tr>


                            <tr valign="top">
                                <th scope="row"><label><?php _e("More video", 'cwpfilter') ?></label></th>
                                <td>

                                    <ul>

                                        <li>
                                            <a href="https://cleveraddon.com/video-tutorials/" class="button" target="_blank"><?php _e("Video tutorials", 'cwpfilter') ?></a>
                                        </li>

                                    </ul>

                                </td>
                            </tr>



                            <tr valign="top">
                                <th scope="row"><label><?php _e("GDPR", 'cwpfilter') ?></label></th>
                                <td>

                                    <ul>

                                        <li>
                                            <a href="https://cleveraddon.com/gdpr/" class="button" target="_blank"><?php _e("GDPR info", 'cwpfilter') ?></a>
                                        </li>

                                    </ul>

                                </td>
                            </tr>


                            <?php if (!$this->is_free_ver): ?>
                                <tr>
                                    <td colspan="2">
                                        <div id="plugin_warning" style="padding: 9px; border: solid red 3px; background: #eee; ">
                                            <div class="plugin_warning_head"><strong style="color: red;">ATTENTION MESSAGE FROM THE PLUGIN AUTHOR TO ALL USERS WHO USES PIRATE VERSION OF THE PLUGIN! IF YOU BOUGHT IT - DO NOT READ AND IGNORE IT!!</strong>!<br></div>
                                            <br />
                                            GET YOUR COPY OF THE PLUGIN <em> <span style="text-decoration: underline;"><span style="color: #ff0000;"><strong>ONLY</strong></span></span></em> FROM <a href="https://cleveraddon.com/affiliate/clever-woocommerce-product-filter" target="_blank"><span style="color: #008000;"><strong>CODECANYON.NET</strong></span></a> OR <span style="color: #008000;"><strong><a href="https://wordpress.org/plugins/clever-woocommerce-product-filter/" target="_blank">WORDPRESS.ORG</a></strong></span> IF YOU DO NOT WANT TO BE AN AFFILIATE OF PORNO VIRUS SITE.<br>
                                            <br>
                                            <strong>DID YOU CATCH A VIRUS DOWNLOADING THE PLUGIN FROM ANOTHER (PIRATE) SITES<span style="color: #ff0000;">?</span></strong> THIS IS YOUR TROUBLES AND <em>DO NOT WRITE TO SUPPORT THAT GOOGLE DOWN YOUR SITE TO ZERO BECAUSE OF &nbsp;PORNO VIRUS</em>!!<br>
                                            <br>
                                            <strong><span style="color: #ff0000;">REMEMBER</span></strong> - if somebody suggesting YOU premium version of the plugin for free - think twenty times before installing it ON YOUR SITE, as it can be trap for it! <strong>DOWNLOAD THE PLUGIN ONLY FROM OFFICIAL SITES TO AVOID THE COLLAPSE OF YOUR BUSINESS</strong>.<br>
                                            <br>
                                            <strong style="color: #ff0000;">Miser pays twice</strong>!<br>
                                            <br>
                                            P.S. Reason of this warning text - emails from the users! Be care!!
                                        </div>
                                    </td>
                                </tr>
                            <?php endif; ?>



                            <tr valign="top">
                                <th scope="row"><label><?php _e("Recommended plugins for your site flexibility and features", 'cwpfilter') ?></label></th>
                                <td>

                                    <ul class="list_plugins">


                                        <li>
                                            <a href="https://currency-switcher.com/" width="300" alt="" target="_blank"><img src="<?php echo CWPF_IMG_LINK ?>plugin_options/woocs_banner.jpg" /></a>
                                            <p class="description"><?php _e("WooCommerce Currency Switcher – is the plugin that allows you to switch to different currencies and get their rates converted in the real time!", 'cwpfilter') ?></p>
                                        </li>

                                        <li>
                                            <a href="https://bulk-editor.com/downloads/" width="300" alt="" target="_blank"><img src="<?php echo CWPF_IMG_LINK ?>plugin_options/woobe_banner.jpg" /></a>
                                            <p class="description"><?php _e("WordPress plugin for managing and bulk edit WooCommerce Products data in robust and flexible way! Be professionals with managing data of your woocommerce e-shop!", 'cwpfilter') ?></p>
                                        </li>

                                        <li>
                                            <a href="https://wordpress.org/plugins/inpost-gallery/" target="_blank">InPost Gallery - flexible photo gallery</a>
                                            <p class="description"><?php _e("Insert Gallery in post, page and custom post types just in two clicks. You can create great galleries for your products.", 'cwpfilter') ?></p>
                                        </li>


                                        <li>
                                            <a href="https://wordpress.org/plugins/autoptimize/" target="_blank">Autoptimize</a>
                                            <p class="description"><?php _e("It concatenates all scripts and styles, minifies and compresses them, adds expires headers, caches them, and moves styles to the page head, and scripts to the footer", 'cwpfilter') ?></p>
                                        </li>


                                        <li>
                                            <a href="https://wordpress.org/plugins/pretty-link/" target="_blank">Pretty Link Lite</a>
                                            <p class="description"><?php _e("Shrink, beautify, track, manage and share any URL on or off of your WordPress website. Create links that look how you want using your own domain name!", 'cwpfilter') ?></p>
                                        </li>

                                        <li>
                                            <a href="https://wordpress.org/plugins/custom-post-type-ui/" target="_blank">Custom Post Type UI</a>
                                            <p class="description"><?php _e("This plugin provides an easy to use interface to create and administer custom post types and taxonomies in WordPress.", 'cwpfilter') ?></p>
                                        </li>

                                        <li>
                                            <a href="https://wordpress.org/plugins/widget-logic/other_notes/" target="_blank">Widget Logic</a>
                                            <p class="description"><?php _e("Widget Logic lets you control on which pages widgets appear using", 'cwpfilter') ?></p>
                                        </li>

                                        <li>
                                            <a href="https://wordpress.org/plugins/wp-super-cache/" target="_blank">WP Super Cache</a>
                                            <p class="description"><?php _e("Cache pages, allow to make a lot of search queries on your site without high load on your server!", 'cwpfilter') ?></p>
                                        </li>


                                        <li>
                                            <a href="https://wordpress.org/plugins/wp-migrate-db/" target="_blank">WP Migrate DB</a>
                                            <p class="description"><?php _e("Exports your database, does a find and replace on URLs and file paths, then allows you to save it to your computer.", 'cwpfilter') ?></p>
                                        </li>

                                        <li>
                                            <a href="https://wordpress.org/plugins/duplicator/" target="_blank">Duplicator</a>
                                            <p class="description"><?php _e("Duplicate, clone, backup, move and transfer an entire site from one location to another.", 'cwpfilter') ?></p>
                                        </li>

                                    </ul>

                                </td>
                            </tr>

                            <tr valign="top">
                                <th scope="row"><label><?php _e("Adv", 'cwpfilter') ?></label></th>
                                <td>

                                    <ul>

                                        <li>
                                            <a href="https://wp.bulk-editor.com/" target="_blank" title="WPBE - WordPress Posts Bulk Editor Professional"><img src="<?php echo CWPF_IMG_LINK ?>plugin_options/wpbe-banner.png" alt="WPBE - WordPress Posts Bulk Editor Professional" width="300" /></a>
                                        </li>

                                    </ul>

                                </td>
                            </tr>

                        </tbody>
                    </table>

                </section>
                <?php */ ?>

            </div>

            <div style="float: right; padding-top: 4px;">
                <a href="https://cleveraddon.com/" target="_blank" style="font-size: 11px; color: #aaa; text-decoration: none;">Powered by CleverAddon</a>
            </div>

        </div>

        <style type="text/css">
            .form-table th {  width: 300px; }
        </style>

    </section><!--/ .cwpf-section-->

    <div id="cwpf_ext_tpl" style="display: none;">
        <li class="cwpf_ext_li is_disabled">

            <table style="width: 100%;">
                <tbody>
                    <tr>
                        <?php /* ?>
                        <td style="vertical-align: top;">
                            <img alt="ext cover" src="<?php echo CWPF_IMG_LINK ?>cwpf_ext_cover.png" style="width: 85px;">
                        </td>
                        <td><div style="width:5px;"></div></td>
                        <?php */ ?>
                        <td style="width: 100%; vertical-align: top; position: relative;">
                            <a href="#" class="cwpf_ext_remove" data-title="__TITLE__" data-idx="__IDX__" title="<?php _e('remove extension', 'cwpfilter') ?>"><img src="<?php echo CWPF_IMG_LINK ?>delete.png" alt="<?php _e('remove extension', 'cwpfilter') ?>" /></a>
                            <label for="__IDX__">
                                <input type="checkbox" name="__NAME__" value="__IDX__" id="__IDX__">
                                __TITLE__
                            </label><br>
                            <i>ver.:</i> __VERSION__<br><p class="description">__DESCRIPTION__</p>
                        </td>
                    </tr>
                </tbody>
            </table>

        </li>
    </div>



    <div id="cwpf_buffer" style="display: none;"></div>

    <div id="cwpf_html_buffer" class="cwpf_info_popup" style="display: none;"></div>


    <?php if ($this->is_free_ver): ?>
        <script>
            jQuery(function () {
                //for premium only
                jQuery('#cwpf_filter_btn_txt').prop('disabled', true);
                jQuery('#override_no_products').prop('disabled', true);
                jQuery('#cwpf_filter_btn_txt').val('In the premium version');
                jQuery('#cwpf_reset_btn_txt').prop('disabled', true);
                jQuery('#cwpf_reset_btn_txt').val('In the premium version');
                jQuery('#cwpf_hide_dynamic_empty_pos').prop('disabled', true);
                jQuery('#cwpf_hide_dynamic_empty_pos_turbo_mode').prop('disabled', true);
                jQuery('select[name="cwpf_settings[hide_terms_count_txt]"]').prop('disabled', true);
                //***
                jQuery('#scwpf_search_slug').prop('disabled', true);
                jQuery('#scwpf_search_slug').val('In the premium version');
                jQuery('#scwpf_search_slug').parents('.cwpf-control-section').addClass('cwpf_premium_only');
                jQuery('#override_no_products').parents('.cwpf-control-section').addClass('cwpf_premium_only');
                jQuery('#hide_terms_count_txt').prop('disabled', true);
                jQuery('#hide_terms_count_txt').parents('.cwpf-control-section').addClass('cwpf_premium_only');
            });
        </script>

        <style type="text/css">
            .cwpf_premium_only{
                color:red !important;
            }

            label[for=cwpf_filter_btn_txt],
            label[for=cwpf_reset_btn_txt],label[for=scwpf_search_slug],
            label[for=cwpf_hide_dynamic_empty_pos],label[for=cwpf_hide_dynamic_empty_pos_turbo_mode],
            label[for=hide_terms_count_txt]
            {
                color:red;
            }
        </style>
    <?php endif; ?>

</div>


<?php if ($this->is_free_ver): ?>
    <hr />


    <table style="width: 100%;">
        <tr>
            <td style="width: 33%;">
                <h3 style="color: tomato"><?php _e("CWPF FULL VERSION", 'cwpfilter') ?>:</h3>
                <a href="https://cleveraddon.com/affiliate/clever-woocommerce-product-filter" target="_blank"><img width="300" src="<?php echo CWPF_IMG_LINK ?>plugin_options/cwpf_banner.jpg" alt="<?php _e("full version of the plugin", 'cwpfilter'); ?>" /></a>
            </td>

            <td style="width: 33%;">
                <h3><?php _e("Get WooCommerce Bulk Editor", 'cwpfilter') ?>:</h3>
                <a href="https://cleveraddon.com/affiliate/woocommerce-bulk-editor" target="_blank"><img width="300" src="<?php echo CWPF_IMG_LINK ?>plugin_options/woobe_banner.jpg" alt="<?php _e("WOOBE", 'cwpfilter'); ?>" /></a>
            </td>

            <td style="width: 33%;">
                <h3><?php _e("Get WooCommerce Currency Swither", 'cwpfilter') ?>:</h3>
                <a href="https://cleveraddon.com/affiliate/woocommerce-currency-switcher" target="_blank"><img width="300" src="<?php echo CWPF_IMG_LINK ?>plugin_options/woocs_banner.jpg" alt="<?php _e("WOOCS", 'cwpfilter'); ?>" /></a>
            </td>
        </tr>

    </table>

<?php endif; ?>

<?php

function cwpf_print_tax($key, $tax, $cwpf_settings) {
    global $CWPF;
    ?>
    <li data-key="<?php echo $key ?>" class="cwpf_options_li">

        <a href="#" class="help_tip cwpf_drag_and_drope" data-tip="<?php _e("drag and drope", 'cwpfilter'); ?>"><span class="cwpf-list-icons cwpf-list-move-button"></span></a>

        <input <?php echo(((isset($CWPF->settings['tax']) ? is_array($CWPF->settings['tax']) : FALSE) ? in_array($key, (array) array_keys($CWPF->settings['tax'])) : false) ? 'checked="checked"' : '') ?> type="checkbox" name="cwpf_settings[tax][<?php echo $key ?>]" id="tax_<?php echo md5($key) ?>" value="1" />
        <label for="tax_<?php echo md5($key) ?>" style="font-weight:bold;display:inline-block;width:153px;"><?php echo $tax->labels->name ?></label>
        <img class="help_tip" data-tip="<?php _e('View of the taxonomies terms on the front', 'cwpfilter') ?>" src="<?php echo WP_PLUGIN_URL ?>/woocommerce/assets/images/help.png" height="16" width="16" />
        <div class="select-wrap">
            <select name="cwpf_settings[tax_type][<?php echo $key ?>]" class="cwpf_select_tax_type">
                <?php foreach ($CWPF->html_types as $type => $type_text) : ?>
                    <option value="<?php echo $type ?>" <?php if (isset($cwpf_settings['tax_type'][$key])) echo selected($cwpf_settings['tax_type'][$key], $type) ?>><?php echo $type_text ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <?php
        $excluded_terms = '';
        if (isset($cwpf_settings['excluded_terms'][$key])) {
            $excluded_terms = $cwpf_settings['excluded_terms'][$key];
        }

        $excluded_terms_reverse = 0;
        if (isset($cwpf_settings['excluded_terms_reverse'][$key])) {
            $excluded_terms_reverse = $cwpf_settings['excluded_terms_reverse'][$key];
        }
        ?>

        <input type="text" style="width: 420px;" name="cwpf_settings[excluded_terms][<?php echo $key ?>]" placeholder="<?php _e('excluded terms ids', 'cwpfilter') ?>" value="<?php echo $excluded_terms ?>" />

        <input <?php echo(((isset($CWPF->settings['excluded_terms_reverse']) ? is_array($CWPF->settings['excluded_terms_reverse']) : FALSE) ? in_array($key, (array) array_keys($CWPF->settings['excluded_terms_reverse'])) : false) ? 'checked="checked"' : '') ?> type="checkbox" name="cwpf_settings[excluded_terms_reverse][<?php echo $key ?>]" value="1" />
        <label  style="font-size:10px;"><?php _e('Reverse', 'cwpfilter') ?></label>


        <img class="help_tip" data-tip="<?php _e('If you want to exclude some current taxonomies terms from the search form! Use Reverse if you want include only instead of exclude! Example: 11,23,77', 'cwpfilter') ?>" src="<?php echo WP_PLUGIN_URL ?>/woocommerce/assets/images/help.png" height="16" width="16" />
        <input type="button" value="" data-key="<?php echo $key ?>" data-taxonomy="<?php echo $key ?>" data-taxonomy-name="<?php echo $tax->labels->name ?>" class="cwpf-button cwpf-list-icons js_cwpf_expand_options js_cwpf_expand_add_options js_cwpf_expand_options_<?php echo $key; ?> js_cwpf_expand_add_options_<?php echo $key; ?>" />

        <div style="display: none;" class="cwpf-additional-options-<?php echo $key; ?>">
            <?php
            $max_height = 0;
            if (isset($cwpf_settings['tax_block_height'][$key])) {
                $max_height = $cwpf_settings['tax_block_height'][$key];
            }
            ?>
            <input type="text" name="cwpf_settings[tax_block_height][<?php echo $key ?>]" placeholder="" value="<?php echo $max_height ?>" />
            <?php
            $show_title_label = 0;
            if (isset($cwpf_settings['show_title_label'][$key])) {
                $show_title_label = $cwpf_settings['show_title_label'][$key];
            }
            ?>
            <input type="text" name="cwpf_settings[show_title_label][<?php echo $key ?>]" placeholder="" value="<?php echo $show_title_label ?>" />
            <?php
            $title_label = $tax->labels->name;
            if (isset($cwpf_settings['title_label'][$key])) {
                $title_label = $cwpf_settings['title_label'][$key];
            }
            ?>
            <input type="text" name="cwpf_settings[title_label][<?php echo $key ?>]" placeholder="" value="<?php echo $title_label ?>" />


            <?php
            $show_toggle_button = 0;
            if (isset($cwpf_settings['show_toggle_button'][$key])) {
                $show_toggle_button = $cwpf_settings['show_toggle_button'][$key];
            }
            ?>
            <input type="text" name="cwpf_settings[show_toggle_button][<?php echo $key ?>]" placeholder="" value="<?php echo $show_toggle_button ?>" />


            <?php
            $tooltip_text = "";
            if (isset($cwpf_settings['tooltip_text'][$key])) {
                $tooltip_text = stripcslashes($cwpf_settings['tooltip_text'][$key]);
            }
            ?>
            <input type="text" name="cwpf_settings[tooltip_text][<?php echo $key ?>]" placeholder="" value="<?php echo $tooltip_text ?>" />

            <?php
            $dispay_in_row = 0;
            if (isset($cwpf_settings['dispay_in_row'][$key])) {
                $dispay_in_row = $cwpf_settings['dispay_in_row'][$key];
            }
            ?>
            <input type="text" name="cwpf_settings[dispay_in_row][<?php echo $key ?>]" placeholder="" value="<?php echo $dispay_in_row ?>" />


            <?php
            $orderby = '-1';
            if (isset($cwpf_settings['orderby'][$key])) {
                $orderby = $cwpf_settings['orderby'][$key];
            }
            ?>
            <input type="text" name="cwpf_settings[orderby][<?php echo $key ?>]" placeholder="" value="<?php echo $orderby ?>" />

            <?php
            $order = 'ASC';
            if (isset($cwpf_settings['order'][$key])) {
                $order = $cwpf_settings['order'][$key];
            }
            ?>
            <input type="text" name="cwpf_settings[order][<?php echo $key ?>]" placeholder="" value="<?php echo $order ?>" />
            <?php
            $comparison_logic = 'OR';
            $logic_restriction = array('checkbox', 'mselect', 'label', 'color', 'image', 'slider', 'select_hierarchy');
            if (isset($cwpf_settings['comparison_logic'][$key])) {
                $comparison_logic = $cwpf_settings['comparison_logic'][$key];
            }
            if (isset($cwpf_settings['tax_type'][$key]) AND ! in_array($cwpf_settings['tax_type'][$key], $logic_restriction) AND $comparison_logic == 'AND') {
                $comparison_logic = 'OR';
            }

            if ($comparison_logic == 'NOT IN' AND $cwpf_settings['tax_type'][$key] == 'select_hierarchy') {
                $comparison_logic = 'OR';
            }
            ?>
            <input type="text" name="cwpf_settings[comparison_logic][<?php echo $key ?>]" placeholder="" value="<?php echo $comparison_logic ?>" />

            <?php
            $custom_tax_label = '';
            if (isset($cwpf_settings['custom_tax_label'][$key])) {
                $custom_tax_label = stripcslashes($cwpf_settings['custom_tax_label'][$key]);
            }
            ?>
            <input type="text" name="cwpf_settings[custom_tax_label][<?php echo $key ?>]" placeholder="" value="<?php echo $custom_tax_label ?>" />


            <?php
            $not_toggled_terms_count = '';
            if (isset($cwpf_settings['not_toggled_terms_count'][$key])) {
                $not_toggled_terms_count = $cwpf_settings['not_toggled_terms_count'][$key];
            }
            ?>
            <input type="text" name="cwpf_settings[not_toggled_terms_count][<?php echo $key ?>]" placeholder="" value="<?php echo $not_toggled_terms_count ?>" />


            <!------------- options for extensions ------------------------>
            <?php
            if (!empty(CWPF_EXT::$includes['taxonomy_type_objects'])) {
                foreach (CWPF_EXT::$includes['taxonomy_type_objects'] as $obj) {
                    if (!empty($obj->taxonomy_type_additional_options)) {
                        foreach ($obj->taxonomy_type_additional_options as $option_key => $option) {
                            $option_val = 0;
                            if (isset($cwpf_settings[$option_key][$key])) {
                                $option_val = $cwpf_settings[$option_key][$key];
                            }
                            ?>
                            <input type="text" name="cwpf_settings[<?php echo $option_key ?>][<?php echo $key ?>]" value="<?php echo $option_val ?>" />
                            <?php
                        }
                    }
                }
            }
            ?>




        </div>
        <div id="cwpf-modal-content-<?php echo $key; ?>" style="display: none;">

            <div class="cwpf_option_container cwpf_option_all">

                <div class="cwpf-form-element-container">

                    <div class="cwpf-name-description">
                        <strong><?php _e('Title', 'cwpfilter') ?></strong>
                    </div>

                    <div class="cwpf-form-element">
                            <input class="cwpf_popup_option regular-text" type="text" data-option="title_label"/>
                    </div>

                </div>
                <div class="cwpf-form-element-container">

                    <div class="cwpf-name-description">
                        <strong><?php _e('Show title label', 'cwpfilter') ?></strong>
                        <span><?php _e('Show/Hide taxonomy block title on the front', 'cwpfilter') ?></span>
                    </div>

                    <div class="cwpf-form-element">

                        <div class="select-wrap">
                            <select class="cwpf_popup_option" data-option="show_title_label">
                                <option value="0"><?php _e('No', 'cwpfilter') ?></option>
                                <option value="1"><?php _e('Yes', 'cwpfilter') ?></option>
                            </select>
                        </div>

                    </div>

                </div>

                <div class="cwpf-form-element-container">

                    <div class="cwpf-name-description">
                        <strong><?php _e('Show toggle button', 'cwpfilter') ?></strong>
                        <span><?php _e('Show toggle button near the title on the front above the block of html-items', 'cwpfilter') ?></span>
                    </div>

                    <div class="cwpf-form-element">

                        <div class="select-wrap">
                            <select class="cwpf_popup_option" data-option="show_toggle_button">
                                <option value="0"><?php _e('No', 'cwpfilter') ?></option>
                                <option value="1"><?php _e('Yes, show as closed', 'cwpfilter') ?></option>
                                <option value="2"><?php _e('Yes, show as opened', 'cwpfilter') ?></option>
                            </select>
                        </div>

                    </div>

                </div>
                <div class="cwpf-form-element-container">

                    <div class="cwpf-name-description">
                        <strong><?php _e('Tooltip', 'cwpfilter') ?></strong>
                        <span><?php _e('Show tooltip', 'cwpfilter') ?></span>
                    </div>

                    <div class="cwpf-form-element">

                        <div class="select-wrap">
                            <textarea class="cwpf_popup_option" data-option="tooltip_text" ></textarea>
                        </div>

                    </div>

                </div>

            </div>


            <div class="cwpf_option_container cwpf_option_all">

                <div class="cwpf-form-element-container">

                    <div class="cwpf-name-description">
                        <strong><?php _e('Not toggled terms count', 'cwpfilter') ?></strong>
                        <span><?php _e('Enter count of terms which should be visible to make all other collapsible. "Show more" button will be appeared. This feature is works with: radio, checkboxes, labels, colors.', 'cwpfilter') ?></span>
                        <span><?php printf(__('Advanced info is <a href="%s" target="_blank">here</a>', 'cwpfilter'), 'https://cleveraddon.com/hook/cwpf_get_more_less_button_xxxx/') ?></span>
                    </div>

                    <div class="cwpf-form-element">
                        <input type="text" class="cwpf_popup_option regular-text code" data-option="not_toggled_terms_count" placeholder="<?php _e('leave it empty to show all terms', 'cwpfilter') ?>" value="0" />
                    </div>

                </div>

            </div>

            <div class="cwpf_option_container cwpf_option_all">

                <div class="cwpf-form-element-container">

                    <div class="cwpf-name-description">
                        <strong><?php _e('Taxonomy custom label', 'cwpfilter') ?></strong>
                        <span><?php _e('For example you want to show title of Product Categories as "My Products". Just for your convenience.', 'cwpfilter') ?></span>
                    </div>

                    <div class="cwpf-form-element">
                        <input type="text" class="cwpf_popup_option regular-text code" data-option="custom_tax_label" placeholder="<?php _e('leave it empty to use native taxonomy name', 'cwpfilter') ?>" value="0" />
                    </div>

                </div>

            </div>

            <div class="cwpf_option_container cwpf_option_radio cwpf_option_checkbox cwpf_option_label">

                <div class="cwpf-form-element-container">

                    <div class="cwpf-name-description">
                        <strong><?php _e('Max height of the block', 'cwpfilter') ?></strong>
                        <span><?php _e('Container max-height (px). 0 means no max-height.', 'cwpfilter') ?></span>
                    </div>

                    <div class="cwpf-form-element">
                        <input type="text" class="cwpf_popup_option regular-text code" data-option="tax_block_height" placeholder="<?php _e('Max height of  the block', 'cwpfilter') ?>" value="0" />
                    </div>

                </div>

            </div>

            <div class="cwpf_option_container cwpf_option_radio cwpf_option_checkbox">

                <div class="cwpf-form-element-container">

                    <div class="cwpf-name-description">
                        <strong><?php _e('Display items in a row', 'cwpfilter') ?></strong>
                        <span><?php _e('Works for radio and checkboxes only. Allows show radio/checkboxes in 1 row!', 'cwpfilter') ?></span>
                    </div>

                    <div class="cwpf-form-element">

                        <div class="select-wrap">
                            <select class="cwpf_popup_option" data-option="dispay_in_row">
                                <option value="0"><?php _e('No', 'cwpfilter') ?></option>
                                <option value="1"><?php _e('Yes', 'cwpfilter') ?></option>
                            </select>
                        </div>

                    </div>

                </div>

            </div>

            <div class="cwpf_option_container  cwpf_option_all">

                <div class="cwpf-form-element-container">

                    <div class="cwpf-name-description">
                        <strong><?php _e('Sort terms', 'cwpfilter') ?></strong>
                        <span><?php _e('How to sort terms inside of filter block', 'cwpfilter') ?></span>
                    </div>

                    <div class="cwpf-form-element">

                        <div class="select-wrap">
                            <select class="cwpf_popup_option" data-option="orderby">
                                <option value="-1"><?php _e('Default', 'cwpfilter') ?></option>
                                <option value="id"><?php _e('Id', 'cwpfilter') ?></option>
                                <option value="name"><?php _e('Title', 'cwpfilter') ?></option>
                                <option value="numeric"><?php _e('Numeric.', 'cwpfilter') ?></option>

                            </select>
                        </div>

                    </div>

                </div>

            </div>
            <div class="cwpf_option_container  cwpf_option_all">

                <div class="cwpf-form-element-container">

                    <div class="cwpf-name-description">
                        <strong><?php _e('Sort terms', 'cwpfilter') ?></strong>
                        <span><?php _e('Direction of terms sorted inside of filter block', 'cwpfilter') ?></span>
                    </div>

                    <div class="cwpf-form-element">

                        <div class="select-wrap">
                            <select class="cwpf_popup_option" data-option="order">
                                <option value="ASC"><?php _e('ASC', 'cwpfilter') ?></option>
                                <option value="DESC"><?php _e('DESC', 'cwpfilter') ?></option>
                            </select>
                        </div>

                    </div>

                </div>

            </div>
            <?php //  cwpf_option_checkbox cwpf_option_mselect cwpf_option_image cwpf_option_color cwpf_option_label cwpf_option_select_radio_check ?>
            <div class="cwpf_option_container cwpf_option_all ">

                <div class="cwpf-form-element-container">

                    <div class="cwpf-name-description">
                        <strong><?php _e('Logic of filtering', 'cwpfilter') ?></strong>
                        <span><?php _e('AND or OR: if to select AND and on the site front select 2 terms - will be found products which contains both terms on the same time.', 'cwpfilter') ?></span>
                        <span><?php _e('If to select NOT IN will be found items which not has selected terms!! Means vice versa to the the concept of including: excluding', 'cwpfilter') ?></span>
                    </div>
                    <div class="cwpf-form-element">

                        <div class="select-wrap">
                            <select class="cwpf_popup_option" data-option="comparison_logic">
                                <option value="OR"><?php _e('OR', 'cwpfilter') ?></option>
                                <option class="cwpf_option_checkbox cwpf_option_mselect cwpf_option_image cwpf_option_color cwpf_option_label cwpf_option_select_radio_check" value="AND" style="display: none;"><?php _e('AND', 'cwpfilter') ?></option>
                                <option value="NOT IN"><?php _e('NOT IN', 'cwpfilter') ?></option>
                            </select>
                        </div>

                    </div>

                </div>

            </div>
            <!------------- options for extensions ------------------------>

            <?php
            if (!empty(CWPF_EXT::$includes['taxonomy_type_objects'])) {
                foreach (CWPF_EXT::$includes['taxonomy_type_objects'] as $obj) {
                    if (!empty($obj->taxonomy_type_additional_options)) {
                        foreach ($obj->taxonomy_type_additional_options as $_tax_key => $_tax_option) {
                            switch ($_tax_option['type']) {
                                case 'select':
                                    ?>
                                    <div class="cwpf_option_container cwpf_option_<?php echo $obj->html_type ?>">

                                        <div class="cwpf-form-element-container">

                                            <div class="cwpf-name-description">
                                                <strong><?php echo $_tax_option['title'] ?></strong>
                                                <span><?php echo $_tax_option['tip'] ?></span>
                                            </div>

                                            <div class="cwpf-form-element">

                                                <div class="select-wrap">
                                                    <select class="cwpf_popup_option" data-option="<?php echo $_tax_key ?>">
                                                        <?php foreach ($_tax_option['options'] as $val => $title): ?>
                                                            <option value="<?php echo $val ?>"><?php echo $title ?></option>
                                                        <?php endforeach; ?>
                                                    </select>
                                                </div>

                                            </div>

                                        </div>

                                    </div>
                                    <?php
                                    break;

                                case 'text':
                                    ?>
                                    <div class="cwpf_option_container cwpf_option_<?php echo $obj->html_type ?>">

                                        <div class="cwpf-form-element-container">

                                            <div class="cwpf-name-description">
                                                <strong><?php echo $_tax_option['title'] ?></strong>
                                                <span><?php echo $_tax_option['tip'] ?></span>
                                            </div>

                                            <div class="cwpf-form-element">
                                                <input type="text" class="cwpf_popup_option regular-text code" data-option="<?php echo $_tax_key ?>" placeholder="<?php echo(isset($_tax_option['placeholder']) ? $_tax_option['placeholder'] : '') ?>" value="" />
                                            </div>

                                        </div>

                                    </div>
                                    <?php
                                    break;

                                case 'image':
                                    ?>
                                    <div class="cwpf_option_container cwpf_option_<?php echo $obj->html_type ?>">

                                        <div class="cwpf-form-element-container">

                                            <div class="cwpf-name-description">
                                                <strong><?php echo $_tax_option['title'] ?></strong>
                                                <span><?php echo $_tax_option['tip'] ?></span>
                                            </div>

                                            <div class="cwpf-form-element">
                                                <input type="text" class="cwpf_popup_option regular-text code" data-option="<?php echo $_tax_key ?>" placeholder="<?php echo $option['placeholder'] ?>" value="" />
                                                <a href="#" class="button cwpf_select_image"><?php _e('select image', 'cwpfilter') ?></a>
                                            </div>

                                        </div>

                                    </div>
                                    <?php
                                    break;

                                default:
                                    break;
                            }
                        }
                    }
                }
            }
            ?>
        </div>
        <?php
        if (isset($cwpf_settings['tax_type'][$key])) {
            do_action('cwpf_print_tax_additional_options_' . $cwpf_settings['tax_type'][$key], $key);
        }
        ?>
    </li>
    <?php
}

//***

function cwpf_print_item_by_key($key, $cwpf_settings) {
    switch ($key) {
        case 'by_price':

            if (!isset($cwpf_settings[$key])) {
                $cwpf_settings[$key] = [];
            }

            if (!is_array($cwpf_settings)) {
                break;
            }
            ?>
            <li data-key="<?php echo $key ?>" class="cwpf_options_li">

                <?php
                $show = 0;
                if (isset($cwpf_settings[$key]['show'])) {
                    $show = $cwpf_settings[$key]['show'];
                }
                ?>

                <a href="#" class="help_tip cwpf_drag_and_drope" data-tip="<?php _e("drag and drope", 'cwpfilter'); ?>"><span class="cwpf-list-icons cwpf-list-move-button"></span></a>

                <strong style="display: inline-block; width: 176px;"><?php _e("Search by Price", 'cwpfilter'); ?>:</strong>

                <img class="help_tip" data-tip="<?php _e('Show woocommerce filter by price inside cwpf search form', 'cwpfilter') ?>" src="<?php echo WP_PLUGIN_URL ?>/woocommerce/assets/images/help.png" height="16" width="16" />

                <div class="select-wrap">
                    <select name="cwpf_settings[<?php echo $key ?>][show]" class="cwpf_setting_select">
                        <option value="0" <?php echo selected($show, 0) ?>><?php _e('No', 'cwpfilter') ?></option>
                        <option value="1" <?php echo selected($show, 1) ?>><?php _e('As woo range-slider', 'cwpfilter') ?></option>
                        <option value="2" <?php echo selected($show, 2) ?>><?php _e('As drop-down', 'cwpfilter') ?></option>
                        <option value="5" <?php echo selected($show, 5) ?>><?php _e('As radio button', 'cwpfilter') ?></option>
                        <option value="4" <?php echo selected($show, 4) ?>><?php _e('As textinputs', 'cwpfilter') ?></option>
                        <option value="3" <?php echo selected($show, 3) ?>><?php _e('As ion range-slider', 'cwpfilter') ?></option>

                    </select>
                </div>

                <span value="<?php _e('additional options', 'cwpfilter') ?>" data-key="<?php echo $key ?>" data-name="<?php _e("Search by Price", 'cwpfilter'); ?>" class="cwpf-list-icons js_cwpf_expand_options js_cwpf_expand_options_<?php echo $key ?>"></span>

                <?php
                if (!isset($cwpf_settings[$key]['show_button'])) {
                    $cwpf_settings[$key]['show_button'] = 0;
                }

                if (!isset($cwpf_settings[$key]['title_text'])) {
                    $cwpf_settings[$key]['title_text'] = '';
                }

                if (!isset($cwpf_settings[$key]['show_toggle_button'])) {
                    $cwpf_settings[$key]['show_toggle_button'] = 0;
                }
                if (!isset($cwpf_settings[$key]['ranges'])) {
                    $cwpf_settings[$key]['ranges'] = '';
                }

                if (!isset($cwpf_settings[$key]['first_option_text'])) {
                    $cwpf_settings[$key]['first_option_text'] = '';
                }

                if (!isset($cwpf_settings[$key]['ion_slider_step'])) {
                    $cwpf_settings[$key]['ion_slider_step'] = 0;
                }
                if (!isset($cwpf_settings[$key]['price_tax'])) {
                    $cwpf_settings[$key]['price_tax'] = 0;
                }

                if (!isset($cwpf_settings[$key]['tooltip_text'])) {
                    $cwpf_settings[$key]['tooltip_text'] = "";
                }
                ?>
                <input type="hidden" name="cwpf_settings[<?php echo $key ?>][tooltip_text]" placeholder="" value="<?php echo stripcslashes($cwpf_settings[$key]['tooltip_text']) ?>" />
                <input type="hidden" name="cwpf_settings[<?php echo $key ?>][show_button]" value="<?php echo $cwpf_settings[$key]['show_button'] ?>" />
                <input type="hidden" name="cwpf_settings[<?php echo $key ?>][title_text]" value="<?php echo $cwpf_settings[$key]['title_text'] ?>" />
                <input type="hidden" name="cwpf_settings[<?php echo $key ?>][show_toggle_button]" value="<?php echo $cwpf_settings[$key]['show_toggle_button'] ?>" />
                <input type="hidden" name="cwpf_settings[<?php echo $key ?>][ranges]" value="<?php echo $cwpf_settings[$key]['ranges'] ?>" />
                <input type="hidden" name="cwpf_settings[<?php echo $key ?>][first_option_text]" value="<?php echo $cwpf_settings[$key]['first_option_text'] ?>" />
                <input type="hidden" name="cwpf_settings[<?php echo $key ?>][ion_slider_step]" value="<?php echo $cwpf_settings[$key]['ion_slider_step'] ?>" />
                <input type="hidden" name="cwpf_settings[<?php echo $key ?>][price_tax]" value="<?php echo $cwpf_settings[$key]['price_tax'] ?>" />

                <div id="cwpf-modal-content-by_price" style="display: none;">

                    <div class="cwpf-form-element-container">

                        <div class="cwpf-name-description">
                            <strong><?php _e('Show button', 'cwpfilter') ?></strong>
                            <span><?php _e('Show button for woocommerce filter by price inside cwpf search form when it is dispayed as woo range-slider', 'cwpfilter') ?></span>
                        </div>

                        <div class="cwpf-form-element">

                            <?php
                            $show_button = array(
                                0 => __('No', 'cwpfilter'),
                                1 => __('Yes', 'cwpfilter')
                            );
                            ?>

                            <div class="select-wrap">
                                <select class="cwpf_popup_option" data-option="show_button">
                                    <?php foreach ($show_button as $show_button_key => $show_button_value) : ?>
                                        <option value="<?php echo $show_button_key; ?>"><?php echo $show_button_value; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                        </div>

                    </div>

                    <div class="cwpf-form-element-container">

                        <div class="cwpf-name-description">
                            <strong><?php _e('Title text', 'cwpfilter') ?></strong>
                            <span><?php _e('Text before the price filter range slider. Leave it empty if you not need it!', 'cwpfilter') ?></span>
                        </div>

                        <div class="cwpf-form-element">
                            <input type="text" class="cwpf_popup_option" data-option="title_text" placeholder="" value="" />
                        </div>

                    </div>
                    <div class="cwpf-form-element-container">

                        <div class="cwpf-name-description">
                            <strong><?php _e('Show toggle button', 'cwpfilter') ?></strong>
                            <span><?php _e('Show toggle button near the title on the front above the block of html-items', 'cwpfilter') ?></span>
                        </div>

                        <div class="cwpf-form-element">
                            <div class="select-wrap">
                                <select class="cwpf_popup_option" data-option="show_toggle_button">
                                    <option value="0"><?php _e('No', 'cwpfilter') ?></option>
                                    <option value="1"><?php _e('Yes, show as closed', 'cwpfilter') ?></option>
                                    <option value="2"><?php _e('Yes, show as opened', 'cwpfilter') ?></option>
                                </select>
                            </div>

                        </div>

                    </div>
                    <div class="cwpf-form-element-container">

                        <div class="cwpf-name-description">
                            <strong><?php _e('Tooltip', 'cwpfilter') ?></strong>
                            <span><?php _e('Show tooltip', 'cwpfilter') ?></span>
                        </div>

                        <div class="cwpf-form-element">

                            <div class="select-wrap">
                                <textarea class="cwpf_popup_option" data-option="tooltip_text" ></textarea>
                            </div>

                        </div>

                    </div>

                    <div class="cwpf-form-element-container">

                        <div class="cwpf-name-description">
                            <h3><?php _e('Drop-down OR radio', 'cwpfilter') ?></h3>
                            <strong><?php _e('Drop-down OR radio price filter ranges', 'cwpfilter') ?></strong>
                            <span><?php _e('Ranges for price filter.', 'cwpfilter') ?></span>
                            <!-- <span><?php //printf(__('Example: 0-50,51-100,101-i. Where "i" is infinity. Max price is %s.', 'cwpfilter'), CWPF_HELPER::get_max_price())               ?></span> -->
                            <span><?php echo __('Example: 0-50,51-100,101-i. Where "i" is infinity.', 'cwpfilter') ?></span>
                        </div>

                        <div class="cwpf-form-element">
                            <input type="text" class="cwpf_popup_option" data-option="ranges" placeholder="" value="" />
                        </div>

                    </div>

                    <div class="cwpf-form-element-container">

                        <div class="cwpf-name-description">
                            <strong><?php _e('Drop-down price filter text', 'cwpfilter') ?></strong>
                            <span><?php _e('Drop-down price filter first option text', 'cwpfilter') ?></span>
                        </div>

                        <div class="cwpf-form-element">
                            <input type="text" class="cwpf_popup_option" data-option="first_option_text" placeholder="" value="" />
                        </div>

                    </div>

                    <div class="cwpf-form-element-container">

                        <div class="cwpf-name-description">
                            <h3><?php _e('Ion Range slider', 'cwpfilter') ?></h3>
                            <strong><?php _e('Step', 'cwpfilter') ?></strong>
                            <span><?php _e('predifined step', 'cwpfilter') ?></span>
                        </div>

                        <div class="cwpf-form-element">
                            <input type="text" class="cwpf_popup_option" data-option="ion_slider_step" placeholder="" value="" />
                        </div>

                    </div>
                    <div class="cwpf-form-element-container">

                        <div class="cwpf-name-description">
                            <h3><?php _e('Taxes', 'cwpfilter') ?></h3>
                            <strong><?php _e('Tax', 'cwpfilter') ?></strong>
                            <span><?php _e('It will be counted in the filter( Only for ion-slider )', 'cwpfilter') ?></span>
                        </div>

                        <div class="cwpf-form-element">
                            <input type="text" class="cwpf_popup_option" data-option="price_tax" placeholder="" value="" />
                        </div>

                    </div>
                </div>
            </li>
            <?php
            break;

        default:
            //options for extensions

            do_action('cwpf_print_html_type_options_' . $key);
            break;
    }
}
