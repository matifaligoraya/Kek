jQuery(document).bind('cleverswatch_update_gallery', function (event, response) {
    new VitrineTheme;
});