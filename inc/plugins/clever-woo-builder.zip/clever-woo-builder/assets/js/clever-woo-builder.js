//Disable photoswipe of WooCommerce and replace by custom function.
if (typeof wc_single_product_params != 'undefined') {
    wc_single_product_params.photoswipe_enabled = false;
}

(function ($, elementorFrontend) {

    "use strict";

    var CleverWooBuilder = {

        init: function () {

            var widgets = {
                'clever-single-images.default': CleverWooBuilder.productImages,
                'clever-single-related.default': CleverWooBuilder.relatedProduct,
                'clever-single-recent-viewed-products.default': CleverWooBuilder.recentViewedProduct,
                'clever-single-add-to-cart.default': CleverWooBuilder.addToCart,
                'clever-single-tabs.default': CleverWooBuilder.productTabs,
                'clever-woo-products.default': CleverWooBuilder.widgetProducts,
                'clever-woo-categories.default': CleverWooBuilder.widgetCategories,
                'clever-single-get-order-time.default': CleverWooBuilder.productGetOrderTime,
                'clever-single-cart-extend.default': CleverWooBuilder.ExtendCartInfo,
                'clever-woo-builder-archive-quick-view.default': CleverWooBuilder.QuickView,
            };
            $.each(widgets, function (widget, callback) {
                elementorFrontend.hooks.addAction('frontend/element_ready/' + widget, callback);
            });

            if ($.browser && $.browser.safari) {
                document.addEventListener('click', function (event) {
                    if (event.target.matches('.add_to_cart_button') || event.target.matches('.single_add_to_cart_button')) {
                        event.target.focus();
                    }
                });
            }

            $(document).on('clever-filter-content-rendered', CleverWooBuilder.reInitCarousel);
            $(document).on('cleverswatch_update_gallery', function () {
                CleverWooBuilder.productImages($('.elementor-clever-single-images.clever-woo-builder'))
            });

            elementorFrontend.hooks.addFilter('clever-popup/widget-extensions/popup-data', CleverWooBuilder.prepareCleverPopup);
            $(window).on('clever-popup/render-content/ajax/success', CleverWooBuilder.cleverPopupLoaded);
            $(document).on('wc_update_cart added_to_cart', CleverWooBuilder.cleverCartPopupOpen);

            $(document).on('click', '.clever-woo-switcher-btn', CleverWooBuilder.gridListSwitcher);

            $(document).on('click', '.cwb-archive-quick-view', CleverWooBuilder.QuickView);
            $(document).on('click', '.cwb-mask-close.mask-quick-view, .close-quickview', function () {
                $('.cwb-mask-close.mask-quick-view').removeClass('active');
                $('#cwb-quickview-lb').attr('style','');
            });

        },

        gridListSwitcher: function (event) {

            event.preventDefault();

            var layout = $(document).find('.clever-woo-products-wrapper').data('layout-switcher'),
                activeLayout = $(event.currentTarget).hasClass('clever-woo-switcher-btn-main') ? layout.main : layout.secondary,
                activeControl = $(document).find('.clever-woo-switcher-controls-wrapper .clever-woo-switcher-btn'),
                productsWrapper = $(document).find('.clever-woo-products-wrapper');

            if (window.CleverSmartFilters && window.CleverSmartFilters.filterGroups['woocommerce-archive/default']) {
                var cleverSmartFiltersProvider = window.CleverSmartFilters.filterGroups['woocommerce-archive/default'],
                    cleverSmartFiltersQuery = cleverSmartFiltersProvider.query;
            }

            if (!$(event.currentTarget).hasClass('active')) {
                if (activeControl.hasClass('active')) {
                    activeControl.removeClass('active');
                }

                $(event.currentTarget).addClass('active');
            }

            $.ajax({
                type: 'POST',
                url: window.cleverWooBuilderData.ajax_url,
                data: {
                    action: 'clever_woo_builder_get_layout',
                    query: window.cleverWooBuilderData.products,
                    layout: activeLayout,
                    filters: cleverSmartFiltersQuery
                },
                beforeSend: function (xhr) {
                    productsWrapper.addClass('clever-layout-loading');
                },
                success: function (data) {
                    productsWrapper.removeClass('clever-layout-loading');
                    productsWrapper.html(data);
                }
            });

        },

        cleverPopupLoaded: function (event, popupData) {
            setTimeout(function () {
                $(window).trigger('resize');

                $('.clever-popup .woocommerce-product-gallery.images').each(function (e) {
                    $(this).wc_product_gallery();
                });
            }, 500);
        },

        prepareCleverPopup: function (popupData, widgetData, $scope, event) {

            if (widgetData['is-clever-woo-builder']) {
                var $product;
                popupData['isCleverWooBuilder'] = true;
                popupData['templateId'] = widgetData['clever-woo-builder-qv-template'];

                if ($scope.hasClass('elementor-widget-clever-woo-products') || $scope.hasClass('elementor-widget-clever-woo-products-list')) {
                    $product = $(event.target).parents('.clever-woo-builder-product');
                } else {
                    $product = $scope.parents('.clever-woo-builder-product');
                }

                if ($product.length) {
                    popupData['productId'] = $product.data('product-id');
                }
            }

            return popupData;

        },
        relatedProduct: function ($scope) {
            CleverWooBuilder.productsCarousel($scope);
        },
        recentViewedProduct: function ($scope) {
            CleverWooBuilder.productsCarousel($scope);
        },
        productsCarousel:function($scope){
            $scope.find('.carousel-layout.products').each(function () {
                let config = JSON.parse($(this).attr('data-cwb-config'));
                let $current = $(this);
                $current.slick({
                    slidesToShow: config.slidesToShow!=""?config.slidesToShow:1,
                    slidesToScroll: 1,
                    rows: 0,
                    rtl: $('body.rtl')[0] ? true : false,
                    swipe: true,
                    arrows: config.arrows == "true",
                    dots: config.dots == "true",
                    prevArrow: '<span class="cwb-carousel-btn prev-item"><i class="' + config.arrow_left + '"></i></span>',
                    nextArrow: '<span class="cwb-carousel-btn next-item "><i class="' + config.arrow_right + '"></i></span>',
                    responsive: [
                        {
                            breakpoint: 768,
                            settings: {
                                slidesToShow: config.slidesToShow_tablet!=""?config.slidesToShow_tablet:1
                            }
                        },
                        {
                            breakpoint: 556,
                            settings: {
                                slidesToShow: config.slidesToShow_mobile!=""?config.slidesToShow_mobile:1
                            }
                        }
                    ]
                });
            })
        },
        productImages: function ($scope) {

            $scope.find('.cwb-single-images:not(.grid-layout)').each(function () {
                let config = JSON.parse($(this).attr('data-slider'));
                let $current = $(this);
                $(this).find('.wrap-main-product-gallery').slick({
                    slidesToShow: ($current.hasClass('carousel-layout') ? parseInt(config.slidesToShow) : 1),
                    slidesToScroll: 1,
                    rows: 0,
                    rtl: $('body.rtl')[0] ? true : false,
                    swipe: true,
                    arrows: config.arrows == "true",
                    dots: config.dots == "true",
                    centerMode: config.center_mod == "true",
                    centerPadding: config.center_padding,
                    prevArrow: '<span class="cwb-carousel-btn prev-item"><i class="' + config.arrow_left + '"></i></span>',
                    nextArrow: '<span class="cwb-carousel-btn next-item "><i class="' + config.arrow_right + '"></i></span>',
                    asNavFor: ($current.hasClass('carousel-layout') ? '' : '.cwb-single-images .wrap-list-thumbnail'),
                    responsive: [
                        {
                            breakpoint: 768,
                            settings: {
                                centerPadding: config.center_padding_tablet,
                                slidesToShow: ($current.hasClass('carousel-layout') ? parseInt(config.slidesToShow_tablet) : 1)
                            }
                        },
                        {
                            breakpoint: 556,
                            settings: {
                                centerPadding: config.center_padding_mobile,
                                slidesToShow: ($current.hasClass('carousel-layout') ? parseInt(config.slidesToShow_mobile) : 1)
                            }
                        }
                    ]
                });
                if ($(this).find('.wrap-list-thumbnail')[0]) {
                    $(this).find('.wrap-list-thumbnail').slick({
                        slidesToShow: config.slidesToShow,
                        slidesToScroll: 1,
                        rows: 0,
                        rtl: $('body.rtl')[0] ? true : false,
                        swipe: true,
                        arrows: config.thumb_arrows == "true",
                        prevArrow: '<span class="cwb-carousel-btn prev-item"><i class="' + config.thumb_arrow_left + '"></i></span>',
                        nextArrow: '<span class="cwb-carousel-btn next-item "><i class="' + config.thumb_arrow_right + '"></i></span>',
                        asNavFor: '.cwb-single-images .wrap-main-product-gallery',
                        vertical: config.isVertical == "1",
                        verticalSwiping: config.isVertical == "1",
                        focusOnSelect: true,
                        responsive: [
                            {
                                breakpoint: 768,
                                settings: {
                                    slidesToShow: config.slidesToShow_tablet
                                }
                            },
                            {
                                breakpoint: 556,
                                settings: {
                                    slidesToShow: config.slidesToShow_mobile
                                }
                            }
                        ]
                    });
                }
            })

            let w_width = '';
            $(window).resize(function () {
                if (w_width != $(window).width()) {
                    if (typeof $.fn.zoom != 'undefined') {
                        $scope.find('.woocommerce-product-gallery__image a').trigger('zoom.destroy');
                        if ($(window).width() > 768) {
                            $scope.find('.woocommerce-product-gallery__image a').zoom();
                        }
                    }
                    if ($(window).width() > 768) {
                        if ($('.cwb-single-images.grid-layout .wrap-main-product-gallery.slick-initialized')[0]) {
                            $('.cwb-single-images.grid-layout.wrap-main-product-gallery.slick-initialized').slick('unslick');
                        }
                    } else {
                        $scope.find('.cwb-single-images.grid-layout').each(function () {
                            let config = JSON.parse($(this).attr('data-slider'));
                            let $current = $(this);
                            $(this).find('.wrap-main-product-gallery').slick({
                                slidesToShow:  parseInt(config.slidesToShow),
                                slidesToScroll: 1,
                                rows: 0,
                                rtl: $('body.rtl')[0] ? true : false,
                                swipe: true,
                                arrows: config.arrows == "true",
                                dots: config.dots == "true",
                                prevArrow: '<span class="cwb-carousel-btn prev-item"><i class="' + config.arrow_left + '"></i></span>',
                                nextArrow: '<span class="cwb-carousel-btn next-item "><i class="' + config.arrow_right + '"></i></span>',
                                responsive: [
                                    {
                                        breakpoint: 768,
                                        settings: {
                                            slidesToShow:  parseInt(config.slidesToShow_tablet)
                                        }
                                    },
                                    {
                                        breakpoint: 556,
                                        settings: {
                                            slidesToShow:  parseInt(config.slidesToShow_mobile)
                                        }
                                    }
                                ]
                            });
                        })
                    }
                    w_width = $(window).width();
                }
            }).resize();
            CleverWooBuilder.productImgLightBox();
        },
        //Gallery light box
        productImgLightBox: function () {
            $(document).on('click', '.cwb-single-images .wrap-main-product-gallery .woocommerce-product-gallery__image a', function (e) {
                e.preventDefault();
                if (typeof PhotoSwipe != 'undefined') {
                    let pswpElement = $('.pswp')[0],
                        items = CleverWooBuilder.GetGalleryItems(),
                        c_index = $(this).parent().index();

                    if ($(this).closest('.slick-slide')[0]) {
                        c_index = $(this).closest('.slick-slide').data('slick-index');
                    }
                    let options = {
                        index: c_index,
                        shareEl: false,
                        closeOnScroll: false,
                        history: false,
                        hideAnimationDuration: 0,
                        showAnimationDuration: 0
                    };
                    // Initializes and opens PhotoSwipe.
                    let photoswipe = new PhotoSwipe(pswpElement, PhotoSwipeUI_Default, items, options);
                    photoswipe.init();
                }
            });
        },
        //Push product images to list
        GetGalleryItems: function () {
            let $slides, items = [];
            $slides = $('.wrap-main-product-gallery').find('.woocommerce-product-gallery__image:not(.slick-cloned)');
            if ($slides.length > 0) {
                $slides.each(function (i, el) {
                    var img = $(el).find('img'),
                        large_image_src = img.attr('data-large_image'),
                        large_image_w = img.attr('data-large_image_width'),
                        large_image_h = img.attr('data-large_image_height'),
                        item = {
                            src: large_image_src,
                            w: large_image_w,
                            h: large_image_h,
                            title: img.attr('title')
                        };
                    items.push(item);
                });
            }
            return items;
        },
        addToCart: function ($scope) {
            //QTY
            if ($('.qty-nav')[0]) {
                $(document).on("click", '.quantity .qty-nav', function () {

                    var qty = $(this).parents('.quantity').find('input.qty');
                    var val = parseInt(!!qty.val()?qty.val():0);
                    if (Number.isNaN(val)) {
                        val = 0;
                    }
                    if ($(this).hasClass('increase')) {
                        qty.val(val + 1);
                    } else {
                        if (val > 1) {
                            qty.val(val - 1);
                        }
                    }
                    qty.trigger('change');
                });
            }

            //CountDown
            $(document).on("show_variation", ".variations_form:not(.cw-form-data)", function () {
                var $this = $('.variations_form [data-countdown="countdown"]');
                if ($this[0]) {
                    var $date = $this.data('date').split("-");
                    $this.lofCountDown({
                        TargetDate: $date[0] + "/" + $date[1] + "/" + $date[2] + " " + $date[3] + ":" + $date[4] + ":" + $date[5],
                        DisplayFormat: "<div class=\"countdown-times\"><div class=\"day\">%%D%% Days </div><div class=\"hours\">%%H%% Hours </div><div class=\"minutes\">%%M%% Mins </div><div class=\"seconds\">%%S%% Secs </div></div>",
                        FinishMessage: "Expired"
                    });
                }
            });
            if ($('.use-ajax')[0]) {
                //Buy now button
                $(document).on('cleverswatch_button_select_option', function (event, response) {
                    var add_to_cart_button = response.selector;
                    add_to_cart_button.closest('.variations_form').find('.cwb-buy-now').addClass('disabled');
                });
                //Bind for button if button is Add to Cart
                $(document).on('cleverswatch_button_add_cart', function (event, response) {
                    var add_to_cart_button = response.selector;
                    add_to_cart_button.closest('.variations_form').find('.cwb-buy-now').removeClass('disabled');
                });
                //Bind for button if button is Out of stock
                $(document).on('cleverswatch_button_out_stock', function (event, response) {
                    var add_to_cart_button = response.selector;
                    add_to_cart_button.closest('.variations_form').find('.cwb-buy-now').addClass('disabled');
                });
                $(document).on('cleverswatch_update_gallery', function (event, response) {

                    var $this = $('.variations_form [data-countdown="countdown"]');
                    if ($this[0]) {
                        var $date = $this.data('date').split("-");
                        $this.lofCountDown({
                            TargetDate: $date[0] + "/" + $date[1] + "/" + $date[2] + " " + $date[3] + ":" + $date[4] + ":" + $date[5],
                            DisplayFormat: "<div class=\"countdown-times\"><div class=\"day\">%%D%% Days </div><div class=\"hours\">%%H%% Hours </div><div class=\"minutes\">%%M%% Mins </div><div class=\"seconds\">%%S%% Secs </div></div>",
                            FinishMessage: "Expired"
                        });
                    }
                });
                $(window).resize(function () {
                    if ($(window).width() > 769 && $('.zoo-cw-is-desktop')[0]) {
                        $(document).on('mouseenter mouseleave click', '.variations_form .zoo-cw-attribute-option',
                            function () {
                                var $this = $('.variations_form [data-countdown="countdown"]');
                                if ($this[0]) {
                                    var $date = $this.data('date').split("-");
                                    $this.lofCountDown({
                                        TargetDate: $date[0] + "/" + $date[1] + "/" + $date[2] + " " + $date[3] + ":" + $date[4] + ":" + $date[5],
                                        DisplayFormat: "<div class=\"countdown-times\"><div class=\"day\">%%D%% Days </div><div class=\"hours\">%%H%% Hours </div><div class=\"minutes\">%%M%% Mins </div><div class=\"seconds\">%%S%% Secs </div></div>",
                                        FinishMessage: "Expired"
                                    });
                                }
                            });
                    }
                }).resize();

                //Single Add to cart
                if (typeof wc_add_to_cart_params != 'undefined') {
                    $(document).on('click', 'button.single_add_to_cart_button:not(.disabled)', function (e) {
                        e.preventDefault();
                        var $thisbutton = $(this);
                        if($thisbutton.closest('form').attr('method')=="get"){
                            let url =$thisbutton.closest('form').attr('action');
                            window.location.href=url;
                        }
                        var max = parseInt(($thisbutton).closest('form').find('input.qty').attr('max'));
                        var qty = parseInt(($thisbutton).closest('form').find('input.qty').val());
                        var $form = $thisbutton.closest('form.cart'),
                            id = $thisbutton.val(),
                            product_qty = $form.find('input[name=quantity]').val() || 1,
                            product_id = $form.find('input[name=product_id]').val() || id,
                            variation_id = $form.find('input[name=variation_id]').val() || 0;
                        var variations = {};

                        if (!product_id) {
                            return true;
                        }
                        $form.find('select').each(function () {
                            variations[$(this).attr('name')] = $(this).val();
                        });
                        if (!!max && (max < qty)) {
                            alert('Value must be less than or equal to ' + max);
                            return;
                        }
                        if ($thisbutton.hasClass('cart-added')) {
                            window.location = wc_add_to_cart_params.cart_url;
                            return false;
                        }
                        if ($form.find('.woocommerce_gc_giftcard_form')[0]) {
                            return true;
                        }

                        var data = {
                            action: 'woocommerce_ajax_add_to_cart',
                            product_id: product_id,
                            product_sku: '',
                            quantity: product_qty,
                            variation_id: variation_id,
                            variations: variations,
                        };

                        $(document.body).trigger('adding_to_cart', [$thisbutton, data]);
                        $.ajax({
                            type: 'post',
                            url: wc_add_to_cart_params.ajax_url,
                            data: data,
                            beforeSend: function (response) {
                                $thisbutton.removeClass('added').addClass('loading');
                            },
                            complete: function (response) {
                                $thisbutton.addClass('added').removeClass('loading');
                            },
                            success: function (response) {
                                if (response.error & response.product_url) {
                                    window.location = response.product_url;
                                    return;
                                } else {
                                    $(document.body).trigger('added_to_cart', [response.fragments, response.cart_hash, $thisbutton]);
                                    if ($thisbutton.hasClass('cwb-buy-now')) {
                                        window.location = cwb_wc_checkout_url;
                                        return false;
                                    }
                                }
                            },
                        });
                        return false;
                    });
                }
            }

            if ($('body').hasClass('single-product')) {
                return;
            }

            if (typeof wc_add_to_cart_variation_params !== 'undefined') {
                $scope.find('.variations_form').each(function () {
                    $(this).wc_variation_form();
                });
            }

        },

        productTabs: function ($scope) {

            $scope.find('.clever-single-tabs__loading').remove();

            var hash = window.location.hash;
            var url = window.location.href;
            var $tabs = $scope.find('.wc-tabs, ul.tabs').first();

            $tabs.find('a').addClass('elementor-clickable');

            $scope.find('.wc-tab, .woocommerce-tabs .panel:not(.panel .panel)').hide();

            if (hash.toLowerCase().indexOf('comment-') >= 0 || hash === '#reviews' || hash === '#tab-reviews') {
                $tabs.find('li.reviews_tab a').click();
            } else if (url.indexOf('comment-page-') > 0 || url.indexOf('cpage=') > 0) {
                $tabs.find('li.reviews_tab a').click();
            } else if (hash === '#tab-additional_information') {
                $tabs.find('li.additional_information_tab a').click();
            } else {
                $tabs.find('li:first a').click();
            }
            if($('.wrap-off-canvas-tab')[0]){
                $(document).on('click','.off-canvas-tab-control a',function (e) {
                    e.preventDefault();
                    let id=$(this).attr('href');
                    $(this).closest('.off-canvas-layout').find('.wrap-off-canvas-tab').addClass('active').fadeIn();
                    $(id).addClass('active');

                    $('body').addClass('overflow')
                });
                $(document).on('click','.close-off-canvas-tab',function (e) {
                    e.preventDefault();
                    $(this).closest('.wrap-off-canvas-tab').removeClass('active').fadeOut();
                    $(this).closest('.wrap-off-canvas-tab').find('.wc-tab.active').removeClass('active');
                    $('body').removeClass('overflow')
                })
            }
            if ($('.cwb-group-accordion')[0]) {
                $('.cwb-product-data-tabs .accordion-active .wc-tab').show();
                $(document).on('click', '.tabs li a', function () {
                    $('.cwb-group-accordion.accordion-active').removeClass('accordion-active');
                    $($(this).attr('href')).closest('.cwb-group-accordion').addClass('accordion-active');
                });
                $(document).on('click', '.cwb-group-accordion .tab-heading', function () {
                    let tab_is_activated = $(this).closest('.accordion-active')[0];
                    $('.cwb-product-data-tabs .accordion-active .wc-tab').slideUp();
                    $('.cwb-product-data-tabs .accordion-active').removeClass('accordion-active');
                    if (!tab_is_activated) {
                        $(this).closest('.cwb-group-accordion').toggleClass('accordion-active');
                        $(this).next('.wc-tab').slideToggle();

                        if ($('.cwb-product-data-tabs .tabs.wc-tabs')[0]) {
                            let id = $(this).next('.wc-tab').attr('id');
                            $('.cwb-product-data-tabs .tabs.wc-tabs .active').removeClass('active');
                            $('.cwb-product-data-tabs .tabs.wc-tabs a[href="#' + id + '"]').parent().addClass('active');
                        }
                    }
                });
            }
            if ($('.cwb-get-order-notice .end-of-day')[0]) {
                var offset = $('.end-of-day').data('timezone');
                var day = new Date();
                var utc = day.getTime() + (day.getTimezoneOffset() * 60000);
                let d = new Date(utc + (3600000 * offset)),
                    duration = 60 * (60 - d.getMinutes());
                let timer = duration, minutes;
                let hours = (23 - d.getHours());
                hours = hours < 10 ? '0' + hours : hours;
                let label_h = $('.cwb-get-order-notice .end-of-day').data('hours');
                let label_m = $('.cwb-get-order-notice .end-of-day').data('minutes');
                setInterval(function () {
                    minutes = parseInt(timer / 60, 10);
                    minutes = minutes < 10 ? "0" + minutes : minutes;
                    $('.cwb-get-order-notice .end-of-day').text(hours + ' ' + label_h + ' ' + minutes + ' ' + label_m);
                    if (--timer < 0) {
                        timer = duration;
                    }
                }, 1000);
            }

        },

        productGetOrderTime: function ($scope) {
            if ($('.cwb-get-order-notice .end-of-day')[0]) {
                var offset = $('.end-of-day').data('timezone');
                var day = new Date();
                var utc = day.getTime() + (day.getTimezoneOffset() * 60000);
                let d = new Date(utc + (3600000 * offset)),
                    duration = 60 * (60 - d.getMinutes());
                let timer = duration, minutes;
                let hours = (23 - d.getHours());
                hours = hours < 10 ? '0' + hours : hours;
                let label_h = $('.cwb-get-order-notice .end-of-day').data('hours');
                let label_m = $('.cwb-get-order-notice .end-of-day').data('minutes');
                setInterval(function () {
                    minutes = parseInt(timer / 60, 10);
                    minutes = minutes < 10 ? "0" + minutes : minutes;
                    $('.cwb-get-order-notice .end-of-day').text(hours + ' ' + label_h + ' ' + minutes + ' ' + label_m);
                    if (--timer < 0) {
                        timer = duration;
                    }
                }, 1000);
            }
        },

        widgetProducts: function ($scope) {

            var $target = $scope.find('.clever-woo-carousel');

            if (!$target.length) {
                return;
            }

            CleverWooBuilder.initCarousel($target, $target.data('slider_options'));

        },

        widgetCategories: function ($scope) {

            var $target = $scope.find('.clever-woo-carousel');

            if (!$target.length) {
                return;
            }

            CleverWooBuilder.initCarousel($target, $target.data('slider_options'));

        },

        reInitCarousel: function (event, $scope) {
            CleverWooBuilder.widgetProducts($scope);
        },

        initCarousel: function ($target, options) {

            var mobileSlides, tabletSlides, desktopSlides, defaultOptions, visibleSlides,
                $slidesCount = $target.find('.swiper-slide').length;

            if (options.slidesToShow.mobile) {
                mobileSlides = options.slidesToShow.mobile;
            } else {
                mobileSlides = 1;
            }

            if (options.slidesToShow.tablet) {
                tabletSlides = options.slidesToShow.tablet;
            } else {
                tabletSlides = 1 === options.slidesToShow.desktop ? 1 : 2;
            }

            desktopSlides = options.slidesToShow.desktop;

            if ($(window).width() < 768) {
                visibleSlides = mobileSlides;
            } else if ($(window).width() < 1025) {
                visibleSlides = tabletSlides;
            } else {
                visibleSlides = desktopSlides;
            }

            defaultOptions = {
                slidesPerView: 1,
                breakpoints: {
                    0: {
                        slidesPerView: mobileSlides,
                        slidesPerGroup: 1,
                    },
                    768: {
                        slidesPerView: tabletSlides,
                        slidesPerGroup: 1,
                    },
                    1025: {
                        slidesPerView: desktopSlides
                    },
                },
                pagination: {
                    el: '.swiper-pagination',
                    clickable: true,
                },
                navigation: {
                    nextEl: '.clever-swiper-button-next',
                    prevEl: '.clever-swiper-button-prev',
                },
            };

            if ($slidesCount > visibleSlides) {
                new Swiper($target, $.extend({}, defaultOptions, options));
                $target.find('.clever-arrow').show();
            } else if (options.direction === 'vertical') {
                $target.addClass('swiper-container-vertical');
                $target.find('.clever-arrow').hide();
            } else {
                $target.find('.clever-arrow').hide();
            }
        },

        cleverCartPopupOpen: function (event) {
            var $target_enable = $(event.currentTarget.activeElement).parents('.clever-woo-products, .clever-woo-products-list, .clever-woo-builder-archive-add-to-cart, .clever-woo-builder-single-ajax-add-to-cart').data('cart-popup-enable'),
                $target_id = $(event.currentTarget.activeElement).parents('.clever-woo-products, .clever-woo-products-list, .clever-woo-builder-archive-add-to-cart, .clever-woo-builder-single-ajax-add-to-cart').data('cart-popup-id');

            $target_id = $($target_id)[0];

            if ($target_enable) {
                $(window).trigger({
                    type: 'clever-popup-open-trigger',
                    popupData: {
                        popupId: 'clever-popup-' + $target_id
                    }
                });
            }
        },
        ExtendCartInfo: function () {
            $(document).on('click', '.cwb-cart-extend-info-item >a', function (e) {
                e.preventDefault();
                let $parent=$(this).closest('.elementor-clever-single-cart-extend');
                $parent.find('.cwb-wrap-content-popup-page').addClass('active');
                $parent.find('.cwb-close-extend-cart-info').addClass('active');
                $($(this).data('target')).addClass('active');
            });
            $(document).on('click', '.cwb-close-extend-cart-info, .cwb-wrap-content-popup-page .cwb-close-popup-page', function () {
                $('.cwb-wrap-content-popup-page.active').removeClass('active');
                $('.cwb-close-extend-cart-info.active').removeClass('active');
                $('.cwb-content-popup-page.active').removeClass('active');
            });
        },
        QuickView: function (e) {
            if(!$('.cwb-mask-close')[0]){
                $('body').append('<div class="cwb-mask-close"></div>')
            }
            $('.cwb-mask-close').addClass('loading active mask-quick-view');
            var load_product_id = $(e.currentTarget).attr('data-id');
            var data = {action: 'clever_woo_builder_ajax_quick_view', product_id: load_product_id};
            $(this).parent().addClass('loading');
            var $this = $(e.currentTarget);
            $.ajax({
                url: ajaxurl,
                data: data,
                type: "POST",
                success: function (response) {
                    $('body').append(response);
                    $this.parent().removeClass('loading');
                    // Variation Form
                    // var form_variation = $(document).find('#cwb-quickview-lb .variations_form');
                    // form_variation.wc_variation_form();
                    // form_variation.trigger('check_variations');
                    setTimeout(function () {
                        $('#cwb-quickview-lb').css('opacity', '1');
                        $('#cwb-quickview-lb').css('top', '50%');
                    }, 100);
                }
            });

        }

    };

    $(window).on('elementor/frontend/init', CleverWooBuilder.init);

}(jQuery, window.elementorFrontend));