(function( $ ) {

	'use strict';

	var CleverwooTemplatePopup = {

		init: function() {

			var self = this;

			$( document )
				.on( 'click.CleverwooTemplatePopup', '.page-title-action', self.openPopup )
				.on( 'click.CleverwooTemplatePopup', '.clever-template-popup__overlay', self.closePopup )
				.on( 'change.CleverwooTemplatePopup', '#template_type', self.switchTemplates )
				.on( 'click.CleverwooTemplatePopup', '.clever-template-popup__item--uncheck', self.uncheckItem )
				.on( 'click.CleverwooTemplatePopup', '.clever-template-popup__label', self.isCheckedItem );

		},

		switchTemplates: function() {
			var $this = $( this ),
				value = $this.find( 'option:selected' ).val();

			if ( '' !== value ) {
				if ( value === 'clever-woo-builder-cart' || value === 'clever-woo-builder-thankyou' || value === 'clever-woo-builder-myaccount' || value === 'clever-woo-builder-checkout' ) {
					$( '.predesigned-row' ).removeClass( 'is-active' );
					$( '.clever-template-popup__subheading' ).hide();
				} else {
					$( '.predesigned-row.template-' + value ).addClass( 'is-active' ).siblings().removeClass( 'is-active' );
					$( '.clever-template-popup__subheading' ).show();
				}
			}
		},

		isCheckedItem: function() {
			var $this = $( this ),
				value = $this.find('input'),
				checked = value.prop( "checked" );

			CleverwooTemplatePopup.uncheckAll();

			if( checked ){
				$this.addClass( 'is--checked');
			}
		},

		uncheckAll: function() {
			var item = $( '.clever-template-popup__label' );

			if( item.hasClass('is--checked') ){
				item.removeClass('is--checked');
				item.find('input').prop( "checked", false );
			}
		},

		uncheckItem: function() {
			var $this = $( this ),
				label = $this.parent().find('.clever-template-popup__label'),
				input = label.find('input'),
				checked = input.prop( "checked" );

			if( checked ){
				input.prop( "checked", false );
				label.removeClass('is--checked');
			}
		},

		openPopup: function( event ) {
			event.preventDefault();
			$( '.clever-template-popup' ).addClass( 'clever-template-popup-active' );

			CleverwooTemplatePopup.uncheckAll();
		},

		closePopup: function() {
			$( '.clever-template-popup' ).removeClass( 'clever-template-popup-active' );
		}

	};

	CleverwooTemplatePopup.init();

})( jQuery );