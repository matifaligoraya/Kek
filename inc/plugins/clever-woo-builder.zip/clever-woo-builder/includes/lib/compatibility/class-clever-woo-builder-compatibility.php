<?php

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

if ( ! class_exists( 'Clever_Woo_Builder_Compatibility' ) ) {

	/**
	 * Define Clever_Woo_Builder_Compatibility class
	 */
	class Clever_Woo_Builder_Compatibility {

		/**
		 * A reference to an instance of this class.
		 *
		 * @since 1.0.0
		 * @var   object
		 */
		private static $instance = null;

		/**
		 * Constructor for the class
		 */
		public function init() {
			// WPML String Translation plugin exist check
			if ( defined( 'WPML_ST_VERSION' ) ) {
				add_filter( 'wpml_elementor_widgets_to_translate', array( $this, 'add_translatable_nodes' ) );
				add_filter( 'clever-woo-builder/current-template/template-id', array( $this, 'clever_woo_builder_modify_template_id' ) );
			}
		}


		function clever_woo_builder_modify_template_id( $template_id ) {
			// WPML String Translation plugin exist check
			return apply_filters( 'wpml_object_id', $template_id, clever_woo_builder_post_type()->slug(), true );
		}

		/**
		 * Load required files.
		 *
		 * @return void
		 */
		public function load_files() {
		}

		/**
		 * Add clever elements translation nodes
		 *
		 * @param array
		 */
		public function add_translatable_nodes( $nodes_to_translate ) {

			$nodes_to_translate[ 'clever-woo-products' ] = array(
				'conditions' => array( 'widgetType' => 'clever-woo-products' ),
				'fields'     => array(
					array(
						'field'       => 'sale_badge_text',
						'type'        => esc_html__( 'Clever Woo Products Grid: Set sale badge text', 'clever-woo-builder' ),
						'editor_type' => 'LINE',
					),
				),
			);

			$nodes_to_translate[ 'clever-woo-categories' ] = array(
				'conditions' => array( 'widgetType' => 'clever-woo-categories' ),
				'fields'     => array(
					array(
						'field'       => 'count_before_text',
						'type'        => esc_html__( 'Clever Woo Categories Grid: Count Before Text', 'clever-woo-builder' ),
						'editor_type' => 'LINE',
					),
					array(
						'field'       => 'count_after_text',
						'type'        => esc_html__( 'Clever Woo Categories Grid: Count After Text', 'clever-woo-builder' ),
						'editor_type' => 'LINE',
					),
					array(
						'field'       => 'desc_after_text',
						'type'        => esc_html__( 'Clever Woo Categories Grid: Trimmed After Text', 'clever-woo-builder' ),
						'editor_type' => 'LINE',
					),
				),
			);

			$nodes_to_translate[ 'clever-woo-taxonomy-tiles' ] = array(
				'conditions' => array( 'widgetType' => 'clever-woo-taxonomy-tiles' ),
				'fields'     => array(
					array(
						'field'       => 'count_before_text',
						'type'        => esc_html__( 'Clever Woo Taxonomy Tiles: Count Before Text', 'clever-woo-builder' ),
						'editor_type' => 'LINE',
					),
					array(
						'field'       => 'count_after_text',
						'type'        => esc_html__( 'Clever Woo Taxonomy Tiles: Count After Text', 'clever-woo-builder' ),
						'editor_type' => 'LINE',
					),
				),
			);

			$nodes_to_translate[ 'clever-single-attributes' ] = array(
				'conditions' => array( 'widgetType' => 'clever-single-attributes' ),
				'fields'     => array(
					array(
						'field'       => 'block_title',
						'type'        => esc_html__( 'Clever Woo Single Attributes: Title Text', 'clever-woo-builder' ),
						'editor_type' => 'LINE',
					),
				),
			);

			$nodes_to_translate[ 'clever-woo-builder-archive-sale-badge' ] = array(
				'conditions' => array( 'widgetType' => 'clever-woo-builder-archive-sale-badge' ),
				'fields'     => array(
					array(
						'field'       => 'block_title',
						'type'        => esc_html__( 'Clever Woo Archive Sale Badge: Sale Badge Text', 'clever-woo-builder' ),
						'editor_type' => 'LINE',
					),
				),
			);

			$nodes_to_translate[ 'clever-woo-builder-archive-category-count' ] = array(
				'conditions' => array( 'widgetType' => 'clever-woo-builder-archive-category-count' ),
				'fields'     => array(
					array(
						'field'       => 'archive_category_count_before_text',
						'type'        => esc_html__( 'Clever Woo Archive Category Count: Count Before Text', 'clever-woo-builder' ),
						'editor_type' => 'LINE',
					),
				),
			);

			$nodes_to_translate[ 'clever-woo-builder-archive-category-count' ] = array(
				'conditions' => array( 'widgetType' => 'clever-woo-builder-archive-category-count' ),
				'fields'     => array(
					array(
						'field'       => 'archive_category_count_after_text',
						'type'        => esc_html__( 'Clever Woo Archive Category Count: Count After Text', 'clever-woo-builder' ),
						'editor_type' => 'LINE',
					),
				),
			);

			$nodes_to_translate[ 'clever-woo-builder-products-navigation' ] = array(
				'conditions' => array( 'widgetType' => 'clever-woo-builder-products-navigation' ),
				'fields'     => array(
					array(
						'field'       => 'prev_text',
						'type'        => esc_html__( 'Clever Woo Shop Products Navigation: The previous page link text', 'clever-woo-builder' ),
						'editor_type' => 'LINE',
					),
				),
			);

			$nodes_to_translate[ 'clever-woo-builder-products-navigation' ] = array(
				'conditions' => array( 'widgetType' => 'clever-woo-builder-products-navigation' ),
				'fields'     => array(
					array(
						'field'       => 'next_text',
						'type'        => esc_html__( 'Clever Woo Shop Products Navigation: The next page link text', 'clever-woo-builder' ),
						'editor_type' => 'LINE',
					),
				),
			);

			$nodes_to_translate[ 'clever-woo-builder-products-pagination' ] = array(
				'conditions' => array( 'widgetType' => 'clever-woo-builder-products-pagination' ),
				'fields'     => array(
					array(
						'field'       => 'prev_text',
						'type'        => esc_html__( 'Clever Woo Shop Products Pagination: The previous page link text', 'clever-woo-builder' ),
						'editor_type' => 'LINE',
					),
				),
			);

			$nodes_to_translate[ 'clever-woo-builder-products-pagination' ] = array(
				'conditions' => array( 'widgetType' => 'clever-woo-builder-products-pagination' ),
				'fields'     => array(
					array(
						'field'       => 'next_text',
						'type'        => esc_html__( 'Clever Woo Shop Products Pagination: The next page link text', 'clever-woo-builder' ),
						'editor_type' => 'LINE',
					),
				),
			);

			return $nodes_to_translate;
		}

		/**
		 * Returns the instance.
		 *
		 * @since  1.0.0
		 * @return object
		 */
		public static function get_instance() {

			// If the single instance hasn't been set, set it now.
			if ( null == self::$instance ) {
				self::$instance = new self;
			}
			return self::$instance;
		}
	}

}

/**
 * Returns instance of Clever_Woo_Builder_Compatibility
 *
 * @return object
 */
function clever_woo_builder_compatibility() {
	return Clever_Woo_Builder_Compatibility::get_instance();
}
