<?php

//Single Add to cart
add_action('wp_ajax_woocommerce_ajax_add_to_cart', 'woocommerce_ajax_add_to_cart');
add_action('wp_ajax_nopriv_woocommerce_ajax_add_to_cart', 'woocommerce_ajax_add_to_cart');
if (!function_exists('woocommerce_ajax_add_to_cart')) {
    function woocommerce_ajax_add_to_cart()
    {
        $product_id = apply_filters('woocommerce_add_to_cart_product_id', absint($_POST['product_id']));
        $quantity = empty($_POST['quantity']) ? 1 : wc_stock_amount($_POST['quantity']);
        $variation_id = absint($_POST['variation_id']);
        $variations = $_POST['variations'];
        $passed_validation = apply_filters('woocommerce_add_to_cart_validation', true, $product_id, $quantity);
        $product_status = get_post_status($product_id);
        if ($passed_validation && WC()->cart->add_to_cart($product_id, $quantity, $variation_id, $variations) && 'publish' === $product_status) {
            do_action('woocommerce_ajax_added_to_cart', $product_id);
            if ('yes' === get_option('woocommerce_cart_redirect_after_add')) {
                wc_add_to_cart_message(array($product_id => $quantity), true);
            }
            WC_AJAX:: get_refreshed_fragments();
        } else {
            $data = array(
                'error' => true,
                'product_url' => apply_filters('woocommerce_cart_redirect_after_error', get_permalink($product_id), $product_id));
            echo wp_send_json($data);
        }
        wp_die();
    }
}

//Count Down Timer Variable Product
if (!function_exists('cwb_filter_woocommerce_available_variation')) {
    function cwb_filter_woocommerce_available_variation($variation_get_max_purchase_quantity, $instance, $variation)
    {
        $variation_get_max_purchase_quantity['availability_html'] = wc_get_stock_html($variation) . cwb_sale_count_down_variable_html($variation);
        return $variation_get_max_purchase_quantity;
    }

    ;
}

if (!function_exists('cwb_sale_count_down_variable_html')) {
    function cwb_sale_count_down_variable_html($variation)
    {
        $sale_date = strtotime($variation->get_date_on_sale_to());
        $sale_date_from = strtotime($variation->get_date_on_sale_from());
        if ($sale_date_from <= time()) {
            $stock = $variation->get_stock_quantity();
            $html = '';
            if ($sale_date > time()) {
                $html .= '<div class="cwb-countdown">';
                $html .= '<div class="label-product-countdown">' . esc_html('Hurry Up! Sales end in', 'clever-woo-builder') . '</div>';
                $html .= '<div class="countdown-block" data-countdown="countdown" data-date=" ' . esc_attr(date("m", $sale_date) . "-" . date("d", $sale_date) . "-" . date("Y", $sale_date) . "-" . date("H", $sale_date) . "-" . date("i", $sale_date) . "-" . date("s", $sale_date)) . ' ">';
                $html .= '</div>';
                $html .= '</div>';
            }
            return $html;
        }
    }
}

//Count Down Timer Simple Product
if (!function_exists('cwb_sale_count_down_simple_html')) {
    function cwb_sale_count_down_simple_html()
    {
        global $product;
        if ($product->is_on_sale()) {
            $cwb_date_sale = get_post_meta(get_the_ID(), '_sale_price_dates_to', true);
            if ($cwb_date_sale > time()) { ?>
                <div class="cwb-countdown">
			        <span class="label-product-countdown">
			           	<?php esc_html_e('Hurry Up! Sales end in:', 'clever-woo-builder'); ?>
			        </span>
                    <div class="countdown-block" data-countdown="countdown"
                         data-date="<?php echo esc_attr(date('m', $cwb_date_sale) . '-' . date('d', $cwb_date_sale) . '-' . date('Y', $cwb_date_sale) . '-' . date('H', $cwb_date_sale) . '-' . date('i', $cwb_date_sale) . '-' . date('s', $cwb_date_sale)); ?>">
                    </div>
                </div>
                <?php
            }
        }
    }
}

//Qty Html
if (!function_exists('qty_nav_decrease')) {
    function qty_nav_decrease()
    { ?>
        <span class="qty-nav decrease">-</span>
        <?php
    }
}
add_action('woocommerce_before_quantity_input_field', 'qty_nav_decrease', 5);

if (!function_exists('qty_nav_increase')) {
    function qty_nav_increase()
    { ?>
        <span class="qty-nav increase">+</span>
        <?php
    }
}
add_action('woocommerce_after_quantity_input_field', 'qty_nav_increase', 5);

//Buy Now Html
if (!function_exists('buy_now_html')) {
    function buy_now_html($redirect, $terms_and_conditions, $label)
    {
        global $product;
        if ($product->get_type() == 'external') {
            return false;
        }
        $direct_link = $disabled = '';
        $enable_terms = false;
        if ($redirect == 'checkout') {
            $direct_link = wc_get_checkout_url();
        } else {
            $direct_link = wc_get_cart_url();
        }
        if (wc_terms_and_conditions_checkbox_enabled() && $terms_and_conditions) {
            $enable_terms = true;
            $disabled = 'disabled';
        }
        ?>

        <div class="wrap-buy-now">
            <?php
            if ($enable_terms) { ?>

                <p class="cwb-product-term">
                    <input id="cwb-agree-term"
                           type="checkbox"
                           name="agree-term"
                           onchange="document.getElementById('cwb-buy-now').disabled = !this.checked;"/><label
                            for="cwb-agree-term"><?php wc_terms_and_conditions_checkbox_text(); ?></label>
                </p>
                <?php
            } ?>
            <button id="cwb-buy-now" type="submit"
                    class="button cwb-buy-now single_add_to_cart_button"
                    direct_link="<?php echo esc_url($direct_link); ?>"
                    value="<?php echo esc_attr($product->get_id()); ?>" <?php echo esc_attr($disabled); ?> > <?php echo esc_attr($label); ?></button>

        </div>
        <?php
    }
}

// Use Ajax Add to Cart
if (!function_exists('use_add_to_cart_advanced')) {
    function use_add_to_cart_ajax()
    { ?>
        <div class="use-ajax"></div>
        <?php
    }
}

// Socials Sharing
if (!function_exists('cwb_woo_share')) {
    function cwb_woo_share($label, $socials)
    { ?>
        <div class="cwb-woo-share">
            <span class="label-share"><?php echo esc_html($label); ?></span>
            <ul class="social-icons">
                <?php foreach ($socials as $social) { ?>
                    <?php
                    if ($social == 'facebook') { ?>
                        <li class="facebook">
                            <a href="http://www.facebook.com/sharer.php?u=<?php the_permalink(); ?>"
                               class="post_share_facebook icon-around"
                               onclick="javascript:window.open(this.href,'', 'menubar=no, toolbar=no, resizable=yes, scrollbars=yes, height=220, width=600'); return false;"
                               title="<?php echo esc_attr__('Share to facebook', 'elementor-theme') ?>">
                                <i class="cs-font clever-icon-facebook"></i>

                            </a>
                        </li>
                        <?php
                    }
                    ?>
                    <?php
                    if ($social == 'twitter') { ?>
                        <li class="twitter">
                            <a href="https://twitter.com/share?url=<?php the_permalink(); ?>"
                               onclick="javascript:window.open(this.href, '', 'menubar=no, toolbar=no, resizable=yes, scrollbars=yes, height=260, width=600'); return false;"
                               title="<?php echo esc_attr__('Share to twitter', 'elementor-theme') ?>"
                               class="product_share_twitter icon-around">
                                <i class="cs-font clever-icon-twitter"></i>

                            </a>
                        </li>
                        <?php
                    }
                    ?>
                    <?php
                    if ($social == 'pinterest') { ?>
                        <li class="pinterest">
                            <a href="http://pinterest.com/pin/create/button/?url=<?php the_permalink(); ?>&media=<?php if (function_exists('the_post_thumbnail')) echo wp_get_attachment_url(get_post_thumbnail_id()); ?>&description=<?php the_title_attribute(); ?>"
                               class="product_share_email icon-around"
                               title="<?php echo esc_attr__('Share to pinterest', 'elementor-theme') ?>">
                                <i class="cs-font clever-icon-pinterest"></i>
                            </a>
                        </li>
                        <?php
                    }
                    ?>
                    <?php
                    if ($social == 'mail') { ?>
                        <li class="mail">
                            <a href="mailto:?subject=<?php the_title_attribute(); ?>&body=<?php echo strip_tags(get_the_excerpt()); ?><?php the_permalink(); ?>"
                               class="product_share_email icon-around"
                               title="<?php echo esc_attr__('Sent to mail', 'elementor-theme') ?>">
                                <i class="cs-font clever-icon-mail-1"></i>
                            </a>
                        </li>
                        <?php
                    }
                    ?>
                    <?php
                } ?>
            </ul>
        </div>
        <?php
    }
}

// Custom Tabs
if (!function_exists('custom_woocommerce_output_product_data_tabs')) {
    function custom_woocommerce_output_product_data_tabs($layout = "accordion", $position = "right")
    {
        $product_tabs = apply_filters('woocommerce_product_tabs', array());
        if (!empty($product_tabs)) { ?>
            <div class="cwb-product-data-tabs <?php echo esc_attr($layout) ?>-layout">
                <div class="woocommerce-tabs wc-tabs-wrapper">
                    <?php
                    $i = 0;
                    $tab_item_class = "cwb-group-accordion ";
                    if ($layout != "accordion") {
                        $tab_item_class = "cwb-wrap-tab-item";
                    }
                    if ($layout == "off-canvas") {
                    ?>
                    <ul class="tabs wc-tabs off-canvas-tab-control">
                        <?php foreach ($product_tabs as $key => $product_tab) : ?>
                            <li class="<?php echo esc_attr($key); ?>_tab">
                                <a href="#tab-<?php echo esc_attr($key); ?>">
                                    <?php echo wp_kses_post(apply_filters('woocommerce_product_' . $key . '_tab_title', $product_tab['title'], $key)); ?>
                                </a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                    <div class="wrap-off-canvas-tab <?php echo esc_attr($position) ?>">
                        <div class="close-off-canvas-tab mask-tab-close"></div>
                        <?php
                        }
                        foreach ($product_tabs as $key => $product_tab) :
                            if ($layout != "off-canvas") {
                                ?>
                                <div class="<?php echo esc_attr($tab_item_class);
                                if ($i == 0 && $layout == "accordion") {
                                    echo esc_attr('accordion-active');
                                } ?>">

                                <h3 class="tab-heading">
	                	<span class="tab-title">
	                	<?php echo apply_filters('woocommerce_product_' . $key . '_tab_title', esc_html($product_tab['title']), $key); ?></span>
                                    <?php if ($layout == "accordion") { ?><span class="toggle-visible"></span><?php } ?>
                                </h3>
                            <?php } ?>
                            <div class="woocommerce-Tabs-panel woocommerce-Tabs-panel--<?php echo esc_attr($key); ?> panel entry-content wc-tab"
                                 id="tab-<?php echo esc_attr($key); ?>">
                                <?php if ($layout == "off-canvas") { ?>
                                <h3 class="tab-heading">
                                    <span class="tab-title"><?php echo apply_filters('woocommerce_product_' . $key . '_tab_title', esc_html($product_tab['title']), $key); ?></span>
                                    <span class="close-off-canvas-tab cs-font clever-icon-close-1"></span>
                                </h3>
                                <div class="wrap-off-canvas-tab-content">
                                    <?php } ?>
                                    <?php
                                    if (isset($product_tab['callback'])) {
                                        call_user_func($product_tab['callback'], $key, $product_tab);
                                    }
                                    if ($layout == "off-canvas") { ?>
                                </div>
                            <?php } ?>
                            </div>
                            <?php if ($layout != "off-canvas") {
                            ?>
                            </div>
                            <?php
                        }
                            $i++;
                        endforeach;
                        if ($layout == "off-canvas") {
                        ?>
                    </div>
                <?php
                }
                do_action('woocommerce_product_after_tabs');

                ?>
                </div>
            </div>
            <?php
        }
    }
}

// Visitor Product
if (!function_exists('countVisitors')) {
    function countVisitors($fake_min, $fake_max)
    {
        $fake_visitor = rand($fake_min, $fake_max);
        return '<span id="cwb-visitors-count" class="visitor" data-fake="' . $fake_min . '"data-fake-max="' . $fake_max . '">' . $fake_visitor . '</span>';
    }
}