<?php
/**
 * Kava integration
 */

add_action( 'elementor/page_templates/canvas/before_content', 'clever_woo_kava_open_site_main_wrap', -999 );
add_action( 'clever-woo-builder/blank-page/before-content', 'clever_woo_kava_open_site_main_wrap', -999 );
add_action( 'elementor/page_templates/header-footer/before_content', 'clever_woo_kava_open_site_main_wrap', -999 );
add_action( 'clever-woo-builder/full-width-page/before-content', 'clever_woo_kava_open_site_main_wrap', -999 );

add_action( 'elementor/page_templates/canvas/after_content', 'clever_woo_kava_close_site_main_wrap', 999 );
add_action( 'clever-woo-builder/blank-page/after_content', 'clever_woo_kava_close_site_main_wrap', 999 );
add_action( 'clever-woo-builder/full-width-page/after_content', 'clever_woo_kava_close_site_main_wrap', 999 );
add_action( 'elementor/page_templates/header-footer/after_content', 'clever_woo_kava_close_site_main_wrap', 999 );

add_action( 'elementor/widgets/register', 'clever_woo_kava_fix_wc_hooks' );

/**
 * Fix WooCommerce hooks for kava
 *
 * @return [type] [description]
 */
function clever_woo_kava_fix_wc_hooks() {
	remove_action( 'woocommerce_shop_loop_item_title', 'woocommerce_template_loop_product_title', 10 );
	remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_rating', 10 );
}

/**
 * Open .site-main wrapper for products
 * @return [type] [description]
 */
function clever_woo_kava_open_site_main_wrap() {
	if ( ! is_singular( array( clever_woo_builder_post_type()->slug(), 'product' ) ) ) {
		return;
	}

	echo '<div class="site-main">';
}

/**
 * Close .site-main wrapper for products
 * @return [type] [description]
 */
function clever_woo_kava_close_site_main_wrap() {

	if ( ! is_singular( array( clever_woo_builder_post_type()->slug(), 'product' ) ) ) {
		return;
	}

	echo '</div>';
}