<?php
/**
 * Class: Clever_Woo_Builder_Single_Sharing
 * Name: Single Sharing
 * Slug: clever-single-sharing
 */

namespace Elementor;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Repeater;
use Elementor\Core\Schemes\Color;
use Elementor\Widget_Base;
use Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly

class Clever_Woo_Builder_Single_Sharing extends Clever_Woo_Builder_Base {

	public function get_name() {
		return 'clever-single-sharing';
	}

	public function get_title() {
		return esc_html__( 'Single Sharing', 'clever-woo-builder' );
	}

	public function get_icon() {
		return 'clever-woo-builder-icon-single-sharing';
	}

	public function get_script_depends() {
		return array();
	}

	public function get_clever_help_url() {
		return 'https://cleveraddon.com/knowledge-base/articles/cleverwoobuilder-how-to-create-and-set-a-single-product-page-template/';
	}

	public function get_categories() {
		return array( 'clever-woo-builder' );
	}

	public function show_in_panel() {
		return clever_woo_builder()->documents->is_document_type( 'single' );
	}

	protected function register_controls() {

		$css_scheme = apply_filters(
			'clever-woo-builder/clever-single-sharing/css-scheme',
			array(
				'sharing_wrapper' 		=> '.cwb-woo-share',
				'sharing_label' 		=> '.cwb-woo-share .label-share',
				'sharing_socials' 		=> '.cwb-woo-share .social-icons',
				'sharing_social' 		=> '.cwb-woo-share .social-icons li',
				'sharing_social_icon' 	=> '.cwb-woo-share .social-icons li i',
			)
		);

		$this->start_controls_section(
			'section_single_sharing',
			array(
				'label' => __( 'General', 'clever-woo-builder' ),
			)
		);

		$this->add_control(
			'single_share_option',
			array(
				'label'     => __( 'Use', 'clever-woo-builder' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'default',
				'options'   => array(
					'default' => esc_html__( 'Default', 'clever-woo-builder' ),
					'addon'   => esc_html__( 'Addon', 'clever-woo-builder' ),
				),
			)
		);

		$this->add_control(
			'single_share_default_socials',
			array(
				'label'     => __( 'Socials', 'clever-woo-builder' ),
				'type'      => Controls_Manager::SELECT2,
				'multiple' => true,
				'default'   => ['facebook','twitter'],
				'options'   => array(
					'facebook' => esc_html__( 'Fcebook', 'clever-woo-builder' ),
					'twitter'   => esc_html__( 'Twitter', 'clever-woo-builder' ),
					'pinterest'   => esc_html__( 'Pinterest', 'clever-woo-builder' ),
					'mail'   => esc_html__( 'Mail', 'clever-woo-builder' ),
				),
				'condition' => [
                    'single_share_option' => 'default',
                ],
			)
		);

		$this->add_control(
			'single_share_default_label',
			array(
				'label'     => __( 'Sharing Label', 'clever-woo-builder' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => 'Sharing:',
				'condition' => [
                    'single_share_option' => 'default',
                ],
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_single_share_style',
			array(
				'label'      => esc_html__( 'General', 'clever-woo-builder' ),
				'tab'        => Controls_Manager::TAB_STYLE,
				'show_label' => false,
				'condition' => [
                    'single_share_option' => 'default',
                ],
			)
		);

		$this->add_control(
			'single_share_label_heading',
			array(
				'label'     => esc_html__( 'Label', 'clever-woo-builder' ),
				'type' => Controls_Manager::HEADING,
				'separator'   => 'after',
			)
		);
		
		$this->add_control(
			'single_share_label_color',
			array(
				'label'     => esc_html__( 'Label Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['sharing_label'] => 'color: {{VALUE}}',
				),
			)
		);
		$this->add_responsive_control(
			'single_share_label_margin',
			array(
				'label'      => __( 'Label Margin', 'clever-woo-builder' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} ' . $css_scheme['sharing_label'] => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'single_share_label_typography',
				'selector' => '{{WRAPPER}} ' . $css_scheme['sharing_label'],
			)
		);

		$this->add_control(
			'single_share_icon_heading',
			array(
				'label'     => esc_html__( 'Socials', 'clever-woo-builder' ),
				'type' => Controls_Manager::HEADING,
				'separator'   => 'after',
			)
		);

		$this->add_control(
			'single_share_icon_color',
			array(
				'label'     => esc_html__( 'Icon Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['sharing_social_icon'] => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_control(
			'single_share_icon_color_hover',
			array(
				'label'     => esc_html__( 'Icon Color Hover', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['sharing_social_icon'].':hover' => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_responsive_control(
			'single_share_icon_size',
			array(
				'label'      => esc_html__( 'Font Size (px)', 'clever-woo-builder' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 60,
					),
				),
				'default'    => array(
					'unit' => 'px',
					'size' => 16,
				),
				'selectors'  => array(
					'{{WRAPPER}} ' . $css_scheme['sharing_social_icon'] => 'font-size: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'single_share_icon_space',
			array(
				'label'      => esc_html__( 'Space Between Icon (px)', 'clever-woo-builder' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 20,
					),
				),
				'default'    => array(
					'unit' => 'px',
					'size' => 2,
				),
				'selectors'  => array(
					'{{WRAPPER}} ' . $css_scheme['sharing_social'] => 'margin: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();

	}

	protected function render() {

		$this->__context = 'render';

		if ( true === $this->__set_editor_product() ) {
			$this->__open_wrap();
			include $this->__get_global_template( 'index' );
			$this->__close_wrap();
			$this->__reset_editor_product();
		}

	}
}
