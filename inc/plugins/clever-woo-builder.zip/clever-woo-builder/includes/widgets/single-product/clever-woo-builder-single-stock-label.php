<?php
/**
 * Class: Clever_Woo_Builder_Single_Stock_Label
 * Name: Single Stock Label
 * Slug: clever-single-stock-label
 */

namespace Elementor;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Repeater;
use Elementor\Core\Schemes\Color;
use Elementor\Widget_Base;
use Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly

class Clever_Woo_Builder_Single_Stock_Label extends Clever_Woo_Builder_Base {

	public function get_name() {
		return 'clever-single-stock-label';
	}

	public function get_title() {
		return esc_html__( 'Single Stock Label', 'clever-woo-builder' );
	}

	public function get_icon() {
		return 'clever-woo-builder-icon-archive-stock-status';
	}

	public function get_script_depends() {
		return array();
	}

	public function get_categories() {
		return array( 'clever-woo-builder' );
	}

	public function show_in_panel() {
		return clever_woo_builder()->documents->is_document_type( 'single' );
	}

	protected function register_controls() {

		$this->start_controls_section(
			'section_single_in_stock_style',
			array(
				'label'      => esc_html__( 'In stock', 'clever-woo-builder' ),
				'tab'        => Controls_Manager::TAB_STYLE,
				'show_label' => false,
			)
		);

		$this->add_control(
			'single_in_stock_color',
			array(
				'label'     => esc_html__( 'Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .in-stock' => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_control(
			'single_in_stock_background',
			array(
				'label'     => esc_html__( 'Background', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .in-stock' => 'background-color: {{VALUE}}',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'single_in_stock_typography',
				'selector' => '{{WRAPPER}} .in-stock'
			)
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'        => 'single_in_stock_border',
				'label'       => esc_html__( 'Border', 'clever-woo-builder' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .in-stock',
			)
		);

		$this->add_responsive_control(
			'single_in_stock_border_radius',
			array(
				'label'      => __( 'Border Radius', 'clever-woo-builder' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .in-stock' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'single_in_stock_box_shadow',
				'selector' => '{{WRAPPER}} .in-stock',
			)
		);

		$this->add_responsive_control(
			'single_in_stock_content_padding',
			array(
				'label'      => __( 'Padding', 'clever-woo-builder' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .in-stock' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->end_controls_section();
        $this->start_controls_section(
            'section_single_low_stock_style',
            array(
                'label'      => esc_html__( 'Low stock', 'clever-woo-builder' ),
                'tab'        => Controls_Manager::TAB_STYLE,
                'show_label' => false,
            )
        );

        $this->add_control(
            'single_low_stock_color',
            array(
                'label'     => esc_html__( 'Color', 'clever-woo-builder' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .low-stock' => 'color: {{VALUE}}',
                ),
            )
        );

        $this->add_control(
            'single_low_stock_background',
            array(
                'label'     => esc_html__( 'Background', 'clever-woo-builder' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .low-stock' => 'background-color: {{VALUE}}',
                ),
            )
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            array(
                'name'     => 'single_low_stock_typography',
                'selector' => '{{WRAPPER}} .low-stock'
            )
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            array(
                'name'        => 'single_low_stock_border',
                'label'       => esc_html__( 'Border', 'clever-woo-builder' ),
                'placeholder' => '1px',
                'default'     => '1px',
                'selector'    => '{{WRAPPER}} .low-stock',
            )
        );

        $this->add_responsive_control(
            'single_low_stock_border_radius',
            array(
                'label'      => __( 'Border Radius', 'clever-woo-builder' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} .low-stock' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            array(
                'name'     => 'single_low_stock_box_shadow',
                'selector' => '{{WRAPPER}} .low-stock',
            )
        );

        $this->add_responsive_control(
            'single_low_stock_content_padding',
            array(
                'label'      => __( 'Padding', 'clever-woo-builder' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} .low-stock' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->end_controls_section();
        $this->start_controls_section(
            'section_single_out_stock_style',
            array(
                'label'      => esc_html__( 'Out of stock', 'clever-woo-builder' ),
                'tab'        => Controls_Manager::TAB_STYLE,
                'show_label' => false,
            )
        );

        $this->add_control(
            'single_out_stock_color',
            array(
                'label'     => esc_html__( 'Color', 'clever-woo-builder' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .out-of-stock' => 'color: {{VALUE}}',
                ),
            )
        );

        $this->add_control(
            'single_out_stock_background',
            array(
                'label'     => esc_html__( 'Background', 'clever-woo-builder' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .out-of-stock' => 'background-color: {{VALUE}}',
                ),
            )
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            array(
                'name'     => 'single_out_stock_typography',
                'selector' => '{{WRAPPER}} .out-of-stock'
            )
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            array(
                'name'        => 'single_out_stock_border',
                'label'       => esc_html__( 'Border', 'clever-woo-builder' ),
                'placeholder' => '1px',
                'default'     => '1px',
                'selector'    => '{{WRAPPER}} .out-of-stock',
            )
        );

        $this->add_responsive_control(
            'single_out_stock_border_radius',
            array(
                'label'      => __( 'Border Radius', 'clever-woo-builder' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} .out-of-stock' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            array(
                'name'     => 'single_out_stock_box_shadow',
                'selector' => '{{WRAPPER}} .out-of-stock',
            )
        );

        $this->add_responsive_control(
            'single_out_stock_content_padding',
            array(
                'label'      => __( 'Padding', 'clever-woo-builder' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} .out-of-stock' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->end_controls_section();
        $this->start_controls_section(
            'section_single_backorder_style',
            array(
                'label'      => esc_html__( 'Backorder', 'clever-woo-builder' ),
                'tab'        => Controls_Manager::TAB_STYLE,
                'show_label' => false,
            )
        );

        $this->add_control(
            'single_backorder_color',
            array(
                'label'     => esc_html__( 'Color', 'clever-woo-builder' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .available-on-backorder' => 'color: {{VALUE}}',
                ),
            )
        );

        $this->add_control(
            'single_backorder_background',
            array(
                'label'     => esc_html__( 'Background', 'clever-woo-builder' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .available-on-backorder' => 'background-color: {{VALUE}}',
                ),
            )
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            array(
                'name'     => 'single_backorder_typography',
                'selector' => '{{WRAPPER}} .available-on-backorder'
            )
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            array(
                'name'        => 'single_backorderr_border',
                'label'       => esc_html__( 'Border', 'clever-woo-builder' ),
                'placeholder' => '1px',
                'default'     => '1px',
                'selector'    => '{{WRAPPER}} .available-on-backorder',
            )
        );

        $this->add_responsive_control(
            'single_backorder_border_radius',
            array(
                'label'      => __( 'Border Radius', 'clever-woo-builder' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} .available-on-backorder' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            array(
                'name'     => 'single_backorder_box_shadow',
                'selector' => '{{WRAPPER}} .available-on-backorder',
            )
        );

        $this->add_responsive_control(
            'single_backorder_content_padding',
            array(
                'label'      => __( 'Padding', 'clever-woo-builder' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} .available-on-backorder' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->end_controls_section();
	}

	protected function render() {

		$this->__context = 'render';

		if ( true === $this->__set_editor_product() ) {
			$this->__open_wrap();
			include $this->__get_global_template( 'index' );
			$this->__close_wrap();
			$this->__reset_editor_product();
		}

	}
}
