<?php
/**
 * Class: Clever_Woo_Builder_Single_Add_To_Cart
 * Name: Single Add to Cart
 * Slug: clever-single-add-to-cart
 */

namespace Elementor;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Repeater;
use Elementor\Core\Schemes\Color;
use Elementor\Widget_Base;
use Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly

class Clever_Woo_Builder_Single_Add_To_Cart extends Clever_Woo_Builder_Base {

	public function get_name() {
		return 'clever-single-add-to-cart';
	}

	public function get_title() {
		return esc_html__( 'Single Add to Cart', 'clever-woo-builder' );
	}

	public function get_icon() {
		return 'clever-woo-builder-icon-add-to-cart';
	}

	public function get_script_depends() {
		return array( 'wc-add-to-cart', 'wc-add-to-cart-variation', 'wc-single-product' );
	}

	public function get_clever_help_url() {
		return 'https://cleveraddon.com/knowledge-base/articles/cleverwoobuilder-how-to-create-and-set-a-single-product-page-template/';
	}

	public function get_categories() {
		return array( 'clever-woo-builder' );
	}

	public function show_in_panel() {
		return clever_woo_builder()->documents->is_document_type( 'single' );
	}

	protected function register_controls() {

		$css_scheme = apply_filters(
			'clever-woo-builder/clever-single-add-to-cart/css-scheme',
			array(
				'button'          	=> '.clever-woo-builder .single_add_to_cart_button.button:not(.cwb-buy-now)',
				'button_3rd'        => '.elementor-clever-single-add-to-cart.clever-woo-builder>.button',
				'countdown_text'	=> '.elementor-clever-single-add-to-cart .label-product-countdown',
				'qty_input'         => '.elementor-clever-single-add-to-cart .qty',
				'qty_section'       => '.elementor-clever-single-add-to-cart .cart .quantity',
				'qty_nav'       	=> '.elementor-clever-single-add-to-cart .qty-nav',
				'term_label'		=> '.elementor-clever-single-add-to-cart .zoo-product-term',
				'buy_now'			=> '.elementor-clever-single-add-to-cart .single_add_to_cart_button.button.cwb-buy-now',
				'description'     	=> '.elementor-clever-single-add-to-cart .woocommerce-variation-description',
				'wrap_price'           	=> '.elementor-clever-single-add-to-cart .woocommerce-variation.single_variation',
				'price'           	=> '.elementor-clever-single-add-to-cart .woocommerce-variation-price .price',
				'price_sale'        => '.elementor-clever-single-add-to-cart .woocommerce-variation-price .price ins',
				'price_reg'        => '.elementor-clever-single-add-to-cart .woocommerce-variation-price .price del',
				'currency'        	=> '.elementor-clever-single-add-to-cart .woocommerce-Price-currencySymbol',
				'in_stock'        	=> '.elementor-clever-single-add-to-cart .in-stock',
				'out_stock'       	=> '.elementor-clever-single-add-to-cart .out-of-stock',
				'availability'    	=> '.elementor-clever-single-add-to-cart .stock',
				'reset_button'    	=> '.elementor-clever-single-add-to-cart .reset_variations',
				'variations_wrap' 	=> '.elementor-clever-single-add-to-cart .variations select',
				'variations_button' => '.elementor-clever-single-add-to-cart .variations_button',
				'form_cart' 		=> '.elementor-clever-single-add-to-cart form.cart',
				'select'          	=> '.elementor-clever-single-add-to-cart .variations select',
				'label'           	=> '.elementor-clever-single-add-to-cart .variations .label label'
			)
		);

		$this->start_controls_section(
			'section_add_to_cart',
			array(
				'label' => esc_html__( 'General', 'clever-woo-builder' ),
			)
		);

		$this->add_control(
			'add_to_cart_buy_now_options',
			array(
				'label'     => __( 'Add to Cart', 'clever-woo-builder' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'ajax',
				'options'   => array(
					'ajax'   => esc_html__( 'Ajax', 'clever-woo-builder' ),
					'reload' => esc_html__( 'Reload', 'clever-woo-builder' ),
				),
				
			)
		);

		$this->add_control(
			'add_to_cart_buy_now',
			array(
				'label'     => __( 'Buy Now', 'clever-woo-builder' ),
				'type' => Controls_Manager::SWITCHER,
	            'return_value' => 'true',
	            'default' => 'true',
	            'condition' => [
                    'add_to_cart_buy_now_options' => 'ajax',
                ],
			)
		);

		$this->add_control(
			'add_to_cart_buy_now_label',
			array(
				'label'     => __( 'Buy Now Label', 'clever-woo-builder' ),
				'type'      => Controls_Manager::TEXT,
				'default'   =>  __( 'Buy now', 'clever-woo-builder' ),
				'condition' => [
                    'add_to_cart_buy_now' => 'true',
                    'add_to_cart_buy_now_options' => 'ajax',
                ],
			)
		);

		$this->add_control(
			'add_to_cart_buy_now_redirect',
			array(
				'label'     => __( 'Redirect', 'clever-woo-builder' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'cart',
				'options'   => array(
					'cart' => esc_html__( 'Cart Page', 'clever-woo-builder' ),
					'checkout'   => esc_html__( 'Checkout Page', 'clever-woo-builder' ),
				),
				'condition' => [
                    'add_to_cart_buy_now' => 'true',
                    'add_to_cart_buy_now_options' => 'ajax',
                ],
			)
		);

		$this->add_control(
			'add_to_cart_buy_now_terms_and_conditions',
			array(
				'label'     => __( 'Terms and Conditions', 'clever-woo-builder' ),
				'type' => Controls_Manager::SWITCHER,
	            'return_value' => 'true',
	            'default' => 'true',
	            'condition' => [
                    'add_to_cart_buy_now' => 'true',
                    'add_to_cart_buy_now_options' => 'ajax',
                ],
			)
		);

		$this->add_control(
			'countdown',
			array(
				'label'     => __( 'Count Down Timer', 'clever-woo-builder' ),
				'type' => Controls_Manager::SWITCHER,
	            'return_value' => 'true',
	            'default' => 'true',
			)
		);
		$this->add_responsive_control(
            'single_tabs_controls_alignment',
            array(
                'label'        => esc_html__( 'Tabs Alignment', 'clever-woo-builder' ),
                'type'         => Controls_Manager::CHOOSE,
                'default'      => 'left',
                'options'      => array(
                    'left'    => array(
                        'title' => esc_html__( 'Left', 'clever-woo-builder' ),
                        'icon'  => 'eicon-text-align-left',
                    ),
                    'center'  => array(
                        'title' => esc_html__( 'Center', 'clever-woo-builder' ),
                        'icon'  => 'eicon-text-align-center',
                    ),
                    'justify' => array(
                        'title' => esc_html__( 'justify', 'clever-woo-builder' ),
                        'icon'  => 'eicon-text-align-justify',
                    ),
                    'right'   => array(
                        'title' => esc_html__( 'Right', 'clever-woo-builder' ),
                        'icon'  => 'eicon-text-align-right',
                    ),
                ),
                'selectors'  => array(
                    '{{WRAPPER}} '=> 'text-align: {{VALUE}}',
                ),
            )
        );
		$this->end_controls_section();

		$this->start_controls_section(
			'section_add_to_cart_style',
			array(
				'label' => esc_html__( 'Cart Button', 'clever-woo-builder' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'        => 'add_to_cart_typography',
				'scheme'      => Typography::TYPOGRAPHY_4,
				'selector'    => '{{WRAPPER}} ' . $css_scheme['button'],
				'placeholder' => '1px',
			)
		);

		$this->add_responsive_control(
			'button_width',
			array(
				'label'      => esc_html__( 'Button Width', 'clever-woo-builder' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array(
					'%',
					'px',
				),
				'range'      => array(
					'%'  => array(
						'min' => 10,
						'max' => 100,
					),
					'px' => array(
						'min' => 50,
						'max' => 1000,
					),
				),
				'default'    => array(
					'unit' => 'px',
					'size' => '',
				),
				'selectors'  => array(
					'{{WRAPPER}} ' . $css_scheme['button'] => 'width: {{SIZE}}{{UNIT}}',
				),
			)
		);

		$this->start_controls_tabs( 'tabs_add_to_cart_style' );

		$this->start_controls_tab(
			'tab_add_to_cart_normal',
			array(
				'label' => esc_html__( 'Normal', 'clever-woo-builder' ),
			)
		);

		$this->add_control(
			'add_to_cart_text_color',
			array(
				'label'     => esc_html__( 'Text Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['button'] => 'color: {{VALUE}};',
				),

			)
		);

		$this->add_control(
			'add_to_cart_background_color',
			array(
				'label'     => esc_html__( 'Background Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['button'] => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'add_to_cart_box_shadow',
				'selector' => '{{WRAPPER}} ' . $css_scheme['button'],
			)
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_add_to_cart_hover',
			array(
				'label' => esc_html__( 'Hover', 'clever-woo-builder' ),
			)
		);

		$this->add_control(
			'add_to_cart_hover_color',
			array(
				'label'     => esc_html__( 'Text Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['button'] . ':hover' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'add_to_cart_background_hover_color',
			array(
				'label'     => esc_html__( 'Background Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['button'] . ':hover' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'add_to_cart_hover_border_color',
			array(
				'label'     => esc_html__( 'Border Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'condition' => array(
					'add_to_cart_border_border!' => '',
				),
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['button'] . ':hover' => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'add_to_cart_hover_box_shadow',
				'selector' => '{{WRAPPER}} ' . $css_scheme['button'] . ':hover',
			)
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_add_to_cart_disabled',
			array(
				'label' => esc_html__( 'Disabled', 'clever-woo-builder' ),
			)
		);

		$this->add_control(
			'add_to_cart_disabled_color',
			array(
				'label'     => esc_html__( 'Text Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['button'] . '.disabled' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'add_to_cart_background_disabled_color',
			array(
				'label'     => esc_html__( 'Background Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['button'] . '.disabled' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'add_to_cart_disabled_border_color',
			array(
				'label'     => esc_html__( 'Border Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'condition' => array(
					'add_to_cart_border_border!' => '',
				),
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['button'] . '.disabled'       => 'border-color: {{VALUE}};',
					'{{WRAPPER}} ' . $css_scheme['button'] . '.disabled:hover' => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'add_to_cart_disabled_box_shadow',
				'selector' => '{{WRAPPER}} ' . $css_scheme['button'] . '.disabled',
			)
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'        => 'add_to_cart_border',
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} ' . $css_scheme['button'],
				'separator'   => 'before'

			)
		);

		$this->add_control(
			'add_to_cart_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'clever-woo-builder' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} ' . $css_scheme['button'] => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'add_to_cart_padding',
			array(
				'label'      => esc_html__( 'Padding', 'clever-woo-builder' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} ' . $css_scheme['button'] => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
				'separator'  => 'before'
			)
		);

		$this->add_responsive_control(
			'add_to_cart_margin',
			array(
				'label'      => esc_html__( 'Margin', 'clever-woo-builder' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} ' . $css_scheme['button'] => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
        $this->start_controls_section(
            'section_button_3rd_style',
            array(
                'label' => esc_html__( '3rd Button', 'clever-woo-builder' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            array(
                'name'        => 'button_3rd_typography',
                'scheme'      => Typography::TYPOGRAPHY_4,
                'selector'    => '{{WRAPPER}} ' . $css_scheme['button_3rd'],
                'placeholder' => '1px',
            )
        );

        $this->add_responsive_control(
            'button_3rd_width',
            array(
                'label'      => esc_html__( 'Button Width', 'clever-woo-builder' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => array(
                    '%',
                    'px',
                ),
                'range'      => array(
                    '%'  => array(
                        'min' => 10,
                        'max' => 100,
                    ),
                    'px' => array(
                        'min' => 50,
                        'max' => 1000,
                    ),
                ),
                'default'    => array(
                    'unit' => 'px',
                    'size' => '',
                ),
                'selectors'  => array(
                    '{{WRAPPER}} ' . $css_scheme['button_3rd'] => 'width: {{SIZE}}{{UNIT}}',
                ),
            )
        );

        $this->start_controls_tabs( 'tabs_button_3rd_style' );

        $this->start_controls_tab(
            'tab_button_3rd_normal',
            array(
                'label' => esc_html__( 'Normal', 'clever-woo-builder' ),
            )
        );

        $this->add_control(
            'button_3rd_color',
            array(
                'label'     => esc_html__( 'Text Color', 'clever-woo-builder' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => array(
                    '{{WRAPPER}} ' . $css_scheme['button_3rd'] => 'color: {{VALUE}};',
                ),

            )
        );

        $this->add_control(
            'button_3rd_bg',
            array(
                'label'     => esc_html__( 'Background Color', 'clever-woo-builder' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} ' . $css_scheme['button_3rd'] => 'background-color: {{VALUE}};',
                ),
            )
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            array(
                'name'     => 'button_3rd_box_shadow',
                'selector' => '{{WRAPPER}} ' . $css_scheme['button_3rd'],
            )
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'tab_button_3rd_hover',
            array(
                'label' => esc_html__( 'Hover', 'clever-woo-builder' ),
            )
        );

        $this->add_control(
            'button_3rd_hover_color',
            array(
                'label'     => esc_html__( 'Text Color', 'clever-woo-builder' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} ' . $css_scheme['button_3rd'] . ':hover' => 'color: {{VALUE}};',
                ),
            )
        );

        $this->add_control(
            'button_3rd_background_hover_color',
            array(
                'label'     => esc_html__( 'Background Color', 'clever-woo-builder' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} ' . $css_scheme['button_3rd'] . ':hover' => 'background-color: {{VALUE}};',
                ),
            )
        );

        $this->add_control(
            'button_3rd_hover_border_color',
            array(
                'label'     => esc_html__( 'Border Color', 'clever-woo-builder' ),
                'type'      => Controls_Manager::COLOR,
                'condition' => array(
                    'add_to_cart_border_border!' => '',
                ),
                'selectors' => array(
                    '{{WRAPPER}} ' . $css_scheme['button_3rd'] . ':hover' => 'border-color: {{VALUE}};',
                ),
            )
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            array(
                'name'     => 'button_3rd_hover_box_shadow',
                'selector' => '{{WRAPPER}} ' . $css_scheme['button_3rd'] . ':hover',
            )
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_group_control(
            Group_Control_Border::get_type(),
            array(
                'name'        => 'button_3rd_border',
                'placeholder' => '1px',
                'default'     => '1px',
                'selector'    => '{{WRAPPER}} ' . $css_scheme['button_3rd'],
                'separator'   => 'before'

            )
        );

        $this->add_control(
            'button_3rd_border_radius',
            array(
                'label'      => esc_html__( 'Border Radius', 'clever-woo-builder' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} ' . $css_scheme['button_3rd'] => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );

        $this->add_responsive_control(
            'button_3rd_padding',
            array(
                'label'      => esc_html__( 'Padding', 'clever-woo-builder' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', 'em', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} ' . $css_scheme['button_3rd'] => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
                'separator'  => 'before'
            )
        );

        $this->add_responsive_control(
            'button_3rd_margin',
            array(
                'label'      => esc_html__( 'Margin', 'clever-woo-builder' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', 'em', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} ' . $css_scheme['button_3rd'] => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );

        $this->end_controls_section();
		$this->start_controls_section(
			'section_qty_style',
			array(
				'label' => esc_html__( 'Quantity', 'clever-woo-builder' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);
		$this->add_control(
			'qty_display',
			array(
				'label'     => esc_html__( 'Quantity Display', 'clever-woo-builder' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => array(
					'nowrap' => esc_html__( 'Inline', 'clever-woo-builder' ),
					'wrap'        => esc_html__( 'Stack', 'clever-woo-builder' ),
				),
				'default'   => 'nowrap',
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['variations_button'] 	=> 'flex-wrap: {{VALUE}};',
					'{{WRAPPER}} ' . $css_scheme['form_cart']    		=> 'flex-wrap: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'qty_input_width',
			array(
				'label'      => esc_html__( 'Width', 'clever-woo-builder' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array(
					'%',
					'px',
				),
				'range'      => array(
					'%'  => array(
						'min' => 10,
						'max' => 100,
					),
					'px' => array(
						'min' => 50,
						'max' => 1000,
					),
				),
				'default'    => array(
					'unit' => 'px',
					'size' => 70,
				),
				'selectors'  => array(
					'{{WRAPPER}} ' . $css_scheme['qty_section'] => 'width: {{SIZE}}{{UNIT}}',
				),
			)
		);
        $this->add_control(
            'qty_input_options',
            array(
                'label'     => esc_html__( 'Input', 'clever-woo-builder' ),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'after'
            )
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            array(
                'name'     => 'qty_typography',
                'selector' => '{{WRAPPER}} ' . $css_scheme['qty_input'],
            )
        );
        $this->add_control(
            'qty_color',
            array(
                'label'     => esc_html__( 'Color', 'clever-woo-builder' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => array(
                    '{{WRAPPER}} ' . $css_scheme['qty_input'] => 'color: {{VALUE}};',
                ),
            )
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            array(
                'name'        => 'qty_border',
                'placeholder' => '1px',
                'default'     => '1px',
                'selector'    => '{{WRAPPER}} ' . $css_scheme['qty_input'],
            )
        );
        $this->add_control(
            'qty_button_options',
            array(
                'label'     => esc_html__( 'Navigation', 'clever-woo-builder' ),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'after'
            )
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            array(
                'name'     => 'qty_nav_typography',
                'selector' => '{{WRAPPER}} ' . $css_scheme['qty_nav'],
            )
        );
        $this->add_responsive_control(
            'qty_nav_padding',
            array(
                'label'      => esc_html__( 'Padding', 'clever-woo-builder' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', 'em', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} ' . $css_scheme['qty_nav'] => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
		$this->start_controls_tabs( 'tabs_qty_style' );

		$this->start_controls_tab(
			'tab_qty_normal',
			array(
				'label' => esc_html__( 'Normal', 'clever-woo-builder' ),
			)
		);

		$this->add_control(
			'qty_nav_color',
			array(
				'label'     => esc_html__( 'Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['qty_nav'] => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'qty_nav_bg',
			array(
				'label'     => esc_html__( 'Background', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['qty_nav'] => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'qty_nav_hover',
			array(
				'label' => esc_html__( 'Hover', 'clever-woo-builder' ),
			)
		);

		$this->add_control(
			'qty_nav_hover_color',
			array(
				'label'     => esc_html__( 'Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['qty_nav'] . ':hover' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'qty_nav_hover_bg',
			array(
				'label'     => esc_html__( 'Background', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['qty_nav'] . ':hover' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

        $this->add_control(
            'qty_section_bg',
            array(
                'label'     => esc_html__( 'Background Color', 'clever-woo-builder' ),
                'type'      => Controls_Manager::COLOR,
                'separator' => 'before',
                'selectors' => array(
                    '{{WRAPPER}} ' . $css_scheme['qty_section'] . ':hover' => 'background-color: {{VALUE}};',
                ),
            )
        );
		$this->add_control(
			'qty_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'clever-woo-builder' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} ' . $css_scheme['qty_section'] => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'qty_box_shadow',
				'selector' => '{{WRAPPER}} ' . $css_scheme['qty_section'],
			)
		);

		$this->add_responsive_control(
			'qty_padding',
			array(
				'label'      => esc_html__( 'Padding', 'clever-woo-builder' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} ' . $css_scheme['qty_section'] => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
				'separator'  => 'before',
			)
		);

		$this->add_responsive_control(
			'qty_margin',
			array(
				'label'      => esc_html__( 'Margin', 'clever-woo-builder' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} ' . $css_scheme['qty_section'] => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_countdown_style',
			array(
				'label' => esc_html__( 'Coundow Timer', 'clever-woo-builder' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
                    'countdown' => 'true',
                ],
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'countdown_typography',
				'selector' => '{{WRAPPER}} ' . $css_scheme['countdown_text'],
			)
		);

		$this->add_control(
			'countdown_text_color',
			array(
				'label'     => esc_html__( 'Text Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['countdown_text'] => 'color: {{VALUE}};',
				),
			)
		);
		
		$this->add_responsive_control(
			'countdown_text_padding',
			array(
				'label'      => esc_html__( 'Padding', 'clever-woo-builder' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} ' . $css_scheme['countdown_text'] => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'countdown_text_alignment',
			array(
				'label'     => esc_html__( 'Alignment', 'clever-woo-builder' ),
				'type'      => Controls_Manager::CHOOSE,
				'default'   => 'left',
				'options'   => array(
					'left'   => array(
						'title' => esc_html__( 'Left', 'clever-woo-builder' ),
						'icon'  => 'eicon-text-align-left',
					),
					'center' => array(
						'title' => esc_html__( 'Center', 'clever-woo-builder' ),
						'icon'  => 'eicon-text-align-center',
					),
					'right'  => array(
						'title' => esc_html__( 'Right', 'clever-woo-builder' ),
						'icon'  => 'eicon-text-align-right',
					),
				),
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['countdown_text'] => 'text-align: {{VALUE}};',
				),
				'classes'   => 'elementor-control-align',
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_term_style',
			array(
				'label' => esc_html__( 'Term & Conditions', 'clever-woo-builder' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
                    'add_to_cart_buy_now' => 'true',
                    'add_to_cart_buy_now_options' => 'ajax',
                ],
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'term_typography',
				'selector' => '{{WRAPPER}} ' . $css_scheme['term_label'],
			)
		);

		$this->add_control(
			'term_color',
			array(
				'label'     => esc_html__( 'Text Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['term_label'] => 'color: {{VALUE}};',
				),
			)
		);
		$this->add_control(
			'term_color_link',
			array(
				'label'     => esc_html__( 'Link Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['term_label'].' a' => 'color: {{VALUE}};',
				),
			)
		);
		$this->add_control(
			'term_color_link_hover',
			array(
				'label'     => esc_html__( 'Link Color Hover', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['term_label'].' a:hover' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'term_padding',
			array(
				'label'      => esc_html__( 'Padding', 'clever-woo-builder' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} ' . $css_scheme['term_label'] => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'term_label_alignment',
			array(
				'label'     => esc_html__( 'Alignment', 'clever-woo-builder' ),
				'type'      => Controls_Manager::CHOOSE,
				'default'   => 'left',
				'options'   => array(
					'left'   => array(
						'title' => esc_html__( 'Left', 'clever-woo-builder' ),
						'icon'  => 'eicon-text-align-left',
					),
					'center' => array(
						'title' => esc_html__( 'Center', 'clever-woo-builder' ),
						'icon'  => 'eicon-text-align-center',
					),
					'right'  => array(
						'title' => esc_html__( 'Right', 'clever-woo-builder' ),
						'icon'  => 'eicon-text-align-right',
					),
				),
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['term_label'] => 'text-align: {{VALUE}};',
				),
				'classes'   => 'elementor-control-align',
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_buy_now_style',
			array(
				'label' => esc_html__( 'Buy Now', 'clever-woo-builder' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
                    'add_to_cart_buy_now' => 'true',
                    'add_to_cart_buy_now_options' => 'ajax',
                ],
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'        => 'buy_now_typography',
				'scheme'      => Typography::TYPOGRAPHY_4,
				'selector'    => '{{WRAPPER}} ' . $css_scheme['buy_now'],
				'placeholder' => '1px',
			)
		);

		$this->add_responsive_control(
			'buy_now_width',
			array(
				'label'      => esc_html__( 'Buy Now Width', 'clever-woo-builder' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array(
					'%',
					'px',
				),
				'range'      => array(
					'%'  => array(
						'min' => 10,
						'max' => 100,
					),
					'px' => array(
						'min' => 50,
						'max' => 1000,
					),
				),
				'default'    => array(
					'unit' => 'px',
					'size' => '',
				),
				'selectors'  => array(
					'{{WRAPPER}} ' . $css_scheme['buy_now'] => 'width: {{SIZE}}{{UNIT}}',
				),
			)
		);

		$this->start_controls_tabs( 'tabs_buy_now_style' );

		$this->start_controls_tab(
			'tab_buy_now_normal',
			array(
				'label' => esc_html__( 'Normal', 'clever-woo-builder' ),
			)
		);

		$this->add_control(
			'buy_now_text_color',
			array(
				'label'     => esc_html__( 'Text Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['buy_now'] => 'color: {{VALUE}};',
				),

			)
		);

		$this->add_control(
			'buy_now_background_color',
			array(
				'label'     => esc_html__( 'Background Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['buy_now'] => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'buy_now_box_shadow',
				'selector' => '{{WRAPPER}} ' . $css_scheme['buy_now'],
			)
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_buy_now_hover',
			array(
				'label' => esc_html__( 'Hover', 'clever-woo-builder' ),
			)
		);

		$this->add_control(
			'buy_now_hover_color',
			array(
				'label'     => esc_html__( 'Text Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['buy_now'] . ':hover' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'buy_now_background_hover_color',
			array(
				'label'     => esc_html__( 'Background Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['buy_now'] . ':hover' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'buy_now_hover_border_color',
			array(
				'label'     => esc_html__( 'Border Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'condition' => array(
					'add_to_cart_border_border!' => '',
				),
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['buy_now'] . ':hover' => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'buy_now_hover_box_shadow',
				'selector' => '{{WRAPPER}} ' . $css_scheme['buy_now'] . ':hover',
			)
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_buy_now_disabled',
			array(
				'label' => esc_html__( 'Disabled', 'clever-woo-builder' ),
			)
		);

		$this->add_control(
			'buy_now_disabled_color',
			array(
				'label'     => esc_html__( 'Text Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['buy_now'] . '.disabled' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'buy_now_background_disabled_color',
			array(
				'label'     => esc_html__( 'Background Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['buy_now'] . '.disabled' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'buy_now_disabled_border_color',
			array(
				'label'     => esc_html__( 'Border Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'condition' => array(
					'add_to_cart_border_border!' => '',
				),
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['buy_now'] . '.disabled'       => 'border-color: {{VALUE}};',
					'{{WRAPPER}} ' . $css_scheme['buy_now'] . '.disabled:hover' => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'buy_now_disabled_box_shadow',
				'selector' => '{{WRAPPER}} ' . $css_scheme['buy_now'] . '.disabled',
			)
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'        => 'buy_now_border',
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} ' . $css_scheme['buy_now'],
				'separator'   => 'before'

			)
		);

		$this->add_control(
			'buy_now_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'clever-woo-builder' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} ' . $css_scheme['buy_now'] => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'buy_now_padding',
			array(
				'label'      => esc_html__( 'Padding', 'clever-woo-builder' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} ' . $css_scheme['buy_now'] => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
				'separator'  => 'before'
			)
		);

		$this->add_responsive_control(
			'buy_now_margin',
			array(
				'label'      => esc_html__( 'Margin', 'clever-woo-builder' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} ' . $css_scheme['buy_now'] => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_description_style',
			array(
				'label' => esc_html__( 'Description', 'clever-woo-builder' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'description_typography',
				'selector' => '{{WRAPPER}} ' . $css_scheme['description'],
			)
		);

		$this->add_control(
			'description_color',
			array(
				'label'     => esc_html__( 'Text Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['description'] => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'description_padding',
			array(
				'label'      => esc_html__( 'Padding', 'clever-woo-builder' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} ' . $css_scheme['description'] => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'description_alignment',
			array(
				'label'     => esc_html__( 'Alignment', 'clever-woo-builder' ),
				'type'      => Controls_Manager::CHOOSE,
				'default'   => 'left',
				'options'   => array(
					'left'   => array(
						'title' => esc_html__( 'Left', 'clever-woo-builder' ),
						'icon'  => 'eicon-text-align-left',
					),
					'center' => array(
						'title' => esc_html__( 'Center', 'clever-woo-builder' ),
						'icon'  => 'eicon-text-align-center',
					),
					'right'  => array(
						'title' => esc_html__( 'Right', 'clever-woo-builder' ),
						'icon'  => 'eicon-text-align-right',
					),
				),
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['description'] => 'text-align: {{VALUE}};',
				),
				'classes'   => 'elementor-control-align',
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_price_style',
			array(
				'label' => esc_html__( 'Variation Price', 'clever-woo-builder' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'price_typography',
				'selector' => '{{WRAPPER}} ' . $css_scheme['price'],
			)
		);

		$this->add_control(
			'price_color',
			array(
				'label'     => esc_html__( 'Price Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['price'] => 'color: {{VALUE}};',
				),
			)
		);
		$this->add_control(
			'reg_price_color',
			array(
				'label'     => esc_html__( 'Regular Price Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['price_reg'] => 'color: {{VALUE}};',
				),
			)
		);$this->add_control(
			'sale_price_color',
			array(
				'label'     => esc_html__( 'Sale Price Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['price_sale'] => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'price_padding',
			array(
				'label'      => esc_html__( 'Padding', 'clever-woo-builder' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} ' . $css_scheme['price'] => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->add_responsive_control(
			'price_margin',
			array(
				'label'      => esc_html__( 'Margin', 'clever-woo-builder' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} ' . $css_scheme['wrap_price'] => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'price_alignment',
			array(
				'label'     => esc_html__( 'Alignment', 'clever-woo-builder' ),
				'type'      => Controls_Manager::CHOOSE,
				'default'   => 'left',
				'options'   => array(
					'left'   => array(
						'title' => esc_html__( 'Left', 'clever-woo-builder' ),
						'icon'  => 'eicon-text-align-left',
					),
					'center' => array(
						'title' => esc_html__( 'Center', 'clever-woo-builder' ),
						'icon'  => 'eicon-text-align-center',
					),
					'right'  => array(
						'title' => esc_html__( 'Right', 'clever-woo-builder' ),
						'icon'  => 'eicon-text-align-right',
					),
				),
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['price'] => 'text-align: {{VALUE}};',
				),
				'classes'   => 'elementor-control-align',
			)
		);

		$this->add_control(
			'price_currency_style',
			array(
				'label'     => esc_html__( 'Currency Symbol', 'clever-woo-builder' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'price_currency_typography',
				'selector' => '{{WRAPPER}} ' . $css_scheme['currency'],
			)
		);

		$this->add_control(
			'price_currency_vertical_align',
			array(
				'label'     => esc_html__( 'Vertical Alignment', 'clever-woo-builder' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => array(
					'baseline'    => esc_html__( 'Baseline', 'clever-woo-builder' ),
					'top'         => esc_html__( 'Top', 'clever-woo-builder' ),
					'middle'      => esc_html__( 'Middle', 'clever-woo-builder' ),
					'bottom'      => esc_html__( 'Bottom', 'clever-woo-builder' ),
					'sub'         => esc_html__( 'Sub', 'clever-woo-builder' ),
					'super'       => esc_html__( 'Super', 'clever-woo-builder' ),
					'text-top'    => esc_html__( 'Text Top', 'clever-woo-builder' ),
					'text-bottom' => esc_html__( 'Text Bottom', 'clever-woo-builder' ),
				),
				'default'   => 'baseline',
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['currency'] => 'vertical-align: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_availability_style',
			array(
				'label' => esc_html__( 'Availability', 'clever-woo-builder' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->start_controls_tabs( 'tabs_availability' );

		$this->start_controls_tab(
			'tab_availability_in_stock',
			array(
				'label' => esc_html__( 'In Stock', 'clever-woo-builder' ),
			)
		);

		$this->add_control(
			'availability_in_stock_color',
			array(
				'label'     => esc_html__( 'Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['in_stock'] => 'color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_availability_out_of_stock',
			array(
				'label' => esc_html__( 'Out of Stock', 'clever-woo-builder' ),
			)
		);

		$this->add_control(
			'availability_out_of_stock_color',
			array(
				'label'     => esc_html__( 'Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['out_stock'] => 'color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'availability_typography',
				'selector' => '{{WRAPPER}} ' . $css_scheme['availability'],
			)
		);

		$this->add_responsive_control(
			'availability_padding',
			array(
				'label'      => esc_html__( 'Padding', 'clever-woo-builder' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} ' . $css_scheme['availability'] => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'availability_alignment',
			array(
				'label'     => esc_html__( 'Alignment', 'clever-woo-builder' ),
				'type'      => Controls_Manager::CHOOSE,
				'default'   => 'left',
				'options'   => array(
					'left'   => array(
						'title' => esc_html__( 'Left', 'clever-woo-builder' ),
						'icon'  => 'eicon-text-align-left',
					),
					'center' => array(
						'title' => esc_html__( 'Center', 'clever-woo-builder' ),
						'icon'  => 'eicon-text-align-center',
					),
					'right'  => array(
						'title' => esc_html__( 'Right', 'clever-woo-builder' ),
						'icon'  => 'eicon-text-align-right',
					),
				),
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['availability'] => 'text-align: {{VALUE}};',
				),
				'classes'   => 'elementor-control-align',
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_reset_button_style',
			array(
				'label' => esc_html__( 'Reset Button', 'clever-woo-builder' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'        => 'reset_button_typography',
				'scheme'      => Typography::TYPOGRAPHY_4,
				'selector'    => '{{WRAPPER}} ' . $css_scheme['reset_button'],
				'placeholder' => '1px',
			)
		);

		$this->start_controls_tabs( 'tabs_reset_button_style' );

		$this->start_controls_tab(
			'tab_reset_button_normal',
			array(
				'label' => esc_html__( 'Normal', 'clever-woo-builder' ),
			)
		);

		$this->add_control(
			'reset_button_text_color',
			array(
				'label'     => esc_html__( 'Text Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['reset_button'] => 'color: {{VALUE}};',
				),

			)
		);

		$this->add_control(
			'reset_button_background_color',
			array(
				'label'     => esc_html__( 'Background Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['reset_button'] => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_reset_button_hover',
			array(
				'label' => esc_html__( 'Hover', 'clever-woo-builder' ),
			)
		);

		$this->add_control(
			'reset_button_hover_color',
			array(
				'label'     => esc_html__( 'Text Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['reset_button'] . ':hover' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'reset_button_background_hover_color',
			array(
				'label'     => esc_html__( 'Background Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['reset_button'] . ':hover' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'reset_button_hover_border_color',
			array(
				'label'     => esc_html__( 'Border Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'condition' => array(
					'reset_button_border_border!' => '',
				),
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['reset_button'] . ':hover' => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'        => 'reset_button_border',
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} ' . $css_scheme['reset_button'],
				'separator'   => 'before'

			)
		);

		$this->add_control(
			'reset_button_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'clever-woo-builder' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} ' . $css_scheme['reset_button'] => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'reset_button_padding',
			array(
				'label'      => esc_html__( 'Padding', 'clever-woo-builder' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} ' . $css_scheme['reset_button'] => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
				'separator'  => 'before'
			)
		);

		$this->add_responsive_control(
			'reset_button_margin',
			array(
				'label'      => esc_html__( 'Margin', 'clever-woo-builder' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} ' . $css_scheme['reset_button'] => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_variation_select_style',
			array(
				'label' => esc_html__( 'Variations Select', 'clever-woo-builder' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'variation_select_typography',
				'selector' => '{{WRAPPER}} ' . $css_scheme['select'],
			)
		);

		$this->add_responsive_control(
			'variation_select_input_width',
			array(
				'label'      => esc_html__( 'Input Width', 'clever-woo-builder' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array(
					'%',
					'px',
				),
				'range'      => array(
					'%'  => array(
						'min' => 10,
						'max' => 100,
					),
					'px' => array(
						'min' => 50,
						'max' => 1000,
					),
				),
				'default'    => array(
					'unit' => 'px',
					'size' => 70,
				),
				'selectors'  => array(
					'{{WRAPPER}} ' . $css_scheme['variations_wrap'] => 'max-width: {{SIZE}}{{UNIT}}',
				),
			)
		);

		$this->start_controls_tabs( 'tabs_variation_select_style' );

		$this->start_controls_tab(
			'tab_variation_select_normal',
			array(
				'label' => esc_html__( 'Normal', 'clever-woo-builder' ),
			)
		);

		$this->add_control(
			'variation_select_color',
			array(
				'label'     => esc_html__( 'Text Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['select'] => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'variation_select_background_color',
			array(
				'label'     => esc_html__( 'Background Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['select'] => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_variation_select_focus',
			array(
				'label' => esc_html__( 'Focus', 'clever-woo-builder' ),
			)
		);

		$this->add_control(
			'variation_select_focus_color',
			array(
				'label'     => esc_html__( 'Text Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['select'] . ':focus' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'variation_select_focus_background_color',
			array(
				'label'     => esc_html__( 'Background Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['select'] . ':focus' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'variation_select_focus_border_color',
			array(
				'label'     => esc_html__( 'Border Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['select'] . ':focus' => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'        => 'variation_select_border',
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} ' . $css_scheme['select'],
				'separator'   => 'before'

			)
		);

		$this->add_control(
			'variation_select_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'clever-woo-builder' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} ' . $css_scheme['select'] => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'variation_select_box_shadow',
				'selector' => '{{WRAPPER}} ' . $css_scheme['select'],
			)
		);

		$this->add_responsive_control(
			'variation_select_padding',
			array(
				'label'      => esc_html__( 'Padding', 'clever-woo-builder' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} ' . $css_scheme['select'] => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
				'separator'  => 'before'
			)
		);

		$this->add_responsive_control(
			'variation_select_margin',
			array(
				'label'      => esc_html__( 'Margin', 'clever-woo-builder' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} ' . $css_scheme['select'] => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_variation_title_style',
			array(
				'label' => esc_html__( 'Variations Title', 'clever-woo-builder' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'variation_title_typography',
				'selector' => '{{WRAPPER}} ' . $css_scheme['label'],
			)
		);

		$this->add_control(
			'variation_title_color',
			array(
				'label'     => esc_html__( 'Text Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['label'] => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'variation_title_padding',
			array(
				'label'      => esc_html__( 'Padding', 'clever-woo-builder' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} ' . $css_scheme['label'] => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'variation_title_margin',
			array(
				'label'      => esc_html__( 'Margin', 'clever-woo-builder' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} ' . $css_scheme['label'] => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	protected function render() {

		$this->__context = 'render';

		global $product;

		$product = wc_get_product();

		if ( empty( $product ) ) {
			return;
		}

		$settings = apply_filters( 'clever-woo-builder/clever-woo-single-add-to-cart/settings', $this->get_settings(), $this );

		$open_wrap    = '';
		$close_wrap   = '';
		$popup_enable = ! empty( $settings['clever_woo_builder_cart_popup'] ) ? filter_var( $settings['clever_woo_builder_cart_popup'], FILTER_VALIDATE_BOOLEAN ) : false;
		$popup_id     = ! empty( $settings['clever_woo_builder_cart_popup_template'] ) ? esc_attr( $settings['clever_woo_builder_cart_popup_template'] ) : '';

		if ( $popup_enable ) {
			$open_wrap  = '<div class="clever-woo-builder-single-ajax-add-to-cart" data-cart-popup-enable=' . esc_attr( json_encode( $popup_enable ) ) . ' data-cart-popup-id=' . esc_attr( $popup_id ) . '>';
			$close_wrap = '</div>';
		}

        $allow_html=array('div'=>array('class'=>array(),'data-cart-popup-enable'=>array(),'data-cart-popup-id'=>array()));
		if ( true === $this->__set_editor_product() ) {
			$this->__open_wrap();

			echo wp_kses($open_wrap,$allow_html);
				include $this->__get_global_template( 'index' );
            echo wp_kses($close_wrap,$allow_html);
			
			$this->__close_wrap();
			$this->__reset_editor_product();
		}

	}
}
