<?php
/**
 * Class: Clever_Woo_Builder_Single_Images
 * Name: Single Images
 * Slug: clever-single-images
 */

namespace Elementor;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Repeater;
use Elementor\Core\Schemes\Color;
use Elementor\Widget_Base;
use Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly

class Clever_Woo_Builder_Single_Images extends Clever_Woo_Builder_Base {

	public function get_name() {
		return 'clever-single-images';
	}

	public function get_title() {
		return esc_html__( 'Single Images', 'clever-woo-builder' );
	}

	public function get_script_depends() {
		return array( 'slick','clever-woo-builder');
	}
    public function get_style_depends()
    {
        return array('slick');
    }
	public function get_icon() {
		return 'clever-woo-builder-icon-images';
	}

	public function get_clever_help_url() {
		return 'https://cleveraddon.com/knowledge-base/articles/cleverwoobuilder-how-to-create-and-set-a-single-product-page-template/';
	}

	public function get_categories() {
		return array( 'clever-woo-builder' );
	}

	public function show_in_panel() {
		return clever_woo_builder()->documents->is_document_type( 'single' );
	}

	protected function register_controls() {
        $this->start_controls_section(
            'section_general_options',
            array(
                'label' => esc_html__( 'General', 'clever-woo-builder' ),
            )
        );
        $this->add_control('layout', [
            'label' => esc_html__('Layout', 'clever-woo-builder'),
            'type' => Controls_Manager::SELECT,
            'default' => 'horizontal',
            'options' => [
                'horizontal' => esc_html__('Horizontal', 'clever-woo-builder'),
                'vertical' => esc_html__('Vertical', 'clever-woo-builder'),
                'carousel' => esc_html__('Carousel', 'clever-woo-builder'),
                'grid' => esc_html__('Grid', 'clever-woo-builder'),
            ],
            'description' => esc_html__('Gallery layout.', 'clever-woo-builder'),
        ]);
        $this->add_responsive_control('cols',[
            'label'         => esc_html__('Columns', 'clever-woo-builder' ),
            'type'          => Controls_Manager::SLIDER,
            'range' => [
                'px' =>[
                    'min' => 1,
                    'max' => 10,
                ]
            ],
            'desktop_default' => [
                'size' => 4,
                'unit' => 'px',
            ],
            'tablet_default' => [
                'size' => 2,
                'unit' => 'px',
            ],
            'mobile_default' => [
                'size' => 1,
                'unit' => 'px',
            ],
            'description' => esc_html__('Case layout is Horizontal or Vertical, this option will effect to thumbnail.', 'clever-woo-builder'),
            'devices' => [ 'desktop', 'tablet', 'mobile' ],
            'selectors' => [
                '{{WRAPPER}} .cwb-single-images.grid-layout .woocommerce-product-gallery__image, {{WRAPPER}} .cwb-single-images .thumbnail-item:not(.slick-slide)' => 'width: calc(100% / {{SIZE}});'
            ],
        ]);
        $this->add_control('thumb_right', [
            'label' => esc_html__('Show Thumbnail at Right', 'clever-woo-builder'),
            'type' => Controls_Manager::SWITCHER,
            'return_value' => 'true',
            'default' => 'false',
            'condition' => [
                'layout' => 'vertical'
            ],
            'selectors' => [
                '{{WRAPPER}} .cwb-single-images .wrap-main-product-gallery' => 'order:-1;'
            ],
        ]);
        $this->end_controls_section();
        $this->start_controls_section(
            'main_options',
            array(
                'label' => esc_html__( 'Main gallery', 'clever-woo-builder' ),
            )
        );
        $this->add_control('center_mod', [
            'label' => esc_html__('Center mod', 'clever-woo-builder'),
            'type' => Controls_Manager::SWITCHER,
            'return_value' => 'true',
            'default' => 'false',
            'condition' => [
                'layout' => 'carousel'
            ],
        ]);
        $this->add_responsive_control('center_padding',[
            'label'         => esc_html__('Center Padding', 'clever-woo-builder' ),
            'type'          => Controls_Manager::SLIDER,
            'size_units' => ['px'],
            'range' => [
                'px' =>[
                    'min' => 0,
                    'max' => 1000,
                ]
            ],
            'condition' => [
                'center_mod' => 'true'
            ],
        ]);
        $this->add_responsive_control('gutter',[
            'label'         => esc_html__('Gutter', 'clever-woo-builder' ),
            'type'          => Controls_Manager::SLIDER,
            'range' => [
                'px' =>[
                    'min' => 0,
                    'max' => 100,
                ]
            ],
            'desktop_default' => [
                'size' => 10,
                'unit' => 'px',
            ],
            'tablet_default' => [
                'size' => 10,
                'unit' => 'px',
            ],
            'mobile_default' => [
                'size' => 10,
                'unit' => 'px',
            ],
            'condition' => [
                'layout' => ['grid','carousel']
            ],
            'description' => esc_html__('Space between each image.', 'clever-woo-builder'),
            'devices' => [ 'desktop', 'tablet', 'mobile' ],
            'selectors' => [
                '{{WRAPPER}} .cwb-single-images .woocommerce-product-gallery__image' => 'padding:0 calc({{SIZE}}{{UNIT}} / 2) {{SIZE}}{{UNIT}};',
                '{{WRAPPER}} .cwb-single-images .woocommerce-product-gallery__wrapper' => 'margin-left:calc(-{{SIZE}}{{UNIT}} / 2);margin-right:calc(-{{SIZE}}{{UNIT}} / 2);width:calc(100% + {{SIZE}}{{UNIT}})'
            ],
        ]);
        $this->add_responsive_control('gallery_space',[
            'label'         => esc_html__('Space', 'clever-woo-builder' ),
            'type'          => Controls_Manager::SLIDER,
            'range' => [
                'px' =>[
                    'min' => 0,
                    'max' => 300,
                ]
            ],
            'desktop_default' => [
                'size' => 20,
                'unit' => 'px',
            ],
            'tablet_default' => [
                'size' => 20,
                'unit' => 'px',
            ],
            'mobile_default' => [
                'size' => 20,
                'unit' => 'px',
            ],
            'condition' => [
                'layout' => ['vertical','horizontal']
            ],
            'description' => esc_html__('Space between main gallery and thumbnail.', 'clever-woo-builder'),
            'devices' => [ 'desktop', 'tablet', 'mobile' ],
            'selectors' => [
                '{{WRAPPER}} .cwb-single-images' => '--gallery-space:{{SIZE}}{{UNIT}};'
            ],
        ]);

        $this->add_control('dots_arrows_heading', [
            'label' => esc_html__('Navigation', 'clever-woo-builder'),
            'type' => Controls_Manager::HEADING,
            'separator'   => 'after',
        ]);
        $this->add_responsive_control('dots', [
            'label' => esc_html__('Show pagination', 'clever-woo-builder'),
            'type' => Controls_Manager::SWITCHER,
            'description' => esc_html__('Show gallery pagination. Apply only for main gallery', 'clever-woo-builder'),
            'return_value' => 'true',
            'default' => 'false',
            'devices' => [ 'desktop', 'tablet', 'mobile' ],
        ]);
        $this->add_responsive_control('arrows', [
            'label' => esc_html__('Show navigation', 'clever-woo-builder'),
            'type' => Controls_Manager::SWITCHER,
            'description' => esc_html__('Show next and previous button.', 'clever-woo-builder'),
            'return_value' => 'true',
            'default' => 'false',
            'devices' => [ 'desktop', 'tablet', 'mobile' ],
        ]);
        $this->add_control('arrow_left', [
            'label' => esc_html__('Arrow Previous', 'clever-woo-builder'),
            'type' => 'cwbclevericon',
            'default' => 'cs-font clever-icon-prev',
            'condition' => [
                'arrows' => 'true'
            ],
        ]);
        $this->add_control('arrow_right', [
            'label' => esc_html__('Arrow Next', 'clever-woo-builder'),
            'type' => 'cwbclevericon',
            'default' => 'cs-font clever-icon-next',
            'condition' => [
                'arrows' => 'true'
            ],
        ]);
        $this->end_controls_section();
        $this->start_controls_section(
            'thumbnail_options',
            array(
                'label' => esc_html__( 'Thumbnail', 'clever-woo-builder' ),
            )
        );
        $this->add_responsive_control('thumb_width',[
            'label'         => esc_html__('Thumbnail width', 'clever-woo-builder' ),
            'type'          => Controls_Manager::SLIDER,
            'size_units' => ['px','%'],
            'range' => [
                'px' =>[
                    'min' => 0,
                    'max' => 300,
                ],'%' =>[
                    'min' => 0,
                    'max' => 100,
                ]
            ],
            'desktop_default' => [
                'size' => 150,
                'unit' => 'px',
            ],
            'tablet_default' => [
                'size' => 150,
                'unit' => 'px',
            ],
            'mobile_default' => [
                'size' => 150,
                'unit' => 'px',
            ],
            'condition' => [
                'layout' => ['vertical']
            ],
            'description' => esc_html__('Space between main gallery and thumbnail.', 'clever-woo-builder'),
            'devices' => [ 'desktop', 'tablet', 'mobile' ],
            'selectors' => [
                '{{WRAPPER}} .cwb-single-images .wrap-list-thumbnail' => 'width:{{SIZE}}{{UNIT}};',
                '{{WRAPPER}} .cwb-single-images .wrap-main-product-gallery' => '--main-gallery-width:calc(100% - {{SIZE}}{{UNIT}});'
            ],
        ]);
        $this->add_responsive_control('thumb_gutter',[
            'label'         => esc_html__('Thumbnail Gutter', 'clever-woo-builder' ),
            'type'          => Controls_Manager::SLIDER,
            'range' => [
                'px' =>[
                    'min' => 0,
                    'max' => 100,
                ]
            ],
            'desktop_default' => [
                'size' => 10,
                'unit' => 'px',
            ],
            'tablet_default' => [
                'size' => 10,
                'unit' => 'px',
            ],
            'mobile_default' => [
                'size' => 10,
                'unit' => 'px',
            ],
            'condition' => [
                'layout' => ['vertical','horizontal']
            ],
            'description' => esc_html__('Space between each thumbnail.', 'clever-woo-builder'),
            'devices' => [ 'desktop', 'tablet', 'mobile' ],
            'selectors' => [
                '{{WRAPPER}} .cwb-single-images.horizontal-layout .wrap-list-thumbnail li' => 'padding:0 calc({{SIZE}}{{UNIT}} / 2);',
                '{{WRAPPER}} .cwb-single-images.horizontal-layout .wrap-list-thumbnail' => 'margin-left:calc(-{{SIZE}}{{UNIT}} / 2);margin-right:calc(-{{SIZE}}{{UNIT}} / 2) ',
                '{{WRAPPER}} .cwb-single-images.vertical-layout .wrap-list-thumbnail li' => 'padding:calc({{SIZE}}{{UNIT}} / 2) 0;',
                '{{WRAPPER}} .cwb-single-images.vertical-layout .wrap-list-thumbnail' => 'margin-top:calc(-{{SIZE}}{{UNIT}} / 2);',
            ],
        ]);
        $this->add_control('thumb_nav_heading', [
            'label' => esc_html__('Navigation', 'clever-woo-builder'),
            'type' => Controls_Manager::HEADING,
            'separator'   => 'after',
        ]);
        $this->add_responsive_control('thumb_arrows', [
            'label' => esc_html__('Show navigation', 'clever-woo-builder'),
            'type' => Controls_Manager::SWITCHER,
            'description' => esc_html__('Show next and previous button.', 'clever-woo-builder'),
            'return_value' => 'true',
            'default' => 'true',
            'devices' => [ 'desktop', 'tablet', 'mobile' ],
        ]);
        $this->add_control('thumb_arrow_left', [
            'label' => esc_html__('Arrow Previous', 'clever-woo-builder'),
            'type' => 'cwbclevericon',
            'default' => 'cs-font clever-icon-prev',
            'condition' => [
                'arrows' => 'true'
            ],
        ]);
        $this->add_control('thumb_arrow_right', [
            'label' => esc_html__('Arrow Next', 'clever-woo-builder'),
            'type' => 'cwbclevericon',
            'default' => 'cs-font clever-icon-next',
            'condition' => [
                'arrows' => 'true'
            ],
        ]);

        $this->end_controls_section();

		$this->start_controls_section(
			'section_single_main_image_style',
			array(
				'label' => esc_html__( 'Main Image', 'clever-woo-builder' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);
		$this->add_control(
			'main_image_background_color',
			array(
				'label' => esc_html__( 'Background Color', 'clever-woo-builder' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wrap-main-product-gallery '  => 'background-color: {{VALUE}}',
				),
			)
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'     => 'main_image_border',
				'selector' => '{{WRAPPER}} .wrap-main-product-gallery .woocommerce-product-gallery__image',
			)
		);

		$this->add_responsive_control(
			'main_image_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'clever-woo-builder' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .wrap-main-product-gallery .woocommerce-product-gallery__image'=> 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->add_responsive_control(
			'main_image_margin',
			array(
				'label'      => esc_html__( 'Margin', 'clever-woo-builder' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .wrap-main-product-gallery .woocommerce-product-gallery__image'=> 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'main_image_box_shadow',
				'selector' => '{{WRAPPER}} .wrap-main-product-gallery',
			)
		);
        $this->end_controls_section();

        $this->start_controls_section(
            'section_main_pagination_style',
            array(
                'label' => esc_html__( 'Main Pagination', 'clever-woo-builder' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            )
        );
        $this->add_responsive_control('dots_size',[
            'label'         => esc_html__('Size', 'clever-woo-builder' ),
            'type'          => Controls_Manager::SLIDER,
            'range' => [
                'px' =>[
                    'min' => 0,
                    'max' => 100,
                ]
            ],
            'desktop_default' => [
                'size' => 10,
                'unit' => 'px',
            ],
            'tablet_default' => [
                'size' => 10,
                'unit' => 'px',
            ],
            'mobile_default' => [
                'size' => 10,
                'unit' => 'px',
            ],
            'devices' => [ 'desktop', 'tablet', 'mobile' ],
            'selectors' => [
                '{{WRAPPER}} .wrap-main-product-gallery .slick-dots button' => 'width:{{SIZE}}{{UNIT}};height:{{SIZE}}{{UNIT}}',
            ],
        ]);
        $this->add_responsive_control('dots_space',[
            'label'         => esc_html__('Space', 'clever-woo-builder' ),
            'type'          => Controls_Manager::SLIDER,
            'range' => [
                'px' =>[
                    'min' => 0,
                    'max' => 100,
                ]
            ],
            'desktop_default' => [
                'size' => 10,
                'unit' => 'px',
            ],
            'tablet_default' => [
                'size' => 10,
                'unit' => 'px',
            ],
            'mobile_default' => [
                'size' => 10,
                'unit' => 'px',
            ],
            'description' => esc_html__('Space between each item.', 'clever-woo-builder'),
            'devices' => [ 'desktop', 'tablet', 'mobile' ],
            'selectors' => [
                '{{WRAPPER}} .wrap-main-product-gallery .slick-dots li' => 'margin-right:{{SIZE}}{{UNIT}};',
            ],
        ]);
        $this->start_controls_tabs( 'dots_background_tabs' );

        $this->start_controls_tab( 'dots_normal', [ 'label' => esc_html__('Normal', 'cafe-lite' ) ] );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            array(
                'name'     => 'dots_border',
                'selector' => '{{WRAPPER}} .wrap-main-product-gallery .slick-dots button',
            )
        );
        $this->add_control(
            'dots_bg_color',
            array(
                'label' => esc_html__( 'Background Color', 'clever-woo-builder' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .wrap-main-product-gallery .slick-dots button'  => 'background-color: {{VALUE}}',
                ),
            )
        );
        $this->end_controls_tab();
        $this->start_controls_tab( 'dots_active', [ 'label' => esc_html__('Hover/Active', 'cafe-lite' ) ] );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            array(
                'name'     => 'dots_active_border',
                'selector' => '{{WRAPPER}} .wrap-main-product-gallery .slick-dots button:hover, {{WRAPPER}} .wrap-main-product-gallery .slick-dots .slick-active button',
            )
        );
        $this->add_control(
            'dots_active_bg_color',
            array(
                'label' => esc_html__( 'Background Color', 'clever-woo-builder' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .wrap-main-product-gallery .slick-dots button:hover, {{WRAPPER}} .wrap-main-product-gallery .slick-dots .slick-active button'  => 'background-color: {{VALUE}}',
                ),
            )
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();

        $this->add_responsive_control(
            'dots_border_radius',
            array(
                'label'      => esc_html__( 'Border Radius', 'clever-woo-builder' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'separator'   => 'before',
                'size_units' => array( 'px', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} .wrap-main-product-gallery .slick-dots button'=> 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_responsive_control(
            'dots_margin',
            array(
                'label'      => esc_html__( 'Margin', 'clever-woo-builder' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'separator'   => 'before',
                'size_units' => array( 'px', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} .wrap-main-product-gallery .slick-dots'=> 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'section_main_nav_style',
            array(
                'label' => esc_html__( 'Main Navigation', 'clever-woo-builder' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            )
        );
        $this->add_responsive_control('nav_size',[
            'label'         => esc_html__('Size', 'clever-woo-builder' ),
            'type'          => Controls_Manager::SLIDER,
            'range' => [
                'px' =>[
                    'min' => 0,
                    'max' => 200,
                ]
            ],
            'desktop_default' => [
                'size' => 10,
                'unit' => 'px',
            ],
            'tablet_default' => [
                'size' => 10,
                'unit' => 'px',
            ],
            'mobile_default' => [
                'size' => 10,
                'unit' => 'px',
            ],
            'devices' => [ 'desktop', 'tablet', 'mobile' ],
            'selectors' => [
                '{{WRAPPER}} .cwb-single-images .wrap-main-product-gallery .cwb-carousel-btn' => 'width:{{SIZE}}{{UNIT}};height:{{SIZE}}{{UNIT}}',
            ],
        ]);

        $this->add_responsive_control('nav_icon_size',[
            'label'         => esc_html__('Icon Size', 'clever-woo-builder' ),
            'type'          => Controls_Manager::SLIDER,
            'range' => [
                'px' =>[
                    'min' => 0,
                    'max' => 100,
                ]
            ],
            'desktop_default' => [
                'size' => 10,
                'unit' => 'px',
            ],
            'tablet_default' => [
                'size' => 10,
                'unit' => 'px',
            ],
            'mobile_default' => [
                'size' => 10,
                'unit' => 'px',
            ],
            'condition' => [
                'layout' => ['vertical','horizontal']
            ],
            'description' => esc_html__('Space between each item.', 'clever-woo-builder'),
            'devices' => [ 'desktop', 'tablet', 'mobile' ],
            'selectors' => [
                '{{WRAPPER}} .wrap-main-product-gallery .cwb-carousel-btn' => 'font-size:{{SIZE}}{{UNIT}};',
            ],
        ]);
        $this->start_controls_tabs( 'nav_background_tabs' );

        $this->start_controls_tab( 'nav_normal', [ 'label' => esc_html__('Normal', 'cafe-lite' ) ] );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            array(
                'name'     => 'nav_border',
                'selector' => '{{WRAPPER}} .wrap-main-product-gallery .cwb-carousel-btn',
            )
        );
        $this->add_control(
            'nav_color',
            array(
                'label' => esc_html__( 'Color', 'clever-woo-builder' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .wrap-main-product-gallery .cwb-carousel-btn'  => 'color: {{VALUE}}',
                ),
            )
        );
        $this->add_control(
            'nav_bg_color',
            array(
                'label' => esc_html__( 'Background Color', 'clever-woo-builder' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .wrap-main-product-gallery .cwb-carousel-btn'  => 'background-color: {{VALUE}}',
                ),
            )
        );
        $this->end_controls_tab();
        $this->start_controls_tab( 'nav_active', [ 'label' => esc_html__('Hover/Active', 'cafe-lite' ) ] );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            array(
                'name'     => 'nav_active_border',
                'selector' => '{{WRAPPER}} .wrap-main-product-gallery .cwb-carousel-btn:hover',
            )
        );
        $this->add_control(
            'nav_active_color',
            array(
                'label' => esc_html__( 'Color', 'clever-woo-builder' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .wrap-main-product-gallery .cwb-carousel-btn:hover'  => 'color: {{VALUE}}',
                ),
            )
        );
        $this->add_control(
            'nav_active_bg_color',
            array(
                'label' => esc_html__( 'Background Color', 'clever-woo-builder' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .wrap-main-product-gallery .cwb-carousel-btn:hover'  => 'background-color: {{VALUE}}',
                ),
            )
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->add_responsive_control(
            'nav_border_radius',
            array(
                'label'      => esc_html__( 'Border Radius', 'clever-woo-builder' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'separator'   => 'before',
                'size_units' => array( 'px', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} .wrap-main-product-gallery .cwb-carousel-btn'=> 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );

		$this->end_controls_section();

		$this->start_controls_section(
			'section_single_image_thumbnails_style',
			array(
				'label' => esc_html__( 'Thumbnails', 'clever-woo-builder' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);
		$this->add_control(
			'image_thumbnails_background_color',
			array(
				'label' => esc_html__( 'Background Color', 'clever-woo-builder' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .thumbnail-item'=> 'background-color: {{VALUE}}',
				),
			)
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'     => 'image_thumbnails_border',
				'selector' => '{{WRAPPER}} .thumbnail-item img',
			)
		);
        $this->add_control(
            'image_thumbnails_active_border_heading',
            array(
                'label'     => esc_html__( 'Active border', 'clever-woo-builder' ),
                'type' => Controls_Manager::HEADING,
                'separator'   => 'after',
            )
        );

        $this->add_group_control(
			Group_Control_Border::get_type(),
			array(
                'label' => esc_html__( 'Active border', 'clever-woo-builder' ),
				'name'     => 'image_thumbnails_active_border',
				'selector' => '{{WRAPPER}} .thumbnail-item.slick-current img, {{WRAPPER}}  .thumbnail-item:hover img',
			)
		);

		$this->add_responsive_control(
			'image_thumbnails_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'clever-woo-builder' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .thumbnail-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'image_thumbnails_box_shadow',
				'selector' => '{{WRAPPER}} .thumbnail-item',
			)
		);

		$this->end_controls_section();

        $this->start_controls_section(
            'section_thumb_nav_style',
            array(
                'label' => esc_html__( 'Thumb Navigation', 'clever-woo-builder' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'layout' => ['vertical','horizontal']
                ],
            )
        );
        $this->add_responsive_control('thumb_size',[
            'label'         => esc_html__('Size', 'clever-woo-builder' ),
            'type'          => Controls_Manager::SLIDER,
            'range' => [
                'px' =>[
                    'min' => 0,
                    'max' => 200,
                ]
            ],
            'desktop_default' => [
                'size' => 10,
                'unit' => 'px',
            ],
            'tablet_default' => [
                'size' => 10,
                'unit' => 'px',
            ],
            'mobile_default' => [
                'size' => 10,
                'unit' => 'px',
            ],
            'devices' => [ 'desktop', 'tablet', 'mobile' ],
            'selectors' => [
                '{{WRAPPER}} .wrap-list-thumbnail .cwb-carousel-btn' => 'width:{{SIZE}}{{UNIT}};height:{{SIZE}}{{UNIT}}',
            ],
        ]);

        $this->add_responsive_control('thumb_nav_icon_size',[
            'label'         => esc_html__('Icon Size', 'clever-woo-builder' ),
            'type'          => Controls_Manager::SLIDER,
            'range' => [
                'px' =>[
                    'min' => 0,
                    'max' => 100,
                ]
            ],
            'desktop_default' => [
                'size' => 10,
                'unit' => 'px',
            ],
            'tablet_default' => [
                'size' => 10,
                'unit' => 'px',
            ],
            'mobile_default' => [
                'size' => 10,
                'unit' => 'px',
            ],
            'devices' => [ 'desktop', 'tablet', 'mobile' ],
            'selectors' => [
                '{{WRAPPER}} .cwb-single-images .wrap-list-thumbnail .cwb-carousel-btn' => 'font-size:{{SIZE}}{{UNIT}};',
            ],
        ]);
        $this->start_controls_tabs( 'thumb_nav_background_tabs' );

        $this->start_controls_tab( 'thumb_nav_normal', [ 'label' => esc_html__('Normal', 'cafe-lite' ) ] );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            array(
                'name'     => 'thumb_nav_border',
                'selector' => '{{WRAPPER}} .cwb-single-images .wrap-list-thumbnail .cwb-carousel-btn',
            )
        );
        $this->add_control(
            'thumb_nav_color',
            array(
                'label' => esc_html__( 'Color', 'clever-woo-builder' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .cwb-single-images .wrap-list-thumbnail .cwb-carousel-btn'  => 'color: {{VALUE}}',
                ),
            )
        );
        $this->add_control(
            'thumb_nav_bg_color',
            array(
                'label' => esc_html__( 'Background Color', 'clever-woo-builder' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .cwb-single-images .wrap-list-thumbnail .cwb-carousel-btn'  => 'background-color: {{VALUE}}',
                ),
            )
        );
        $this->end_controls_tab();
        $this->start_controls_tab( 'thumb_nav_active', [ 'label' => esc_html__('Hover/Active', 'cafe-lite' ) ] );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            array(
                'name'     => 'thumb_nav_active_border',
                'selector' => '{{WRAPPER}} .cwb-single-images .wrap-list-thumbnail .cwb-carousel-btn:hover',
            )
        );
        $this->add_control(
            'thumb_nav_active_color',
            array(
                'label' => esc_html__( 'Color', 'clever-woo-builder' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .cwb-single-images .wrap-list-thumbnail .cwb-carousel-btn:hover'  => 'color: {{VALUE}}',
                ),
            )
        );
        $this->add_control(
            'thumb_nav_active_bg_color',
            array(
                'label' => esc_html__( 'Background Color', 'clever-woo-builder' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .cwb-single-images .wrap-list-thumbnail .cwb-carousel-btn:hover'  => 'background-color: {{VALUE}}',
                ),
            )
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->add_responsive_control(
            'thumb_nav_border_radius',
            array(
                'label'      => esc_html__( 'Border Radius', 'clever-woo-builder' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'separator'   => 'before',
                'size_units' => array( 'px', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} .cwb-single-images .wrap-list-thumbnail .cwb-carousel-btn'=> 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->end_controls_section();

	}

	protected function render() {

		$this->__context = 'render';

		global $product;

		$product = wc_get_product();

		if ( empty( $product ) ) {
			return;
		}

		if ( true === $this->__set_editor_product() ) {
			$this->__open_wrap();
			include $this->__get_global_template( 'index' );
			$this->__close_wrap();
			$this->__reset_editor_product();
		}
	}
}
