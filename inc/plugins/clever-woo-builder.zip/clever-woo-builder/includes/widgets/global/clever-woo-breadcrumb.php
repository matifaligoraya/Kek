<?php
/**
 * Class: Clever_Woo_BreadCrumb
 * Name: WooCommerce BreadCrumb
 * Slug: clever-woo-breadcrumb
 */

namespace Elementor;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Color;
use Elementor\Widget_Base;
use Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly

class Clever_Woo_BreadCrumb extends Clever_Woo_Builder_Base {

	public function get_name() {
		return 'clever-woo-breadcrumb';
	}

	public function get_title() {
		return esc_html__( 'WooCommerce BreadCrumb', 'clever-woo-builder' );
	}

	public function get_icon() {
        return 'clever-woo-builder-icon-taxonomy-tiles';
	}

	public function get_categories() {
		return array( 'clever-woo-builder' );
	}

	public function __shortcode() {
		return clever_woo_builder_shortocdes()->get_shortcode( $this->get_name() );
	}

	protected function register_controls() {
		$this->start_controls_section(
			'breadcrumb_style',
			array(
				'label'      => esc_html__( 'Breadcrumb', 'clever-woo-builder' ),
				'tab'        => Controls_Manager::TAB_STYLE,
				'show_label' => false,
			)
		);
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            array(
                'name'     => 'breadcrumb_typography',
                'selector' => '{{WRAPPER}} .woocommerce-breadcrumb',
            )
        );
        $this->add_control(
            'color',
            array(
                'label'     => esc_html__( 'Color', 'clever-woo-builder' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .woocommerce-breadcrumb'  => 'color: {{VALUE}}',
                ),
            )
        );
        $this->add_control(
            'heading_link_color',
            array(
                'label'     => esc_html__( 'Link', 'clever-woo-builder' ),
                'type'      => Controls_Manager::HEADING,
                'separator'  => 'before'
            )
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            array(
                'name'     => 'breadcrumb_link_typography',
                'selector' => '{{WRAPPER}} .woocommerce-breadcrumb a',
            )
        );
        $this->start_controls_tabs( 'box_style_tabs' );

        $this->start_controls_tab(
            'link',
            array(
                'label' => esc_html__( 'Normal', 'clever-woo-builder' ),
            )
        );

        $this->add_control(
            'link_color',
            array(
                'label'     => esc_html__( 'Color', 'clever-woo-builder' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .woocommerce-breadcrumb a'  => 'color: {{VALUE}}',
                ),
            )
        );
        $this->end_controls_tab();

        $this->start_controls_tab(
            'link_hover',
            array(
                'label' => esc_html__( 'Hover', 'clever-woo-builder' ),
            )
        );

        $this->add_control(
            'link_hover_color',
            array(
                'label'     => esc_html__( 'Color', 'clever-woo-builder' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .woocommerce-breadcrumb a:hover' => 'color: {{VALUE}}',
                ),
            )
        );
        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_responsive_control(
            'box_padding',
            array(
                'label'      => esc_html__( 'Padding item', 'clever-woo-builder' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} .woocommerce-breadcrumb a'  => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
                'separator'  => 'before'
            )
        );
		$this->end_controls_section();

	}

	protected function render() {
		$this->__context = 'render';

		$this->__open_wrap();
        woocommerce_breadcrumb();
		$this->__close_wrap();
	}
	protected function _content_template() {
	}

}
