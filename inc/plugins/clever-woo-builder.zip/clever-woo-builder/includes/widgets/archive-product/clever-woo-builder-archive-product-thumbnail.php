<?php
/**
 * Class: Clever_Woo_Builder_Archive_Product_Thumbnail
 * Name: Thumbnail
 * Slug: clever-woo-builder-archive-product-thumbnail
 */

namespace Elementor;

use Elementor\Group_Control_Border;

if (!defined('ABSPATH')) exit; // Exit if accessed directly

class Clever_Woo_Builder_Archive_Product_Thumbnail extends Widget_Base
{

    private $source = false;

    public function get_name()
    {
        return 'clever-woo-builder-archive-product-thumbnail';
    }

    public function get_title()
    {
        return esc_html__('Thumbnail', 'clever-woo-builder');
    }

    public function get_icon()
    {
        return 'clever-woo-builder-icon-images';
    }

    public function get_help_url()
    {
        return 'https://cleveraddon.com/knowledge-base/articles/woocommerce-cleverwoobuilder-settings-how-to-create-and-set-a-custom-categories-archive-template/?utm_source=need-help&utm_medium=clever-woo-categories&utm_campaign=cleverwoobuilder';
    }

    public function get_categories()
    {
        return array('clever-woo-builder');
    }

    public function show_in_panel()
    {
        return clever_woo_builder()->documents->is_document_type('archive');
    }

    protected function register_controls()
    {

        $css_scheme = apply_filters(
            'clever-woo-builder/clever-archive-product-thumbnail/css-scheme',
            array(
                'thumbnail-wrapper' => '.clever-woo-builder-archive-product-thumbnail__wrapper',
                'thumbnail' => '.clever-woo-builder-archive-product-thumbnail'
            )
        );

        $this->start_controls_section(
            'section_general',
            array(
                'label' => __('Content', 'clever-woo-builder'),
            )
        );

        $this->add_control(
            'is_linked',
            array(
                'label' => esc_html__('Add link to title', 'clever-woo-builder'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'clever-woo-builder'),
                'label_off' => esc_html__('No', 'clever-woo-builder'),
                'return_value' => 'yes',
                'default' => '',
            )
        );

        $this->add_control(
            'enable_sec_img',
            array(
                'label' => esc_html__('Enable Second Images', 'clever-woo-builder'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'clever-woo-builder'),
                'label_off' => esc_html__('No', 'clever-woo-builder'),
                'return_value' => 'yes',
                'default' => '',
            )
        );

        $this->add_control(
            'archive_thumbnail_size',
            array(
                'type' => 'select',
                'label' => esc_html__('Thumbnail Size', 'clever-woo-builder'),
                'default' => 'woocommerce_thumbnail',
                'options' => clever_woo_builder_tools()->get_image_sizes(),
            )
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_archive_thumbnail_style',
            array(
                'label' => esc_html__('Thumbnail', 'clever-woo-builder'),
                'tab' => Controls_Manager::TAB_STYLE,
                'show_label' => false,
            )
        );

        $this->add_control(
            'archive_thumbnail_background_color',
            array(
                'label' => esc_html__('Background Color', 'clever-woo-builder'),
                'type' => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} ' . $css_scheme['thumbnail'] => 'background-color: {{VALUE}};',
                ),
            )
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            array(
                'name' => 'archive_thumbnail_border',
                'selector' => '{{WRAPPER}} ' . $css_scheme['thumbnail'],
            )
        );

        $this->add_control(
            'archive_thumbnail_border_radius',
            array(
                'label' => esc_html__('Border Radius', 'clever-woo-builder'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => array('px', '%'),
                'selectors' => array(
                    '{{WRAPPER}} ' . $css_scheme['thumbnail'] => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}; overflow:hidden;',
                ),
            )
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            array(
                'name' => 'archive_thumbnail_box_shadow',
                'selector' => '{{WRAPPER}} ' . $css_scheme['thumbnail'],
            )
        );

        $this->add_responsive_control(
            'archive_thumbnail_alignment',
            array(
                'label' => esc_html__('Alignment', 'clever-woo-builder'),
                'type' => Controls_Manager::CHOOSE,
                'options' => array(
                    'left' => array(
                        'title' => esc_html__('Left', 'clever-woo-builder'),
                        'icon' => 'eicon-text-align-left',
                    ),
                    'center' => array(
                        'title' => esc_html__('Center', 'clever-woo-builder'),
                        'icon' => 'eicon-text-align-center',
                    ),
                    'right' => array(
                        'title' => esc_html__('Right', 'clever-woo-builder'),
                        'icon' => 'eicon-text-align-right',
                    ),
                ),
                'selectors' => array(
                    '{{WRAPPER}} ' . $css_scheme['thumbnail-wrapper'] => 'text-align: {{VALUE}};',
                ),
                'classes' => 'elementor-control-align',
            )
        );

        $this->end_controls_section();

    }

    /**
     * Returns CSS selector for nested element
     *
     * @param  [type] $el [description]
     * @return [type]     [description]
     */
    public function css_selector($el = null)
    {
        return sprintf('{{WRAPPER}} .%1$s %2$s', $this->get_name(), $el);
    }

    public static function render_callback($settings = array())
    {

        $open_link = '';
        $close_link = '';
        global $product;
        if (isset($settings['is_linked']) && 'yes' === $settings['is_linked']) {
            $open_link = '<a href="' . get_permalink() . '">';
            $close_link = '</a>';
        }
        $allow_html = array('a' => array('class' => array(), 'href' => array()));
        $wrap_class = 'cwb-archive-product-thumb clever-woo-builder-archive-product-thumbnail__wrapper';
        if (isset($settings['enable_sec_img']) && 'yes' === $settings['enable_sec_img']) {
            $wrap_class .= ' enable-sec-img';
        }
        echo '<div class="' . esc_attr($wrap_class) . '">';
		echo '<div class="clever-woo-builder-archive-product-thumbnail">';
		echo wp_kses($open_link, $allow_html);
		echo clever_woo_builder_template_functions()->get_product_thumbnail(
            $settings['archive_thumbnail_size'],
            true,
            array(
                'class' => 'clever-woo-builder-archive-product-image',
                'data-no-lazy' => '1',
            )
        );
		if (isset($settings['enable_sec_img']) && 'yes' === $settings['enable_sec_img']) {
            $gallery = get_post_meta($product->get_id(), '_product_image_gallery', true);
            if (!empty($gallery)) {
                $gallery = explode(',', $gallery);
                $first_image_id = $gallery[0];
                echo wp_get_attachment_image($first_image_id, $settings['archive_thumbnail_size'], '', array('class' => 'sec-img hover-image'));
            }
        }
        echo wp_kses($close_link, $allow_html);
		echo '</div>';
		echo '</div>';

	}

    protected function render()
    {

        $settings = $this->get_settings();

        $macros_settings = array(
            'is_linked' => $settings['is_linked'],
            'enable_sec_img' => $settings['enable_sec_img'],
            'archive_thumbnail_size' => $settings['archive_thumbnail_size'],
        );

        if (clever_woo_builder_tools()->is_builder_content_save()) {
            echo clever_woo_builder()->parser->get_macros_string($this->get_name(), $macros_settings);
        } else {
            echo self::render_callback($macros_settings);
        }

    }

    public function add_product_classes()
    {
    }

}
