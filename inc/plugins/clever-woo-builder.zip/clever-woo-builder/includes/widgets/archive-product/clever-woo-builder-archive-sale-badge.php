<?php
/**
 * Class: Clever_Woo_Builder_Archive_Sale_Badge
 * Name: Sale Badge
 * Slug: clever-woo-builder-archive-sale-badge
 */

namespace Elementor;

use Elementor\Group_Control_Border;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly

class Clever_Woo_Builder_Archive_Sale_Badge extends Widget_Base {

	private $source = false;

	public function get_name() {
		return 'clever-woo-builder-archive-sale-badge';
	}

	public function get_title() {
		return esc_html__( 'Sale Badge', 'clever-woo-builder' );
	}

	public function get_icon() {
		return 'clever-woo-builder-icon-sale-badge';
	}

	public function get_help_url() {
		return 'https://cleveraddon.com/knowledge-base/articles/woocommerce-cleverwoobuilder-settings-how-to-create-and-set-a-custom-categories-archive-template/?utm_source=need-help&utm_medium=clever-woo-categories&utm_campaign=cleverwoobuilder';
	}

	public function get_categories() {
		return array( 'clever-woo-builder' );
	}

	public function show_in_panel() {
		return clever_woo_builder()->documents->is_document_type( 'archive' );
	}

	protected function register_controls() {

		$css_scheme = apply_filters(
			'clever-woo-builder/clever-archive-sale-badge/css-scheme',
			array(
				'wrapper' => '.clever-woo-builder-archive-product-sale-badge',
				'badge'   => '.clever-woo-product-badge__sale'
			)
		);
		$this->start_controls_section(
			'section_badge_content',
			array(
				'label'      => esc_html__( 'Content', 'clever-woo-builder' ),
				'tab'        => Controls_Manager::TAB_CONTENT,
				'show_label' => false,
			)
		);
        $this->add_control('display_type', [
            'label' => esc_html__('Display type', 'clever-woo-builder'),
            'type' => Controls_Manager::SELECT,
            'default' => 'label',
            'options' => [
                'label' => esc_html__('Label', 'clever-woo-builder'),
                'percent' => esc_html__('Percent', 'clever-woo-builder'),
                'numeric' => esc_html__('Numeric', 'clever-woo-builder'),
            ],
        ]);
		$this->add_control(
			'archive_badge_text',
			array(
				'type'        => 'text',
				'label'       => esc_html__( 'Sale Badge Text', 'clever-woo-builder' ),
				'default'     => 'Sale!',
                'condition' => [
                    'display_type' => 'label'
                ],
				'description' => esc_html__( 'Use %percentage_sale% and %numeric_sale% macros to display a withdrawal of discounts as a percentage or numeric of the initial price.', 'clever-woo-builder' ),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_archive_badge_style',
			array(
				'label'      => esc_html__( 'General', 'clever-woo-builder' ),
				'tab'        => Controls_Manager::TAB_STYLE,
				'show_label' => false,
			)
		);

		$this->add_control(
			'archive_badge_color',
			array(
				'label'     => esc_html__( 'Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['badge'] => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_control(
			'archive_badge_background',
			array(
				'label'     => esc_html__( 'Background', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['badge'] => 'background-color: {{VALUE}}',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'archive_badge_typography',
				'selector' => '{{WRAPPER}} ' . $css_scheme['badge'],
			)
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'        => 'archive_badge_border',
				'label'       => esc_html__( 'Border', 'clever-woo-builder' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} ' . $css_scheme['badge'],
			)
		);

		$this->add_responsive_control(
			'archive_badge_border_radius',
			array(
				'label'      => __( 'Border Radius', 'clever-woo-builder' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} ' . $css_scheme['badge'] => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'archive_badge_box_shadow',
				'selector' => '{{WRAPPER}} ' . $css_scheme['badge'],
			)
		);

		$this->add_responsive_control(
			'archive_badge_content_padding',
			array(
				'label'      => __( 'Padding', 'clever-woo-builder' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} ' . $css_scheme['badge'] => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'archive_badge_content_margin',
			array(
				'label'      => esc_html__( 'Margin', 'clever-woo-builder' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} ' . $css_scheme['wrapper'] => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'archive_badge_alignment',
			array(
				'label'     => esc_html__( 'Alignment', 'clever-woo-builder' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => array(
					'left'   => array(
						'title' => esc_html__( 'Left', 'clever-woo-builder' ),
						'icon'  => 'eicon-text-align-left',
					),
					'center' => array(
						'title' => esc_html__( 'Center', 'clever-woo-builder' ),
						'icon'  => 'eicon-text-align-center',
					),
					'right'  => array(
						'title' => esc_html__( 'Right', 'clever-woo-builder' ),
						'icon'  => 'eicon-text-align-right',
					),
				),
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['wrapper'] => 'text-align: {{VALUE}};',
				),
				'classes'   => 'elementor-control-align',
			)
		);

		$this->end_controls_section();

	}

	/**
	 * Returns CSS selector for nested element
	 *
	 * @param  [type] $el [description]
	 *
	 * @return [type]     [description]
	 */
	public function css_selector( $el = null ) {
		return sprintf( '{{WRAPPER}} .%1$s %2$s', $this->get_name(), $el );
	}

	public static function render_callback( $settings = array() ) {



        global $product;
        if ( $product->is_on_sale() ) :
            $percent=0;
            $numeric=0;
            if (!$product->is_type('grouped')) {
                $regular_price = $product->get_regular_price();
                $sale_price = $product->get_sale_price();
                if ($product->has_child()) {
                    $variation_prices = $product->get_variation_prices();
                    foreach ($variation_prices['price'] as $id => $value) {
                        $new_percent = round((($variation_prices['regular_price'][$id] - $value) / $variation_prices['regular_price'][$id]) * 100);
                        if ($new_percent > $percent) {
                            $numeric=$variation_prices['regular_price'][$id] - $value;
                            $percent = $new_percent;
                        }
                    }
                    $regular_price = $product->get_variation_regular_price('max', true);
                } else {
                    $numeric=$regular_price - $sale_price;
                    $percent = round(($numeric / $regular_price) * 100);
                }
            }
            if($settings['display_type']=='label'){
                $badge_text = clever_woo_builder()->macros->do_macros( $settings['archive_badge_text'] );
                $badge_text = clever_woo_builder_template_functions()->get_product_sale_flash( $badge_text );
            }elseif($settings['display_type']=='percent'){
                $badge_text=$percent.'%';
            }else{
                $badge_text=$numeric;
            }
            echo '<div class="clever-woo-builder-archive-product-sale-badge">';
            echo esc_html($badge_text);
            echo '</div>';
        endif;

	}


	protected function render() {
		$settings = $this->get_settings();

		$macros_settings = array(
			'display_type' => $settings['display_type'],
			'archive_badge_text' => $settings['archive_badge_text'],
		);

		if ( clever_woo_builder_tools()->is_builder_content_save() ) {
			echo clever_woo_builder()->parser->get_macros_string( $this->get_name(), $macros_settings );
		} else {
			echo self::render_callback( $macros_settings );
		}

	}

}
