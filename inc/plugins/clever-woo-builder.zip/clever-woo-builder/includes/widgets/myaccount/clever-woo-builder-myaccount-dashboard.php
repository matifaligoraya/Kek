<?php
/**
 * Class: Clever_Woo_Builder_MyAccount_Dashboard
 * Name: My Account Dashboard
 * Slug: clever-myaccount-dashboard
 */

namespace Elementor;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Repeater;
use Elementor\Core\Schemes\Color;
use Elementor\Widget_Base;
use Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly

class Clever_Woo_Builder_MyAccount_Dashboard extends Clever_Woo_Builder_Base {

	public function get_name() {
		return 'clever-myaccount-dashboard';
	}

	public function get_title() {
		return esc_html__( 'My Account Dashboard', 'clever-woo-builder' );
	}

	public function get_icon() {
		return 'clever-woo-builder-icon-my-account-dashboard';
	}

	public function get_clever_help_url() {
		return '';
	}

	public function get_categories() {
		return array( 'clever-woo-builder' );
	}

	public function show_in_panel() {
		return clever_woo_builder()->documents->is_document_type( 'myaccount' );
	}

	protected function register_controls() {

		$this->start_controls_section(
			'myaccount_dashboard_styles',
			array(
				'label' => esc_html__( 'Styles', 'clever-woo-builder' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'myaccount_dashboard_typography',
				'label'    => esc_html__( 'Typography', 'clever-woo-builder' ),
				'selector' => '{{WRAPPER}}',
			)
		);

		$this->add_control(
			'myaccount_dashboard_color',
			array(
				'label'     => esc_html__( 'Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}}' => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_control(
			'myaccount_dashboard_link_color',
			array(
				'label'     => esc_html__( 'Link Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} a' => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_control(
			'myaccount_dashboard_link_hover_color',
			array(
				'label'     => esc_html__( 'Link Hover Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} a:hover' => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_responsive_control(
			'myaccount_dashboard_align',
			array(
				'label'        => esc_html__( 'Alignment', 'clever-woo-builder' ),
				'type'         => Controls_Manager::CHOOSE,
				'options'      => array(
					'left'   => array(
						'title' => esc_html__( 'Left', 'clever-woo-builder' ),
						'icon'  => 'eicon-text-align-left',
					),
					'center' => array(
						'title' => esc_html__( 'Center', 'clever-woo-builder' ),
						'icon'  => 'eicon-text-align-center',
					),
					'right'  => array(
						'title' => esc_html__( 'Right', 'clever-woo-builder' ),
						'icon'  => 'eicon-text-align-right',
					),
				),
				'selectors' => array(
					'{{WRAPPER}}' => 'text-align: {{VALUE}}',
				),
				'classes'   => 'elementor-control-align',
			)
		);

		$this->end_controls_section();

	}

	protected function render() {

		$this->__context = 'render';
		
		$this->__open_wrap();

		include $this->__get_global_template( 'index' );
			
		$this->__close_wrap();

	}
}
