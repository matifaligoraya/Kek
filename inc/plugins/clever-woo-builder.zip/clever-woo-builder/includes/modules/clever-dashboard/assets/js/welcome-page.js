(function () {

	'use strict';

	Vue.component( 'welcome-page', {
		template: '#clever-dashboard-welcome-page',
		data: function() {
			return {};
		}
	} );

})();
