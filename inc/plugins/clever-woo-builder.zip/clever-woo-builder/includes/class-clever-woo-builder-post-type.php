<?php
/**
 * Clever Woo Builder post type template
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

if (!class_exists('Clever_Woo_Builder_Post_Type')) {

    /**
     * Define Clever_Woo_Builder_Post_Type class
     */
    class Clever_Woo_Builder_Post_Type
    {

        /**
         * A reference to an instance of this class.
         *
         * @since 1.0.0
         * @var   object
         */
        private static $instance = null;

        protected $post_type = 'clever-woo-builder';
        protected $meta_key = 'clever-woo-builder-item';

        /**
         * Constructor for the class
         */
        public function init()
        {

            $this->register_post_type();
            $this->init_meta();

            if (is_admin()) {
                add_action('admin_menu', array($this, 'add_templates_page'), 22);
            }

            add_action('manage_' . $this->post_type . '_posts_columns', array($this, 'admin_columns_headers'));
            add_action('manage_' . $this->post_type . '_posts_custom_column', array($this, 'admin_columns_content'), 10, 2);

            add_filter('option_elementor_cpt_support', array($this, 'set_option_support'));
            add_filter('default_option_elementor_cpt_support', array($this, 'set_option_support'));

            add_filter('body_class', array($this, 'set_body_class'));
            add_filter('post_class', array($this, 'set_post_class'));

            add_filter('the_content', array($this, 'add_product_wrapper'), 1000000);

            add_action('init', array($this, 'fix_documents_types'), 99);

            add_action('admin_enqueue_scripts', array($this, 'enqueue_templates_popup'));
            add_action('admin_action_clever_woo_new_template', array($this, 'create_template'));

            add_filter('post_row_actions', array($this, 'remove_view_action'), 10, 2);

            add_filter('get_sample_permalink_html', array($this, 'remove_permalink_action'), 10, 5);

        }

        /**
         * Remove permalink html
         *
         * @param $return
         * @param $post_id
         * @param $new_title
         * @param $new_slug
         * @param $post
         *
         * @return string
         */
        public function remove_permalink_action($return, $post_id, $new_title, $new_slug, $post)
        {

            if ($this->post_type === $post->post_type) {
                return '';
            }

            return $return;
        }

        /**
         * Actions posts
         *
         * @param  [type] $actions [description]
         * @param  [type] $post    [description]
         * @return [type]          [description]
         */
        public function remove_view_action($actions, $post)
        {

            if ($this->post_type === $post->post_type) {
                unset($actions['view']);
            }

            return $actions;

        }

        /**
         * Create new template
         *
         * @return [type] [description]
         */
        public function create_template()
        {

            if (!current_user_can('edit_posts')) {
                wp_die(
                    esc_html__('You don\'t have permissions to do this', 'clever-woo-builder'),
                    esc_html__('Error', 'clever-woo-builder')
                );
            }

            $doc_types = clever_woo_builder()->documents->get_document_types();
            $default_type = $doc_types['single']['slug'];
            $type = isset($_REQUEST['template_type']) ? $_REQUEST['template_type'] : $default_type;
            $name = isset($_REQUEST['template_name']) ? $_REQUEST['template_name'] : '';
            $documents = Elementor\Plugin::instance()->documents;
            $doc_type = $documents->get_document_type($type);
            $template_data = '';
            $templates = array();


            if ($type === $doc_types['single']['slug']) {
                $template = isset($_REQUEST['template_single']) ? $_REQUEST['template_single'] : '';
                $templates = $this->predesigned_single_templates();
            } else if ($type === $doc_types['archive']['slug']) {
                $template = isset($_REQUEST['template_archive']) ? $_REQUEST['template_archive'] : '';
                $templates = $this->predesigned_archive_templates();
            } else if ($type === $doc_types['category']['slug']) {
                $template = isset($_REQUEST['template_category']) ? $_REQUEST['template_category'] : '';
                $templates = $this->predesigned_category_templates();
            } else if ($type === $doc_types['shop']['slug']) {
                $template = isset($_REQUEST['template_shop']) ? $_REQUEST['template_shop'] : '';
                $templates = $this->predesigned_shop_templates();
            }

            if ($template) {
                if (!isset($templates[$template])) {
                    wp_die(
                        esc_html__('This template not registered', 'clever-woo-builder'),
                        esc_html__('Error', 'clever-woo-builder')
                    );
                }

                $data = $templates[$template];
                $content = $data['content'];

                ob_start();
                include $content;
                $template_data = ob_get_clean();

            }

            $meta_input = array(
                '_elementor_edit_mode' => 'builder',
                $doc_type::TYPE_META_KEY => esc_attr($type),
            );

            if (!empty($template_data)) {
                $meta_input['_elementor_data'] = wp_slash($template_data);
            }

            $post_data = array(
                'post_type' => $this->slug(),
                'meta_input' => $meta_input,
            );

            if ($name) {
                $post_data['post_title'] = esc_attr($name);
            }

            $template_id = wp_insert_post($post_data);

            if (!$template_id) {
                wp_die(
                    esc_html__('Can\'t create template. Please try again', 'clever-woo-builder'),
                    esc_html__('Error', 'clever-woo-builder')
                );
            }

            if (version_compare(ELEMENTOR_VERSION, '2.6.0', '<')) {
                $redirect = Elementor\Utils::get_edit_link($template_id);
            } else {
                $redirect = Elementor\Plugin::$instance->documents->get($template_id)->get_edit_url();
            }

            wp_redirect($redirect);
            die();

        }

        /**
         * Enqueue templates popup assets
         *
         * @return [type] [description]
         */
        public function enqueue_templates_popup($hook)
        {

            if ('edit.php' !== $hook) {
                return;
            }

            if (!isset($_GET['post_type']) || $this->slug() !== $_GET['post_type']) {
                return;
            }

            wp_enqueue_style(
                'clever-woo-builder-template-popup',
                clever_woo_builder()->plugin_url('assets/css/template-popup.css')
            );

            wp_enqueue_script(
                'clever-woo-builder-template-popup',
                clever_woo_builder()->plugin_url('assets/js/template-popup.js'),
                array('jquery'),
                clever_woo_builder()->get_version(),
                true
            );

            wp_localize_script('clever-woo-builder-template-popup', 'CleverwooPopupSettings', array(
                'button' => '<a href="#" class="page-title-action clever-woo-new-template">' . __('Create from predesigned template', 'clever-woo-builder') . '</a>',
            ));

            add_action('admin_footer', array($this, 'template_popup'));

        }

        /**
         * Returns predesigned templates for single product
         *
         * @return array
         */
        public function predesigned_single_templates()
        {

            $base_url = clever_woo_builder()->plugin_url('includes/templates/single/');
            $base_dir = clever_woo_builder()->plugin_path('includes/templates/single/');

            return apply_filters('clever-woo-builder/predesigned-single-templates', array(
                'layout-1' => array(
                    'content' => $base_dir . 'layout-1/template.json',
                    'thumb' => $base_url . 'layout-1/thumbnail.png',
                ),
                'layout-2' => array(
                    'content' => $base_dir . 'layout-2/template.json',
                    'thumb' => $base_url . 'layout-2/thumbnail.png',
                ),
                'layout-3' => array(
                    'content' => $base_dir . 'layout-3/template.json',
                    'thumb' => $base_url . 'layout-3/thumbnail.png',
                ),
                'layout-4' => array(
                    'content' => $base_dir . 'layout-4/template.json',
                    'thumb' => $base_url . 'layout-4/thumbnail.png',
                ),
                'layout-5' => array(
                    'content' => $base_dir . 'layout-5/template.json',
                    'thumb' => $base_url . 'layout-5/thumbnail.png',
                ),
                'layout-6' => array(
                    'content' => $base_dir . 'layout-6/template.json',
                    'thumb' => $base_url . 'layout-6/thumbnail.png',
                ),
                'layout-7' => array(
                    'content' => $base_dir . 'layout-7/template.json',
                    'thumb' => $base_url . 'layout-7/thumbnail.png',
                ), 'layout-8' => array(
                    'content' => $base_dir . 'layout-8/template.json',
                    'thumb' => $base_url . 'layout-8/thumbnail.png',
                ), 'layout-9' => array(
                    'content' => $base_dir . 'layout-9/template.json',
                    'thumb' => $base_url . 'layout-9/thumbnail.png',
                ), 'layout-10' => array(
                    'content' => $base_dir . 'layout-10/template.json',
                    'thumb' => $base_url . 'layout-10/thumbnail.png',
                ), 'layout-11' => array(
                    'content' => $base_dir . 'layout-11/template.json',
                    'thumb' => $base_url . 'layout-11/thumbnail.png',
                ), 'layout-12' => array(
                    'content' => $base_dir . 'layout-12/template.json',
                    'thumb' => $base_url . 'layout-12/thumbnail.png',
                ), 'layout-13' => array(
                    'content' => $base_dir . 'layout-13/template.json',
                    'thumb' => $base_url . 'layout-13/thumbnail.png',
                ), 'layout-14' => array(
                    'content' => $base_dir . 'layout-14/template.json',
                    'thumb' => $base_url . 'layout-14/thumbnail.png',
                ),
            ));
        }

        /**
         * Returns predesigned templates for archive product
         *
         * @return array
         */
        public function predesigned_archive_templates()
        {

            $base_url = clever_woo_builder()->plugin_url('includes/templates/archive/');
            $base_dir = clever_woo_builder()->plugin_path('includes/templates/archive/');

            return apply_filters('clever-woo-builder/predesigned-archive-templates', array(
                'layout-1' => array(
                    'content' => $base_dir . 'layout-1/template.json',
                    'thumb' => $base_url . 'layout-1/thumbnail.png',
                ),
                'layout-2' => array(
                    'content' => $base_dir . 'layout-2/template.json',
                    'thumb' => $base_url . 'layout-2/thumbnail.png',
                ),
                'layout-3' => array(
                    'content' => $base_dir . 'layout-3/template.json',
                    'thumb' => $base_url . 'layout-3/thumbnail.png',
                ),
                'layout-4' => array(
                    'content' => $base_dir . 'layout-4/template.json',
                    'thumb' => $base_url . 'layout-4/thumbnail.png',
                ),
            ));
        }

        /**
         * Returns predesigned templates for category product
         *
         * @return array
         */
        public function predesigned_category_templates()
        {

            $base_url = clever_woo_builder()->plugin_url('includes/templates/category/');
            $base_dir = clever_woo_builder()->plugin_path('includes/templates/category/');

            return apply_filters('clever-woo-builder/predesigned-category-templates', array(
                'layout-1' => array(
                    'content' => $base_dir . 'layout-1/template.json',
                    'thumb' => $base_url . 'layout-1/thumbnail.png',
                ),
                'layout-2' => array(
                    'content' => $base_dir . 'layout-2/template.json',
                    'thumb' => $base_url . 'layout-2/thumbnail.png',
                ),
                'layout-3' => array(
                    'content' => $base_dir . 'layout-3/template.json',
                    'thumb' => $base_url . 'layout-3/thumbnail.png',
                ),
                'layout-4' => array(
                    'content' => $base_dir . 'layout-4/template.json',
                    'thumb' => $base_url . 'layout-4/thumbnail.png',
                ),
            ));
        }

        /**
         * Returns predesigned templates for shop product
         *
         * @return array
         */
        public function predesigned_shop_templates()
        {

            $base_url = clever_woo_builder()->plugin_url('includes/templates/shop/');
            $base_dir = clever_woo_builder()->plugin_path('includes/templates/shop/');

            return apply_filters('clever-woo-builder/predesigned-shop-templates', array(
                'layout-1' => array(
                    'content' => $base_dir . 'layout-1/template.json',
                    'thumb' => $base_url . 'layout-1/thumbnail.png',
                ),
                'layout-2' => array(
                    'content' => $base_dir . 'layout-2/template.json',
                    'thumb' => $base_url . 'layout-2/thumbnail.png',
                ),
                'layout-3' => array(
                    'content' => $base_dir . 'layout-3/template.json',
                    'thumb' => $base_url . 'layout-3/thumbnail.png',
                ),
                'layout-4' => array(
                    'content' => $base_dir . 'layout-4/template.json',
                    'thumb' => $base_url . 'layout-4/thumbnail.png',
                ),
            ));
        }

        /**
         * Template popup content
         *
         * @return [type] [description]
         */
        public function template_popup()
        {

            $action = add_query_arg(
                array(
                    'action' => 'clever_woo_new_template',
                ),
                esc_url(admin_url('admin.php'))
            );

            include clever_woo_builder()->get_template('template-popup.php');

        }

        /**
         * Maybe fix document types for Clever Woo templates
         *
         * @return void
         */
        public function fix_documents_types()
        {

            if (!isset($_GET['fix_clever_woo_templates'])) {
                return;
            }

            $args = array(
                'post_type' => $this->slug(),
                'post_status' => array('publish', 'pending', 'draft', 'future'),
                'posts_per_page' => -1,
            );

            $wp_query = new WP_Query($args);
            $documents = Elementor\Plugin::instance()->documents;
            $doc_type = $documents->get_document_type($this->slug());

            if (!$wp_query->have_posts()) {
                return false;
            }

            foreach ($wp_query->posts as $post) {
                update_post_meta($post->ID, $doc_type::TYPE_META_KEY, $this->slug());
            }

        }

        /**
         * Add .product wrapper to content
         *
         * @param string $content
         */
        public function add_product_wrapper($content)
        {

            if (is_singular($this->slug()) && isset($_GET['elementor-preview'])) {
                $content = sprintf('<div class="product">%s</div>', $content);
            }

            return $content;
        }

        /**
         * Add 'single-product' class to body on template pages
         *
         * @param array $classes Default classes list.
         * @return array
         */
        public function set_body_class($classes)
        {

            if (is_singular($this->slug())) {
                $classes[] = 'single-product woocommerce';
            }

            $custom_cart_page = clever_woo_builder_shop_settings()->get('custom_cart_page');
            $custom_checkout_page = clever_woo_builder_shop_settings()->get('custom_checkout_page');
            $custom_myaccount_page = clever_woo_builder_shop_settings()->get('custom_myaccount_page');

            if (($custom_cart_page === 'yes' && is_cart()) || ($custom_checkout_page === 'yes' && is_checkout()) || ($custom_myaccount_page === 'yes' && is_account_page())) {
                $classes[] = 'clever-woo-builder-elementor';
            }

            return $classes;
        }

        /**
         * Add 'product' class to post on template pages
         *
         * @param array $classes Default classes list.
         * @return array
         */
        public function set_post_class($classes)
        {

            if (is_singular($this->slug())) {
                $classes[] = 'product';
            }

            return $classes;
        }

        /**
         * Clever Woo Builder page
         */
        public function add_templates_page()
        {

            add_submenu_page(
                'clever-dashboard',
                esc_html__('Clever Woo Templates', 'clever-woo-builder'),
                esc_html__('Clever Woo Templates', 'clever-woo-builder'),
                'edit_pages',
                'edit.php?post_type=' . $this->slug()
            );

        }

        /**
         * Set required post columns
         *
         * @param array $posts_columns
         * @return array
         */
        public function admin_columns_headers($posts_columns)
        {

            $offset = 2;

            $posts_columns = array_slice($posts_columns, 0, $offset, true) + array('type' => esc_html__('Type', 'clever-woo-builder'),) + array_slice($posts_columns, $offset, null, true);

            $offset = 3;

            $posts_columns = array_slice($posts_columns, 0, $offset, true) + array('condition' => esc_html__('Active Condition', 'clever-woo-builder'),) + array_slice($posts_columns, $offset, null, true);

            return $posts_columns;

        }

        /**
         * Set required post columns content
         *
         * @param string $column_name
         * @param number $post_id
         *
         * @return mixed
         */
        public function admin_columns_content($column_name, $post_id)
        {

            $post_id = absint($post_id);

            if (!$post_id || !get_post($post_id)) {
                return false;
            }

            $template_types = clever_woo_builder()->documents->get_document_types();
            $documents = Elementor\Plugin::instance()->documents;
            $doc_type = $documents->get_document_type($this->slug());
            $doc_type_slug = get_post_meta($post_id, $doc_type::TYPE_META_KEY, true);

            switch ($column_name) {

                case 'type':

                    $col_type_content = '';

                    foreach ($template_types as $template => $template_type) {

                        if (!isset($template)) {
                            continue;
                        }

                        if ($doc_type_slug === $template_type['slug']) {
                            $col_type_content = $template_type['name'];
                        }

                    }

                    printf('<div class="clever-woo-builder-template-type">%s</div>', $col_type_content);

                    break;

                case 'condition';

                    $col_condition_content = '';

                    foreach ($template_types as $template => $template_type) {

                        if (!isset($template)) {
                            continue;
                        }

                        if ('clever-woo-builder' === $doc_type_slug) {
                            $single_page_id = absint(clever_woo_builder_integration_woocommerce()->get_custom_single_template());

                            if ($single_page_id === $post_id) {
                                $col_condition_content = esc_html__('Single Product', 'clever-woo-builder');
                            }

                        }

                        if ('clever-woo-builder-archive' === $doc_type_slug) {
                            $archive_template_id = absint(clever_woo_builder_shop_settings()->get('archive_template'));
                            $search_template_id = absint(clever_woo_builder_shop_settings()->get('search_template'));
                            $shortcode_template_id = absint(clever_woo_builder_shop_settings()->get('shortcode_template'));
                            $related_template_id = absint(clever_woo_builder_shop_settings()->get('related_template'));
                            $cross_sell_template_id = absint(clever_woo_builder_shop_settings()->get('cross_sells_template'));

                            if ($archive_template_id === $post_id) {
                                $col_condition_content = esc_html__('Archive Template', 'clever-woo-builder');
                            } elseif ($search_template_id === $post_id) {
                                $col_condition_content = esc_html__('Search Template', 'clever-woo-builder');
                            } elseif ($shortcode_template_id === $post_id) {
                                $col_condition_content = esc_html__('Shortcode Template', 'clever-woo-builder');
                            } elseif ($related_template_id === $post_id) {
                                $col_condition_content = esc_html__('Related Template', 'clever-woo-builder');
                            } elseif ($cross_sell_template_id === $post_id) {
                                $col_condition_content = esc_html__('Cross Sell Template', 'clever-woo-builder');
                            }

                        }

                        if ('clever-woo-builder-category' === $doc_type_slug) {
                            $category_page_id = absint(clever_woo_builder_integration_woocommerce()->get_custom_archive_category_template());

                            if ($category_page_id === $post_id) {
                                $col_condition_content = esc_html__('Archive Category', 'clever-woo-builder');
                            }

                        }

                        if ('clever-woo-builder-shop' === $doc_type_slug) {
                            $shop_page_id = absint(clever_woo_builder_integration_woocommerce()->get_custom_shop_template());

                            if ($shop_page_id === $post_id) {
                                $col_condition_content = esc_html__('Shop Page', 'clever-woo-builder');
                            }

                        }

                        if ('clever-woo-builder-cart' === $doc_type_slug) {
                            $cart_page_id = absint(clever_woo_builder_integration_woocommerce()->get_custom_cart_template());
                            $cart_empty_page_id = absint(clever_woo_builder_integration_woocommerce()->get_custom_empty_cart_template());

                            if ($cart_page_id === $post_id) {
                                $col_condition_content = esc_html__('Cart Page', 'clever-woo-builder');
                            } elseif ($cart_empty_page_id === $post_id) {
                                $col_condition_content = esc_html__('Empty Cart Page', 'clever-woo-builder');
                            }

                        }

                        if ('clever-woo-builder-checkout' === $doc_type_slug) {
                            $checkout_page_id = absint(clever_woo_builder_integration_woocommerce()->get_custom_checkout_template());
                            $checkout_top_content_id = absint(clever_woo_builder_integration_woocommerce()->get_custom_top_checkout_template());

                            if ($checkout_page_id === $post_id) {
                                $col_condition_content = esc_html__('Checkout Page', 'clever-woo-builder');
                            } elseif ($checkout_top_content_id === $post_id) {
                                $col_condition_content = esc_html__('Checkout Top Content', 'clever-woo-builder');
                            }

                        }

                        if ('clever-woo-builder-thankyou' === $doc_type_slug) {
                            $thankyou_page_id = absint(clever_woo_builder_integration_woocommerce()->get_custom_thankyou_template());

                            if ($thankyou_page_id === $post_id) {
                                $col_condition_content = esc_html__('Thank You Page', 'clever-woo-builder');
                            }

                        }

                        if ('clever-woo-builder-myaccount' === $doc_type_slug) {
                            $myaccount_page_id = absint(clever_woo_builder_integration_woocommerce()->get_custom_myaccount_template());
                            $myaccount_login_page_id = absint(clever_woo_builder_integration_woocommerce()->get_custom_form_login_template());

                            if ($myaccount_page_id === $post_id) {
                                $col_condition_content = esc_html__('My Account Page', 'clever-woo-builder');
                            } elseif ($myaccount_login_page_id === $post_id) {
                                $col_condition_content = esc_html__('My Account Login Page', 'clever-woo-builder');
                            }

                        }

                    }

                    printf('<div class="clever-woo-builder-active-conditions">%1$s</div>', $col_condition_content);

            }

        }

        /**
         * Returns post type slug
         *
         * @return string
         */
        public function slug()
        {
            return $this->post_type;
        }

        /**
         * Returns Clever Woo Builder meta key
         *
         * @return string
         */
        public function meta_key()
        {
            return $this->meta_key;
        }

        /**
         * Add elementor support for clever woo builder items.
         */
        public function set_option_support($value)
        {

            if (empty($value)) {
                $value = array();
            }

            return array_merge($value, array($this->slug()));
        }

        /**
         * Register post type
         *
         * @return void
         */
        public function register_post_type()
        {

            $labels = array(
                'name' => esc_html__('Clever Woo Templates', 'clever-woo-builder'),
                'singular_name' => esc_html__('Clever Woo Template', 'clever-woo-builder'),
                'add_new' => esc_html__('Add New Template', 'clever-woo-builder'),
                'add_new_item' => esc_html__('Add New Template', 'clever-woo-builder'),
                'edit_item' => esc_html__('Edit Template', 'clever-woo-builder'),
                'menu_name' => esc_html__('Clever Woo Templates', 'clever-woo-builder'),
            );

            $args = array(
                'labels' => $labels,
                'hierarchical' => false,
                'description' => 'description',
                'taxonomies' => array(),
                'public' => true,
                'show_ui' => true,
                'show_in_menu' => false,
                'show_in_admin_bar' => true,
                'menu_position' => null,
                'menu_icon' => null,
                'show_in_nav_menus' => false,
                'publicly_queryable' => true,
                'exclude_from_search' => true,
                'has_archive' => false,
                'query_var' => true,
                'can_export' => true,
                'rewrite' => false,
                'capability_type' => 'post',
                'supports' => array('title'),
            );

            register_post_type($this->slug(), $args);

        }

        /**
         * Initialize template metabox
         *
         * @return void
         */
        public function init_meta()
        {

            new Cherry_X_Post_Meta(array(
                'id' => 'template-settings',
                'title' => esc_html__('Template Settings', 'clever-woo-builder'),
                'page' => array($this->slug()),
                'context' => 'normal',
                'priority' => 'high',
                'callback_args' => false,
                'builder_cb' => array($this, 'get_builder'),
                'fields' => array(
                    '_sample_product' => array(
                        'type' => 'select',
                        'element' => 'control',
                        'options' => false,
                        'options_callback' => array($this, 'get_products'),
                        'label' => esc_html__('Sample Product for Editing (if not selected - will be used latest added)', 'clever-woo-builder'),
                        'sanitize_callback' => 'esc_attr',
                    ),
                ),
            ));
        }

        /**
         * Return products list
         *
         * @return void
         */
        public function get_products()
        {

            $products = get_posts(array(
                'post_type' => 'product',
                'post_status' => array('publish', 'pending', 'draft', 'future'),
                'posts_per_page' => 100,
            ));

            $default = array(
                '' => __('Select Product...', 'clever-woo-builder'),
            );

            if (empty($products)) {
                return $default;
            }

            $products = wp_list_pluck($products, 'post_title', 'ID');

            return $default + $products;
        }

        /**
         * Return UI builder instance
         *
         * @return [type] [description]
         */
        public function get_builder()
        {

            $builder_data = clever_woo_builder()->module_loader->get_included_module_data('cherry-x-interface-builder.php');

            return new CX_Interface_Builder(
                array(
                    'path' => $builder_data['path'],
                    'url' => $builder_data['url'],
                )
            );
        }

        /**
         * Return Templates list from options
         *
         * @return void
         */
        public function get_templates_list($type = 'all')
        {

            $args = array(
                'posts_per_page' => -1,
                'post_status' => 'publish',
                'post_type' => $this->slug(),
            );

            if ('all' !== $type) {

                $doc_types = clever_woo_builder()->documents->get_document_types();
                $default_type = $doc_types['single']['slug'];
                $type = isset($doc_types[$type]) ? $doc_types[$type]['slug'] : $default_type;
                $documents = Elementor\Plugin::instance()->documents;
                $doc_type = $documents->get_document_type($type);

                $args['meta_query'] = array(
                    array(
                        'key' => $doc_type::TYPE_META_KEY,
                        'value' => $type,
                    ),
                );
            }

            $templates = get_posts($args);

            return $templates;

        }

        /**
         * Returns templates list for select options
         *
         * @return [type] [description]
         */
        public function get_templates_list_for_options($type = 'all')
        {

            $templates = $this->get_templates_list($type);

            $default = array(
                '' => esc_html__('Select Template...', 'clever-woo-builder'),
            );

            if (empty($templates)) {
                return $default;
            }

            return $default + wp_list_pluck($templates, 'post_title', 'ID');

        }

        /**
         * Returns the instance.
         *
         * @return object
         * @since  1.0.0
         */
        public static function get_instance()
        {

            // If the single instance hasn't been set, set it now.
            if (null == self::$instance) {
                self::$instance = new self;
            }
            return self::$instance;
        }
    }

}

/**
 * Returns instance of Clever_Woo_Builder_Post_Type
 *
 * @return object
 */
function clever_woo_builder_post_type()
{
    return Clever_Woo_Builder_Post_Type::get_instance();
}
