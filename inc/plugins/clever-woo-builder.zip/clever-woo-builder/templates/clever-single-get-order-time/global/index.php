<?php
/**
 * Product title template
 */
$settings      = $this->get_settings();
$order_day = $settings['single_get_order_time_days'];
$getOrderDate = date_i18n(get_option('date_format'), strtotime('+'.$order_day." days"));
?>
<div class="cwb-extend-notice-item cwb-get-order-notice">
    <i class="<?php echo esc_attr($settings['single_get_order_time_icon']); ?>"></i>
    <div class="order-label">
	    <label class="order-next"><?php echo esc_html($settings['single_get_order_time_order_next']); ?></label>
	    <span class="end-of-day" data-timezone="<?php echo get_option('gmt_offset');  ?>" data-hours="hours" data-minutes ="minutes">
	    </span>
	    <label class="order-end"><?php echo esc_html($settings['single_get_order_time_order_end']); ?></label>
	    <span class="get-order-date">
	        <?php echo esc_html($getOrderDate);?>
	    </span>
    </div>
</div>
