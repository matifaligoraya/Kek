<?php
/**
 * Loop item price
 */

$price = clever_woo_builder_template_functions()->get_product_price();

if ( 'yes' !== $this->get_attr( 'show_price' ) || '' === $price ) {
	return;
}
?>

<div class="clever-woo-product-price"><?php echo wp_kses_post($price); ?></div>