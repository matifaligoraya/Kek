<?php
/**
 * Sharing template
 */
$settings      = $this->get_settings();

if($settings['single_share_option'] == 'default' && $settings['single_share_default_socials']){ 
    cwb_woo_share($settings['single_share_default_label'], $settings['single_share_default_socials']);
}
else{
	woocommerce_template_single_sharing();
}

