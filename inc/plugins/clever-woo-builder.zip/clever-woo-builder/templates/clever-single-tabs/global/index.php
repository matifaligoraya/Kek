<?php
/**
 * Tabs template
 */
$settings      = $this->get_settings();
$remove_tabs  = $settings['single_tabs_remove'];

if($settings['single_tabs_options'] == 'custom'){
	if(is_array($remove_tabs)){
		foreach ( $remove_tabs as $tab) {
			if($tab == 'description'){
				add_filter( 'woocommerce_product_tabs', 'cwb_remove_product_tabs_description', 98 );
				function cwb_remove_product_tabs_description( $tabs ) {
				    unset( $tabs['description'] );     
				    return $tabs;
				}
			}elseif ($tab == 'reviews') {
				add_filter( 'woocommerce_product_tabs', 'cwb_remove_product_tabs_reviews', 98 );
				function cwb_remove_product_tabs_reviews( $tabs ) {
				    unset( $tabs['reviews'] );     
				    return $tabs;
				}
			}elseif($tab == 'additional_information'){
				add_filter( 'woocommerce_product_tabs', 'cwb_remove_product_tabs_additional_information', 98 );
				function cwb_remove_product_tabs_additional_information( $tabs ) {
				    unset( $tabs['additional_information'] );     
				    return $tabs;
				}
			}
		}
	}
}

echo '<div class="clever-single-tabs__wrap">';
	printf( '<div class="clever-single-tabs__loading">%s</div>', __( 'Loading...', 'clever-woo-builder' ) );

//if( $settings['single_tabs_layout'] == 'tab'  &&  !wp_is_mobile()){
if( $settings['single_tabs_layout'] == 'tab' ){
	woocommerce_output_product_data_tabs();
}else{
	custom_woocommerce_output_product_data_tabs($settings['single_tabs_layout'],$settings['single_tabs_off_canvas_position']);
}
echo '</div>';

