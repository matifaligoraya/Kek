<?php
/**
 * Loop item categories
 */

$categories = clever_woo_builder_template_functions()->get_product_categories_list();

if ( 'yes' !== $this->get_attr( 'show_cat' ) ) {
	return;
}
?>

<div class="clever-woo-product-categories"><?php echo wp_kses_post($categories); ?></div>