<?php
/**
 * Product title template
 */
$settings = $this->get_settings();
?>
<div class="cwb-count-visitor">
    <i class="<?php echo esc_attr($settings['single_visitor_product_icon']); ?>"></i>
    <div class="cwb-count">
    	<label class="real-time"><?php echo esc_html($settings['single_visitor_product_real_time']); ?></label>
	    <?php
	    echo countVisitors($settings['single_visitor_product_min'], $settings['single_visitor_product_max']);
	    ?>
	    <label class="visitor-right-now"><?php echo esc_html($settings['single_visitor_product_right_now']); ?></label>
	</div>
</div>
