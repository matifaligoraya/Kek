<?php
/**
 * Products loop template with switcher enable
 */

$settings                        = $this->get_settings();
$template_archive                = clever_woo_builder_shop_settings()->get( 'archive_template' );
$default_template                = $template_archive !== 'default' ? $template_archive : '';
$switcher_data                   = array(
	'main'      => ! empty( $settings['main_layout'] ) ? $settings['main_layout'] : $default_template,
	'secondary' => ! empty( $settings['secondary_layout'] ) ? $settings['secondary_layout'] : $default_template,
);
$main_layout_switcher_label      = ! empty( $settings['main_layout_switcher_label'] ) ? sprintf( '<span class="clever-woo-switcher-btn__label">%s</span>', $settings['main_layout_switcher_label'] ) : '';
$secondary_layout_switcher_label = ! empty( $settings['secondary_layout_switcher_label'] ) ? sprintf( '<span class="clever-woo-switcher-btn__label">%s</span>', $settings['secondary_layout_switcher_label'] ) : '';
$active_main_layout              = '';
$active_secondary_layout         = '';
$layout                          = ! empty( $_COOKIE['clever_woo_builder_layout'] ) ? absint( $_COOKIE['clever_woo_builder_layout'] ) : false;

if ( $layout && ( absint( $switcher_data['main'] ) !== absint( $switcher_data['secondary'] ) ) ) {
	$active_main_layout      = $layout === absint( $switcher_data['main'] ) ? 'active' : '';
	$active_secondary_layout = $layout === absint( $switcher_data['secondary'] ) ? 'active' : '';
} else {
	$active_main_layout = 'active';
}
$allow_html=array(
        'span'=>array('class'=>array())
)
?>

<div class="clever-woo-builder-products-loop">
	<div class="clever-woo-switcher-controls-wrapper">
		<a type="button" class="button clever-woo-switcher-btn clever-woo-switcher-btn-main <?php echo esc_attr($active_main_layout); ?>">
			<?php
				$this->__render_icon( 'main_layout_switcher_icon', '%s', 'clever-woo-switcher-btn__icon clever-woo-builder-icon', true );
				echo wp_kses($main_layout_switcher_label,$allow_html);
			?>
		</a>
		<a type="button" class="button clever-woo-switcher-btn clever-woo-switcher-btn-secondary <?php echo esc_attr($active_secondary_layout); ?>">
			<?php
				$this->__render_icon( 'secondary_layout_switcher_icon', '%s', 'clever-woo-switcher-btn__icon clever-woo-builder-icon', true );
            echo wp_kses($secondary_layout_switcher_label,$allow_html);
			?>
		</a>
	</div>

	<div class="clever-woo-products-wrapper" data-layout-switcher='<?php echo esc_attr( json_encode( $switcher_data ) ); ?>'>
		<?php $this->products_loop(); ?>
	</div>
</div>
