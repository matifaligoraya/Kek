<?php
/**
 * Silence is golden
 *
 * @package  clever-woo-builder
 * @category Core
 * @author   CleverSoft
 * @license  GPL-2.0+
 */
