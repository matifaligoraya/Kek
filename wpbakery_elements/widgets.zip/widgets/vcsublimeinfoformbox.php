<?php

if (!class_exists('VCSublimeInfoFormBox')) {
    class VCSublimeInfoFormBox extends WPBakeryShortCode {
        function __construct() {
            add_action('init', array($this, 'vc_sublime_info_form_box_mapping'), 42);
            add_shortcode('vc_sublime_info_form_box', array($this, 'vc_sublime_info_form_box_html'));
        }

        public function vc_sublime_info_form_box_mapping() {
            if (!defined('WPB_VC_VERSION')) {
                return;
            }

            vc_map(array(
                'name' => __('Info Form Box', 'text-domain'),
                'base' => 'vc_sublime_info_form_box',
                'description' => __('Displays a custom banner info section.', 'text-domain'),
                'category' => CUSTOM_ELEMENTS_CATEGORY,
                'params' => array(
                    array(
                        'type' => 'textfield',
                        'heading' => __('Heading', 'text-domain'),
                        'param_name' => 'heading',
                        'description' => __('Subscribe to our Mailing List to Get Free Analyses', 'text-domain'),
                    ),
                    array(
                        'type' => 'textarea_html',
                        'heading' => __('Form HTML', 'text-domain'),
                        'param_name' => 'content',
                        'description' => __('Form HTML goes here.', 'text-domain'),
                    ),                    
                )
            ));
        }

        public function vc_sublime_info_form_box_html($atts, $content = null) {
            $atts = shortcode_atts(array(
                'heading' => '',              
            ), $atts);            

            ob_start(); // Start output buffer capture
            ?>
            <div class="sidebar-subscribe_box">
                <div class="sidebar-subscribe_box-inner">
                    <h4>Subscribe to our Mailing List to Get Free Analyses</h4>
                    <?php echo my_custom_kses_allowed_html($content); ?>
                </div>
            </div>
            <?php
            return ob_get_clean(); // Return output buffer contents
        }
    }

    function my_custom_kses_allowed_html($content) {
        $custom_tags = array(
            'form' => array(
                'action' => true,
                'method' => true,
                'class' => true,
                'id' => true,
                'style' => true
            ),
            'div' => array(
                'class' => true,
                'style' => true,
            ),
            'input' => array(
                'class' => true,
                'type' => true,
                'placeholder' => true,
                'name' => true,
                'value' => true,
                'style' => true,
            ),
            'button' => array(
                'class' => true,
                'type' => true,
                'name' => true,
                'style' => true
            ),
            'span' => array(
                'style' => true,
                'class' => true,
            ),
            // Include additional tags as needed
        );
    
        return wp_kses($content, $custom_tags);
    }

    
    new VCSublimeInfoFormBox();
}
?>
