<?php
if (!class_exists('StaticBannerWithTrialOption')) {

    class StaticBannerWithTrialOption extends WPBakeryShortCode {

        function __construct() {
            add_action('init', array($this, 'vc_static_banner_with_trial_option_mapping'), 999);
            add_shortcode('vc_static_banner_with_trial_option', array($this, 'vc_static_banner_with_trial_option_html'));
        }

        public function vc_static_banner_with_trial_option_mapping() {
            if (!defined('WPB_VC_VERSION')) {
                return;
            }

            vc_map(array(
                'name' => __('Static Banner with Trial Option', 'text-domain'),
                'base' => 'vc_static_banner_with_trial_option',
                'description' => __('Display a static banner with a trial option.', 'text-domain'),
                'category' => CUSTOM_ELEMENTS_CATEGORY,
                'params' => array(
                    array(
                        'type' => 'attach_image',
                        'heading' => __('Banner Image', 'text-domain'),
                        'param_name' => 'banner_image',
                        'description' => __('Select the background image for the banner.', 'text-domain'),
                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => __('Main Heading', 'text-domain'),
                        'param_name' => 'main_heading',
                        'description' => __('Enter the main heading for the banner.', 'text-domain'),
                    ),
                    array(
                        'type' => 'param_group',
                        'heading' => __('List Items', 'text-domain'),
                        'param_name' => 'list_items',
                        'params' => array(
                            array(
                                'type' => 'textfield',
                                'heading' => __('List Item', 'text-domain'),
                                'param_name' => 'list_item',
                                'description' => __('Enter a list item.', 'text-domain'),
                            ),
                        ),
                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => __('Sub Heading', 'text-domain'),
                        'param_name' => 'sub_heading',
                        'description' => __('Enter the sub heading for the banner.', 'text-domain'),
                    ),
                    array(
                        'type' => 'textarea',
                        'heading' => __('Sub Text', 'text-domain'),
                        'param_name' => 'sub_text',
                        'description' => __('Enter the sub text for the banner.', 'text-domain'),
                    ),
                    array(
                        'type' => 'vc_link',
                        'heading' => __('Button Link', 'text-domain'),
                        'param_name' => 'button_link',
                        'description' => __('Enter the URL for the button link.', 'text-domain'),
                    ),
                ),
            ));
        }

        public function vc_static_banner_with_trial_option_html($atts) {
            $atts = shortcode_atts(array(
                'banner_image' => '',
                'main_heading' => '',
                'list_items' => '',
                'sub_heading' => '',
                'sub_text' => '',
                'button_link' => '',
            ), $atts);

            $banner_image = wp_get_attachment_url($atts['banner_image']);
            $main_heading = !empty($atts['main_heading']) ? $atts['main_heading'] : '';
            $list_items = vc_param_group_parse_atts($atts['list_items']);
            $sub_heading = !empty($atts['sub_heading']) ? $atts['sub_heading'] : '';
            $sub_text = !empty($atts['sub_text']) ? $atts['sub_text'] : '';
            $button_link = vc_build_link($atts['button_link']);
            $button_url = !empty($button_link['url']) ? $button_link['url'] : '#';
            $button_title = !empty($button_link['title']) ? $button_link['title'] : 'Start Your 14 Day Trial';

            $list_items_output = '';
            if (!empty($list_items)) {
                $list_items_output .= '<ul>';
                foreach ($list_items as $item) {
                    $list_item = !empty($item['list_item']) ? $item['list_item'] : '';
                    $list_items_output .= '<li>' . esc_html($list_item) . '</li>';
                }
                $list_items_output .= '</ul>';
            }

            $output = <<<HTML
            <article class="banner banner--home static-banner">
                <div class="banner-inner">
                    <div class="banner-image wow fadeInRight" data-wow-duration="1.5s">
                        <div class="banner-image-inner" style="background-image: url({$banner_image})"></div>
                    </div>
                    <div class="banner-text banner-text--pb_lg">
                        <div class="banner-text-top wow fadeInLeft" data-wow-duration="1.5s">
                            <h1>{$main_heading}</h1>
                            {$list_items_output}
                        </div>
                    </div>
                    <div class="banner-start">
                        <div class="container container--big">
                            <div class="row justify-content-center align-items-end">
                                <div class="col-lg-8">
                                    <div class="pb-4 p-lg-0 wow fadeInLeft" data-wow-duration="1.5s">
                                        <h2>{$sub_heading}</h2>
                                        <p>{$sub_text}</p>
                                    </div>
                                </div>
                                <div class="col-sm-6 col-md-5 col-lg-4">
                                    <div class=" wow fadeInRight" data-wow-duration="1.5s">
                                        <a href="{$button_url}" class="btn btn--secondary w-100">{$button_title}</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="shapes">
                        <div class="shapes-base shapes-base--one"></div>
                        <div class="shapes-base shapes-base--two"></div>
                        <div class="decor decor--2">
                            <span class="top_right"></span>
                            <img src="img/circle-stripe-1.png" alt="">
                        </div>
                        <div class="circles d-none d-lg-block">
                            <div class="circles-item circles-item--1"><div></div></div>
                            <div class="circles-item circles-item--2"><div></div></div>
                            <div class="circles-item circles-item--3"><div></div></div>
                            <div class="circles-item circles-item--4"><div></div></div>
                            <div class="circles-item circles-item--5"><div></div></div>
                            <div class="circles-item circles-item--6"><div></div></div>
                            <div class="circles-item circles-item--7"><div></div></div>
                            <div class="circles-item circles-item--8"><div></div></div>
                            <span class="bottom_left red"></span>
                        </div>
                    </div>
                </div>
            </article>
            HTML;

            return $output;
        }
    }

    new StaticBannerWithTrialOption();
}
?>
