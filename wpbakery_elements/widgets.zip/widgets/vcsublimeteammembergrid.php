<?php
if (!class_exists('VCTeamMemberGrid')) {
    class VCTeamMemberGrid extends WPBakeryShortCode {

        function __construct() {
            add_action('init', array($this, 'vc_team_member_grid_mapping'), 39);
            add_shortcode('vc_team_member_grid', array($this, 'render_shortcode'));
        }

        public function vc_team_member_grid_mapping() {
            if (!defined('WPB_VC_VERSION')) {
                return;
            }

            vc_map(array(
                'name' => __('Team Member Grid', 'text-domain'),
                'base' => 'vc_team_member_grid',
                'description' => __('Displays a grid of team members with their names and roles.', 'text-domain'),
                'category' => CUSTOM_ELEMENTS_CATEGORY,                
                'params' => array(
                    array(
                        'type' => 'param_group',
                        'param_name' => 'team_members',
                        'params' => array(
                            array(
                                'type' => 'textfield',
                                'heading' => __('Name', 'text-domain'),
                                'param_name' => 'name',
                                'description' => __('Enter the name of the team member.', 'text-domain'),
                                'edit_field_class' => 'vc_col-sm-6 vc_column',
                            ),
                            array(
                                'type' => 'textfield',
                                'heading' => __('Role', 'text-domain'),
                                'param_name' => 'role',
                                'description' => __('Enter the role of the team member.', 'text-domain'),
                                'edit_field_class' => 'vc_col-sm-6 vc_column',
                            ),
                            array(
                                'type' => 'textfield',
                                'heading' => __('Twitter Link', 'text-domain'),
                                'param_name' => 'twitter_link',
                                'description' => __('Enter the Twitter link of the team member.', 'text-domain'),
                                'edit_field_class' => 'vc_col-sm-6 vc_column',
                            ),
                        ),
                        'group' => __('Team Members', 'text-domain'),
                    ),
                )
            ));
        }

        public function render_shortcode($atts, $content = null) {
            // Extract shortcode parameters
            extract(shortcode_atts(array(
                'team_members' => '',
            ), $atts));

            $team_members = vc_param_group_parse_atts($team_members);

            // Output HTML
            $output = '<div class="about-names">';
            foreach ($team_members as $member) {
                $output .= '<div class="about-names-item">';
                $output .= '<h3>' . esc_html($member['name']) . '</h3>';
                $output .= '<p>' . esc_html($member['role']) . '</p>';
                if (!empty($member['twitter_link'])) {
                    $output .= '<a href="' . esc_url($member['twitter_link']) . '" target="_blank"><i class="fab fa-twitter"></i></a>';
                }
                $output .= '</div>';
            }
            $output .= '</div>';

            return $output;
        }
    }

    new VCTeamMemberGrid();
}

?>