<?php
class VCBlueBoxContent extends WPBakeryShortCode {
    function __construct() {
        add_action('init', array($this, 'vc_blue_box_content_mapping'),45);
        add_shortcode('vc_blue_box_content', array($this, 'vc_blue_box_content_html'));
    }

    public function vc_blue_box_content_mapping() {
        if (!defined('WPB_VC_VERSION')) {
            return;
        }

        vc_map(array(
            'name' => __('Blue Box Content', 'text-domain'),
            'base' => 'vc_blue_box_content',
            'description' => __('Display a custom Blue Box Content', 'text-domain'),
            'category' => CUSTOM_ELEMENTS_CATEGORY,
            'params' => array(
                array(
                    'type' => 'textfield',
                    'heading' => __('Heading', 'text-domain'),
                    'param_name' => 'heading',
                    'description' => __('Enter the heading text.', 'text-domain'),
                ),
                array(
                    'type' => 'textarea',
                    'heading' => __('Paragraph Text', 'text-domain'),
                    'param_name' => 'paragraph_text',
                    'description' => __('Enter the paragraph text.', 'text-domain'),
                ),
                array(
                    'type' => 'attach_image',
                    'heading' => __('Image', 'text-domain'),
                    'param_name' => 'image',
                    'description' => __('Select an image.', 'text-domain'),
                ),
                // Left Side Content
                array(
                    'type' => 'textarea',
                    'heading' => __('Left Side Text', 'text-domain'),
                    'param_name' => 'left_side_text',
                    'description' => __('Enter text for the left side.', 'text-domain'),
                ),
                // Right Side Content
                array(
                    'type' => 'textarea',
                    'heading' => __('Right Side Text', 'text-domain'),
                    'param_name' => 'right_side_text',
                    'description' => __('Enter text for the right side.', 'text-domain'),
                ),
            ),
        ));
    }

    public function vc_blue_box_content_html($atts) {
        // Shortcode logic here
        $atts = shortcode_atts(array(
            'heading' => 'Blue Box Approach',
            'paragraph_text' => 'Lorem ipsum dolor sit amet consectetur adipisicing elit, sed do eiusmod tempor.',
            'image' => '',
            'left_side_text' => '',
            'right_side_text' => '',
        ), $atts);

        $image_url = wp_get_attachment_url($atts['image']);

        ob_start(); // Start output buffer capture
        ?>
        <section class="home-box">
            <div class="container">
                <div class="text-center bp-3 wow fadeInUp" data-wow-duration="1.5s">
                    <h2><?php echo esc_html($atts['heading']); ?></h2>
                    <p><?php echo esc_html($atts['paragraph_text']); ?></p>
                </div>
                <div class="row justify-content-center">
                    <div class="col-lg-9 col-xl-12">
                        <div class="home-box-image">
                            <div class="home-box-image-hold wow fadeInUp" data-wow-duration="1.5s">
                                <img src="<?php echo esc_url($image_url); ?>" alt="" class="home-box-image-screen">
                            </div>
                            <div class="home-box-image-text home-box-image-text--left d-none d-lg-block wow fadeInDown" data-wow-duration="1.5s">
                                <p><?php echo esc_html($atts['left_side_text']); ?></p>
                                <img src="img/arrow-left.png" alt="">
                            </div>
                            <div class="home-box-image-text home-box-image-text--right d-none d-lg-block wow fadeInDown" data-wow-duration="1.5s">
                                <p><?php echo esc_html($atts['right_side_text']); ?></p>
                                <img src="img/arrow-right.png" alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <?php
        return ob_get_clean(); // Return output buffer contents
    }
}

new VCBlueBoxContent();
