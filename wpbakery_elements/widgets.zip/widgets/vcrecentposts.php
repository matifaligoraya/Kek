<?php
class VCRecentPosts extends WPBakeryShortCode {

    function __construct() {
        // Initialize the shortcode and map it
        add_action('vc_before_init', array($this, 'vc_recent_posts_mapping'),50);
        add_shortcode('vc_recent_posts', array($this, 'vc_recent_posts_html'));
    }

    function vc_recent_posts_mapping() {
        // Check if Visual Composer is not installed
        if (!defined('WPB_VC_VERSION')) {
            return;
        }

        vc_map(array(
            'name' => __('Recent Posts', 'text-domain'),
            'base' => 'vc_recent_posts',
            'description' => __('Displays a featured post with additional posts in a grid.', 'text-domain'),
            'category' => CUSTOM_ELEMENTS_CATEGORY, // Use a defined constant here
            'params' => array(
                array(
                    'type' => 'dropdown',
                    'heading' => __('Sort By', 'text-domain'),
                    'param_name' => 'sort_by',
                    'value' => array(
                        __('Latest ID', 'text-domain') => 'id',
                        __('Date', 'text-domain') => 'date'
                    ),
                    'description' => __('Select how to sort the posts.', 'text-domain'),
                ),
                array(
                    'type' => 'autocomplete',
                    'heading' => __('Select Categories', 'text-domain'),
                    'param_name' => 'categories',
                    'settings' => array(
                        'multiple' => true,
                        'sortable' => true,
                        'min_length' => 1,
                        'no_hide' => true,
                        'groups' => true,
                        'unique_values' => true,
                        'display_inline' => true,
                        'values' => $this->getCategories()
                    ),
                    'description' => __('Select categories to filter posts.', 'text-domain'),
                ),
                array(
                    'type' => 'vc_link',
                    'heading' => __('View All Link', 'text-domain'),
                    'param_name' => 'view_all_link',
                    'description' => __('Add a custom link for the "View All" button.', 'text-domain'),
                ),
            )
        ));
    }

    function getCategories() {
        $categories = get_categories(array(
            'hide_empty' => false,
        ));
        $values = array();
        foreach ($categories as $category) {
            $values[] = array(
                'value' => $category->term_id,
                'label' => $category->name,
            );
        }
        return $values;
    }

    function vc_recent_posts_html($atts) {
        // Set default attributes and extract them
        $atts = shortcode_atts(array(
            'sort_by' => 'date',
            'categories' => '',
            'view_all_link' => '',
        ), $atts);

        // Prepare category filter if categories are selected
        $category_ids = !empty($atts['categories']) ? explode(',', $atts['categories']) : array();

        // Set the query arguments based on the attributes
        $args = array(
            'post_type' => 'post',
            'posts_per_page' => 4,
            'post__not_in' => array(get_the_ID()), // Optionally exclude the current post
            'orderby' => $atts['sort_by'] == 'id' ? 'ID' : 'date',
            'order' => 'DESC',
            'category__in' => $category_ids,
        );

        // Query for recent blog posts
        $recent_posts = new WP_Query($args);

        ob_start(); // Start output buffering
        ?>
        <div class="news-title wow fadeInUp" data-wow-duration="1.5s">
            <h2>Recent Blogs & Articles</h2>
        </div>
  
                <?php
                $first_post = true;
                if ($recent_posts->have_posts()) : while ($recent_posts->have_posts()) : $recent_posts->the_post();
                    if ($first_post) {
                        $first_post = false;
                        ?>
                        <div class="news-block">
                            <div class="row justify-content-center align-items-center">
                                <div class="col-md-7 col-lg-6">
                                    <div class="news-block-image wow fadeInLeft" data-wow-duration="1.5s" 
                                    style="background-image: url('<?php echo get_the_post_thumbnail_url(get_the_ID(), 'large'); ?>')">
                                </div>
                                    
                                </div>
                                <div class="col-lg-6">
                                    <article class="news-block-text wow fadeInRight" data-wow-duration="1.5s">
                                        <h3><?php the_title(); ?></h3>
                                        <p><?php echo wp_trim_words(get_the_content(), 40); ?></p>
                                        <a href="<?php the_permalink(); ?>" class="news-block-text-more">Learn More</a>
                                    </article>
                                </div>
                            </div>
                        </div>
                        <div class="news-grid">
                    <?php
                    } else {
                        ?>
                            
                                <div class="news-item wow fadeInUp" data-wow-duration="1.5s">
                                    <div class="news-item-image">
                                        <a href="<?php the_permalink(); ?>" class="news-item-image-link" style="background-image: url('<?php echo get_the_post_thumbnail_url(get_the_ID(), 'medium'); ?>')"></a>
                                        <div class="news-category">
                                            <?php
                                            $categories = get_the_category();
                                            if (!empty($categories)) {
                                                foreach ($categories as $category) {
                                                    echo '<span>' . esc_html($category->name) . '</span>';
                                                }
                                            }
                                            ?>
                                         </div>
                                    </div>
                                    <div class="news-item-inner">
                                        <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                                       <div class="news-item-text"> <p><?php echo wp_trim_words(get_the_content(), 20); ?></p></div>
                                        <div class="news-item-bottom">
                                            <div class="news-author">
                                                <a href="<?php echo get_author_posts_url(get_the_author_meta('ID')); ?>" class="news-author-photo" style="background-image: url('<?php echo get_avatar_url(get_the_author_meta('ID')); ?>')"></a>
                                                <span>By <strong><a href="<?php echo get_author_posts_url(get_the_author_meta('ID')); ?>"><?php the_author(); ?></a></strong></span>
                                            </div>
                                            <a href="<?php the_permalink(); ?>" class="news-item-more"><i class="fas fa-arrow-right"></i></a>
                                        </div>
                                    </div>
                                </div>
                           
                    <?php
                    }
                endwhile; ?>
                 
                </div> <!-- End Grid Container -->
                <?php endif;
                wp_reset_postdata();
                ?>
            </div>
        </div>
        
        <?php
        return ob_get_clean(); // Return the output buffer
    }
}

// Instantiate the class
new VCRecentPosts();
