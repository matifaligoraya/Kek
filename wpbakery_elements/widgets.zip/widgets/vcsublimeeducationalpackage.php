<?php 

class VCSublimeEducationalPackageBox extends WPBakeryShortCode {
    function __construct() {
        add_action('init', array($this, 'vc_sublime_educational_package_mapping'), 40);
        add_shortcode('vc_sublime_educational_package', array($this, 'vc_sublime_educational_package_html'));
    }

    public function vc_sublime_educational_package_mapping() {
        if (!defined('WPB_VC_VERSION')) {
            return;
        }

        vc_map(array(
            'name' => __('Educational Package', 'text-domain'),
            'base' => 'vc_sublime_educational_package',
            'description' => __('Displays an educational package.', 'text-domain'),
            'category' => CUSTOM_ELEMENTS_CATEGORY,
            'params' => array(
                array(
                    'type' => 'attach_image',
                    'heading' => __('Image', 'text-domain'),
                    'param_name' => 'image',
                    'description' => __('Select an image.', 'text-domain'),
                ),
                array(
                    'type'        => 'textfield',
                    'heading'     => __('Video Url', 'sublimeplus'),
                    'param_name'  => 'discount',
                    'description' => __('Please provide the video url.', 'sublimeplus'),
                    'value'       => '',
                ),
                
                array(
                    'type' => 'textfield',
                    'heading' => __('Custom CSS Class', 'text-domain'),
                    'param_name' => 'custom_css_class',
                    'value' => '',
                    'description' => __('Optional. Add a custom CSS class for additional styling.', 'text-domain'),
                ),
               
            ),
        ));
    }

    public function vc_sublime_educational_package_html($atts) {
        $atts = shortcode_atts(array(
            'custom_css_class' => '',
            'image' => '',
            'discount' => '',
            'textcolor' => '',
            'background' => '',
        ), $atts);

        // Assuming you are passing a post ID through a shortcode attribute or using the global post
        global $post;
        $post_id = $post->ID;
        $image_url = wp_get_attachment_url($atts['image']);
        $background = get_post_meta($post_id, '_educational_package_bedge_background', true);
        $color = get_post_meta($post_id, '_educational_package_bedge_textcolor', true);
        $discount = get_post_meta($post_id, '_educational_package_bedge_discount', true);
        $new_price = get_post_meta($post_id, '_educational_package_price', true);
        $old_price = get_post_meta($post_id, '_educational_package_original_price', true);
        if( $discount == "")
        {
            $discount =  $this->calculate_discount_percentage($old_price, $new_price);
        }
        ob_start(); // Start output buffer capture
        ?>
       
        <style>
                    .education-discount {
                        background: <?= $background?> !important;
                        color: <?= $color?> !important;
                }
                .education-discount::before {
                    border-left: .75rem solid  <?= $background?> !important;
                 }
            </style>
        <aside class="education-plan wow zoomIn <?= esc_attr($atts['custom_css_class']); ?>" data-wow-duration="1.5s">
           
            <span class="education-discount"><?= esc_html($discount); ?></span>
            <div class="education-plan-video" style="background-image: url('<?= $image_url; ?>');">
            <a href="#" class="education-plan-video-play"><span><i class="fas fa-play"></i></span></a>
            </div>
            <div class="education-plan-inner">
                <?php if ($new_price ): ?>
                    <div class="education-plan-price">
                        <strong><?= esc_html($new_price); ?></strong> 
                        <span><?= esc_html($old_price); ?></span>
                    </div>
                <?php endif; ?>
                <?php if ($avail = get_post_meta($post_id, '_educational_package_available_offer', true)): ?>
                    <div class="education-plan-available"><?= esc_html($avail); ?></div>
                <?php endif; ?>
                <?php if ($link = get_post_meta($post_id, '_educational_package_purchase_link', true)): ?>
                    <a href="<?= esc_url($link); ?>" class="btn btn--secondary w-100 mb-3">Purchase Now</a>
                <?php endif; ?>
                <p><strong>Duration: </strong><?= esc_html(get_post_meta($post_id, '_educational_package_duration', true)); ?></p>
                <p><strong>Level: </strong><?= esc_html(get_post_meta($post_id, '_educational_package_level', true)); ?></p>
                <p><strong>Language: </strong><?= esc_html(get_post_meta($post_id, '_educational_package_language', true)); ?></p>
                <p><strong>Format: </strong><?= esc_html(get_post_meta($post_id, '_educational_package_format', true)); ?></p>
                
                <!-- <div class="education-plan-rating mt-3">
                    <i class="fas fa-star color--yellow"></i>
                    <i class="fas fa-star color--yellow"></i>
                    <i class="fas fa-star color--yellow"></i>
                    <i class="fas fa-star color--yellow"></i>
                    <i class="fas fa-star color--yellow"></i>
                    <span>Rating: 5 - 155 reviews</span>
                </div> -->
                
            </div>
        </aside>
        <?php
        return ob_get_clean(); // Return output buffer contents
    }

    function calculate_discount_percentage($old_price, $new_price) {
        // Remove dollar signs and convert to float
        $old_price = floatval(str_replace('$', '', $old_price));
        $new_price = floatval(str_replace('$', '', $new_price));
    
        // Check if the old price is not zero to avoid division by zero error
        if ($old_price == 0) {
            return 0; // Return 0% discount if old price is zero to avoid division by zero
        }
    
        // Calculate discount
        $difference = $old_price - $new_price;
        $discount_percentage = ($difference / $old_price) * 100;
    
        // Return the discount percentage
        return round($discount_percentage, 2) . ' %'; // Round to 2 decimal places for better readability
    }
}

new VCSublimeEducationalPackageBox();
