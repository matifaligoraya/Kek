<?php
class VCSublimeSubscriptionForm extends WPBakeryShortCode {
    function __construct() {
        add_action('init', array($this, 'vc_sublime_subscription_form_mapping'),45);
        add_shortcode('vc_sublime_subscription_form', array($this, 'vc_sublime_subscription_form_html'));
    }

    public function vc_sublime_subscription_form_mapping() {
        if (!defined('WPB_VC_VERSION')) {
            return;
        }

        vc_map(array(
            'name' => __('Subscription Form', 'text-domain'),
            'base' => 'vc_sublime_subscription_form',
            'description' => __('Displays a subscription form to gather user emails.', 'text-domain'),
            'category' => CUSTOM_ELEMENTS_CATEGORY,
            'params' => array(
                array(
                    'type' => 'textfield',
                    'heading' => __('Title', 'text-domain'),
                    'param_name' => 'title',
                    'value' => 'Get Free Analyses', // Default value
                    'description' => __('Enter the title of the form.', 'text-domain'),
                ),
                array(
                    'type' => 'textarea',
                    'heading' => __('Description', 'text-domain'),
                    'param_name' => 'description',
                    'value' => 'Subscribe now and be the first to receive all the latest updates!', // Default value
                    'description' => __('Enter the description text.', 'text-domain'),
                ),
                array(
                    'type' => 'attach_image',
                    'heading' => __('Decorative Image', 'text-domain'),
                    'param_name' => 'decor_image',
                    'description' => __('Upload an image for the decorative background.', 'text-domain'),
                ),
            ),
        ));
    }

    public function vc_sublime_subscription_form_html($atts) {
        $atts = shortcode_atts(array(
            'title' => 'Get Free Analyses',
            'description' => 'Subscribe now and be the first to receive all the latest updates!',
            'decor_image' => '',
        ), $atts);

        $decor_image_url = wp_get_attachment_url($atts['decor_image']);

        ob_start(); // Start output buffer capture
        ?>
        <aside class="subscribe">
            <div class="container">
                <div class="text-center wow fadeInUp" data-wow-duration="1.5s" style="visibility: visible; animation-duration: 1.5s; animation-name: fadeInUp;">
                    <h2><?php echo esc_html($atts['title']); ?></h2>
                    <p><?php echo esc_html($atts['description']); ?></p>
                </div>
                <div class="subscribe-form form">
                    <form action="">
                        <div class="row">
                            <div class="col-sm-6 col-lg-3">
                                <div class="form-group wow fadeInUp" data-wow-duration="1.5s">
                                    <input type="text" class="form-control" placeholder="First Name">
                                </div>
                            </div>
                            <div class="col-sm-6 col-lg-3">
                                <div class="form-group wow fadeInUp" data-wow-duration="1.5s">
                                    <input type="text" class="form-control" placeholder="Last Name">
                                </div>
                            </div>
                            <div class="col-sm-6 col-lg-4">
                                <div class="form-group wow fadeInUp" data-wow-duration="1.5s">
                                    <input type="email" class="form-control" placeholder="Email Address">
                                </div>
                            </div>
                            <div class="col-sm-6 col-lg-2">
                                <div class="form-group wow fadeInUp" data-wow-duration="1.5s">
                                    <a href="#" class="btn btn--gradient w-100" data-toggle="modal" data-target="#modalThankYou">Submit</a>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="decor">
                <span class="top_right"></span>
                <img src="<?php echo esc_url($decor_image_url); ?>" alt="">
            </div>
        </aside>
        <?php
        return ob_get_clean(); // Return output buffer contents
    }
}

new VCSublimeSubscriptionForm();
