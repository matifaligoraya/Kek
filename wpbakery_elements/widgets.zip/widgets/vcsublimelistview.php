<?php 

if (!class_exists('VCSublimeListView')) {
    class VCSublimeListView extends WPBakeryShortCode {

        function __construct() {
            add_action('vc_before_init', array($this, 'vc_sublime_list_view_mapping'), 34);
            add_shortcode('vc_sublime_list_view', array($this, 'vc_sublime_list_view_html'));
        }

        function vc_sublime_list_view_mapping() {
            vc_map(array(
                'name'        => __('List View', 'sublimeplus'),
                'base'        => 'vc_sublime_list_view',
                'description' => __('Add list view', 'sublimeplus'),
                'category' => CUSTOM_ELEMENTS_CATEGORY,
                'params'      => array(
                    array(
                        'type' => 'param_group',
                        'heading' => __('List View', 'sublimeplus'),
                        'param_name' => 'listview',
                        'description' => __('Add FAQ items.', 'sublimeplus'),
                        'params' => array(
                            array(
                                'type' => 'attach_image',
                                'heading' => __('List View Icon', 'sublimeplus'),
                                'param_name' => 'icon',
                                'admin_label' => true,
                            ),
                            array(
                                'type'        => 'textfield',
                                'heading'     => __('List Title', 'sublimeplus'),
                                'param_name'  => 'text',
                                'value'       => '', // Default value
                                'description' => __('Text for the list item.', 'sublimeplus'),
                            ),                        
                        )
                    ),                  
                )
            ));
        }

        public function vc_sublime_list_view_html($atts, $content = null) {
            $atts = shortcode_atts(array(
                'listview' => '',
            ), $atts, 'vc_sublime_list_view');
        
            $list_items = vc_param_group_parse_atts($atts['listview']);
            $output = '<div class="crypto-info-custom_list wow fadeInUp"><ul>';
        
            foreach ($list_items as $item) {
                // Check if the 'icon' key exists and get the URL if it does
                $image_url = isset($item['icon']) ? wp_get_attachment_url($item['icon']) : '';
                // Use a default image or styling if no image is set
                $background_style = $image_url ? ' style="background-image: url(' . esc_url($image_url) . ');"' : ' style="background-color: #f0f0f0;"'; // Default fallback background color
                $text = isset($item['text']) ? $item['text'] : ' ';
        
                $output .= '<li' . $background_style . '>' . $text . '</li>';
            }
        
            $output .= '</ul></div>';
            return $output;
        }
        
    }        

    // Initialize the class
    new VCSublimeListView();
}
?>
