<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

if (!class_exists('VCSublimeBanner')) {

    class VCSublimeBanner extends WPBakeryShortCode {

        function __construct() {
            add_action('init', array($this, 'create_shortcode'), 999);
            add_shortcode('vc_sublime_banner', array($this, 'render_shortcode'));
        }

        public function create_shortcode() {
            // Check if WPBakery Page Builder is active
            if (!defined('WPB_VC_VERSION')) {
                return;
            }

            vc_map(array(
                'name' => __('Sublime Banner', 'text-domain'),
                'base' => 'vc_sublime_banner',
                'description' => __('Display a sublime banner with video.', 'text-domain'),
                'category' => CUSTOM_ELEMENTS_CATEGORY, // Use a defined constant here
                'params' => array(
                    array(
                        'type' => 'textfield',
                        'heading' => __('Title Text', 'text-domain'),
                        'param_name' => 'title_text',
                        'value' => __('Reliable forecasts you can trust', 'text-domain'),
                        'admin_label' => true,
                    ),
                    array(
                        'type' => 'textarea_html',
                        'heading' => __('Description Text', 'text-domain'),
                        'param_name' => 'description_text',
                        'value' => __('Discover a fast and trusted way to make better decisions and improve success as a trader.', 'text-domain'),
                    ),
                    array(
                        'type' => 'param_group',
                        'heading' => __('Buttons', 'text-domain'),
                        'param_name' => 'buttons',
                        'params' => array(
                            array(
                                'type' => 'textfield',
                                'heading' => __('Button Text', 'text-domain'),
                                'param_name' => 'button_text',
                                'edit_field_class' => 'vc_col-sm-6 vc_column',
                                'admin_label' => true,
                                'description' => __('Enter the button text', 'text-domain')
                            ),
                            array(
                                'type' => 'vc_link',
                                'heading' => __('Button URL', 'text-domain'),
                                'param_name' => 'button_url',
                                'edit_field_class' => 'vc_col-sm-6 vc_column',
                                'description' => __('Enter the button URL', 'text-domain')
                            ),
                            array(
                                'type' => 'colorpicker',
                                'heading' => __('Button Color', 'text-domain'),
                                'param_name' => 'button_color',
                                'edit_field_class' => 'vc_col-sm-4 vc_column',
                                'description' => __('Select the button color', 'text-domain')
                            ),
                            array(
                                'type' => 'colorpicker',
                                'heading' => __('Button Border Color', 'text-domain'),
                                'param_name' => 'button_border_color',
                                'edit_field_class' => 'vc_col-sm-4 vc_column',
                                'description' => __('Select the button border color', 'text-domain')
                            ),
                            array(
                                'type' => 'iconpicker',
                                'heading' => __('Button Icon', 'text-domain'),
                                'param_name' => 'button_icon',
                                'edit_field_class' => 'vc_col-sm-4 vc_column',
                                'description' => __('Select the button icon', 'text-domain')
                            ),
                        )
                    ),
                    array(
                        'type' => 'param_group',
                        'heading' => __('Notes', 'text-domain'),
                        'param_name' => 'notes',
                        'params' => array(
                            array(
                                'type' => 'iconpicker',
                                'heading' => __('Note Icon', 'text-domain'),
                                'param_name' => 'note_icon',
                                'description' => __('Select the icon for the note', 'text-domain')
                            ),
                            array(
                                'type' => 'textarea',
                                'heading' => __('Note Text', 'text-domain'),
                                'param_name' => 'note_text',
                                'description' => __('Enter the text for the note (HTML tags allowed: <span>, <b>, <strong>, <a>)', 'text-domain'),
                                'value' => '',
                                'admin_label' => true,
                                'edit_field_class' => 'vc_col-sm-12 vc_column',
                            ),
                           
                        )
                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => __('Video URL', 'text-domain'),
                        'param_name' => 'video_url',
                        'description' => __('Enter your video link.', 'text-domain'),
                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => __('Video Poster URL', 'text-domain'),
                        'param_name' => 'video_poster_url',
                        'description' => __('Enter the video poster URL.', 'text-domain'),
                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => __('Play Button URL', 'text-domain'),
                        'param_name' => 'play_button_url',
                        'description' => __('Enter the play button URL.', 'text-domain'),
                    ),   array(
                        'type' => 'textfield',
                        'heading' => __('Custom Css Class', 'text-domain'),
                        'param_name' => 'custom_css_class',
                        'description' => __('Custom CSS class for the whole container.', 'text-domain'),
                    ),
                ),
            ));
        }

        public function render_shortcode($atts, $content, $tag) {
            $atts = shortcode_atts(array(
                'title_text' => 'Reliable forecasts you can trust',
                'description_text' => 'Discover a fast and trusted way to make better decisions and improve success as a trader.',
                'buttons' => '',
                'notes' => '',
                'video_url' => 'https://elliottwave-forecast.com/wp-content/uploads/2024/06/EWF_bg02.mp4',
                'video_poster_url' => 'https://elliottwave-forecast.com/wp-content/uploads/2024/06/video-image.jpg',
                'play_button_url' => 'https://elliottwave-forecast.com/wp-content/uploads/2022/04/EWF-DVC-FHD1.mp4',
                'custom_css_class' => ''
            ), $atts);

            // Parse buttons
            $buttons_list = vc_param_group_parse_atts($atts['buttons']);
            $buttons_output = '';
            foreach ($buttons_list as $button) {
                $button_url = vc_build_link($button['button_url']);
                $button_style = 'background-color: ' . esc_attr($button['button_color']) . '; border-color: ' . esc_attr($button['button_border_color']) . ';';
                $buttons_output .= '
                    <a href="' . esc_url($button_url['url']) . '" class="btn" style="' . $button_style . '">
                        <div class="btntxt">' . esc_html($button['button_text']) . '</div>
                        <div class="btnicon"><i class="' . esc_attr($button['button_icon']) . '"></i></div>
                    </a>';
            }

            // Parse notes
            $notes_list = vc_param_group_parse_atts($atts['notes']);
            $notes_output = '';
            foreach ($notes_list as $note) {
                $custom_css_class = esc_html($note['custom_css_class']);
                $note_text = wp_kses($note['note_text'], array('span' => array(), 'b' => array(), 'strong' => array(), 'a' => array('href' => array(), 'title' => array())));
                $notes_output .= '<div class="innernote"><div class="icon"><i class="' . $custom_css_class . ' ' . esc_attr($note['note_icon']) . '"></i> </div><div class="text">' . $note_text . '</div></div>';
            }

            $output = '
            <!--SLIDER EWF-->
            <section class="banner banner--home">
                <div class="banner-inner">
                    <div class="banner-text">
                        <div class="container">
                            <div class="banner-text-top">
                                <div class="ttl"><h1>' . esc_html($atts['title_text']) . '</h1></div>
                                <div class="txt">' . wpb_js_remove_wpautop($atts['description_text'], true) . '</div>
                                <div class="trial">
                                    <div class="trial-btn">' . $buttons_output . '</div>
                                </div>
                                <div class="note" style="border-top: 1px solid #86868680">' . $notes_output . '</div>
                            </div>
                        </div>
                        <div class="banner-video">
                            <div class="banner-video-hold">
                                <video autoplay loop muted webkit-playsinline="" playsinline="" poster="' . esc_url($atts['video_poster_url']) . '">
                                    <source src="' . esc_url($atts['video_url']) . '" type="video/mp4">
                                </video>
                            </div>
                            <div class="banner-play">
                                <a href="' . esc_url($atts['play_button_url']) . '" data-toggle="modal" data-target="#modalBannerVideo"><i class="fas fa-play"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <div class="modal modal-video fade" id="modalBannerVideo" tabindex="-1" role="dialog" aria-labelledby="modalBannerVideo" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-video-content">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                        <video controls="" webkit-playsinline="" playsinline="" poster="' . esc_url($atts['video_poster_url']) . '">
                            <source src="' . esc_url($atts['play_button_url']) . '" type="video/mp4">
                        </video>
                    </div>
                </div>
            </div>';

            return $output;
        }
    }

    new VCSublimeBanner();
}

