<?php
if (!class_exists('PlansListStyle2')) {

    class PlansListStyle2 extends WPBakeryShortCode {

        function __construct() {
            add_action('vc_before_init', array($this, 'vc_plans_list_style_2_mapping'), 55);
            add_shortcode('vc_plans_list_style_2', array($this, 'vc_plans_list_style_2_html'));
        }

        public function vc_plans_list_style_2_mapping() {
            if (!defined('WPB_VC_VERSION')) {
                return;
            }

            vc_map(array(
                'name' => __('Plans List Style 2', 'text-domain'),
                'base' => 'vc_plans_list_style_2',
                'description' => __('Displays a list of plans with features and prices.', 'text-domain'),
                'category' => CUSTOM_ELEMENTS_CATEGORY, // Use a defined constant here
                'params' => array(
                    array(
                        'type' => 'textfield',
                        'heading' => __('Heading', 'text-domain'),
                        'param_name' => 'heading',
                        'description' => __('Enter the section heading', 'text-domain'),
                    ),
                    array(
                        'type' => 'textarea',
                        'heading' => __('Description', 'text-domain'),
                        'param_name' => 'description',
                        'description' => __('Enter the section description', 'text-domain'),
                    ),
                    array(
                        'type' => 'param_group',
                        'heading' => __('Plans', 'text-domain'),
                        'param_name' => 'plans',
                        'params' => array(
                            array(
                                'type' => 'textfield',
                                'heading' => __('Plan Name', 'text-domain'),
                                'param_name' => 'plan_name',
                                'value' => '',
                                'edit_field_class' => 'vc_col-sm-12 vc_column',
                                'admin_label' => true,
                                'description' => __('Name of the plan', 'text-domain'),
                            ),
                            array(
                                'type' => 'textfield',
                                'heading' => __('Plan Tag', 'text-domain'),
                                'param_name' => 'plan_tag',
                                'value' => '',
                                'edit_field_class' => 'vc_col-sm-12 vc_column',
                                'description' => __('Tag of the plan', 'text-domain'),
                            ),
                            array(
                                'type' => 'textfield',
                                'heading' => __('Plan Tagline', 'text-domain'),
                                'param_name' => 'plan_tagline',
                                'value' => '',
                                'description' => __('Name of the plan.', 'text-domain'),
                                'admin_label' => true,
                            ),
                            array(
                                'type' => 'textfield',
                                'heading' => __('Price', 'text-domain'),
                                'param_name' => 'price',
                                'value' => '',
                                'edit_field_class' => 'vc_col-sm-6 vc_column',
                                'description' => __('Price of the plan', 'text-domain'),
                            ),
                            array(
                                'type' => 'textfield',
                                'heading' => __('Billing Period', 'text-domain'),
                                'param_name' => 'billing_period',
                                'value' => '',
                                'edit_field_class' => 'vc_col-sm-6 vc_column',
                                'description' => __('Billing period of the plan', 'text-domain'),
                            ),
                            array(
                                'type' => 'textfield',
                                'heading' => __('Button Text', 'text-domain'),
                                'param_name' => 'button_text',
                                'value' => '',
                                'edit_field_class' => 'vc_col-sm-6 vc_column',
                                'description' => __('Text for the button', 'text-domain'),
                            ),
                            array(
                                'type' => 'vc_link',
                                'heading' => __('Button Link', 'text-domain'),
                                'edit_field_class' => 'vc_col-sm-6 vc_column',
                                'param_name' => 'button_link',
                                'description' => __('URL for the button', 'text-domain'),
                            ),
                            array(
                                'type' => 'param_group',
                                'heading' => __('Features', 'text-domain'),
                                'param_name' => 'features',
                                'params' => array(
                                    array(
                                        'type' => 'attach_image',
                                        'heading' => __('Feature Image', 'text-domain'),
                                        'param_name' => 'feature_image',
                                        'edit_field_class' => 'vc_col-sm-4 vc_column',
                                        'description' => __('Select image for the feature.', 'text-domain'),
                                    ),
                                    array(
                                        'type' => 'textarea',
                                        'heading' => __('Feature', 'text-domain'),
                                        'param_name' => 'feature_text',
                                        'edit_field_class' => 'vc_col-sm-8 vc_column',
                                        'admin_label' => true,
                                        'description' => __('Enter the feature text.', 'text-domain'),
                                    ),
                                ),
                            ),
                            array(
                                'type' => 'textfield',
                                'heading' => __('Custom CSS Class', 'text-domain'),
                                'param_name' => 'custom_css_class',
                                'value' => '',
                                'description' => __('Add a custom CSS class for styling this element.', 'text-domain'),
                            ),
                        )
                    ),
                    array(
                        'type' => 'textarea',
                        'heading' => __('Section Text', 'text-domain'),
                        'param_name' => 'section_text',
                        'description' => __('Enter the text for the section after the plans', 'text-domain'),
                    ),
                    array(
                        'type' => 'vc_link',
                        'heading' => __('Video Link', 'text-domain'),
                        'param_name' => 'video_link',
                        'description' => __('URL for the video link', 'text-domain'),
                    ),
                )
            ));
        }

        public function vc_plans_list_style_2_html($atts) {
            extract(shortcode_atts(array(
                'heading' => '',
                'description' => '',
                'plans' => '',
                'section_text' => '',
                'video_link' => '',
            ), $atts));

            $plans = vc_param_group_parse_atts($atts['plans']);
            $video_link = vc_build_link($video_link);
            ob_start();
            ?>
            <div class="plansliststyle2">
                <div class="container">
                    <?php if (!empty($heading)): ?>
                        <h2 class="section-heading"><?php echo esc_html($heading); ?></h2>
                    <?php endif; ?>
                    <?php if (!empty($description)): ?>
                        <p class="section-p"><?php echo esc_html($description); ?></p>
                    <?php endif; ?>
                    <div class="pricing-plans-list row">
                        <?php foreach ($plans as $plan) :
                            if (empty($plan)) {
                                continue;
                            }
                            $custom_css_class = isset($plan['custom_css_class']) ? esc_attr($plan['custom_css_class']) : '';
                            $features = isset($plan['features']) ? vc_param_group_parse_atts($plan['features']) : [];
                            $link = isset($plan['button_link']) ? vc_build_link($plan['button_link']) : array('url' => '#', 'title' => '');
                        ?>
                        <div class="pricing-plan col-lg-3 col-md-6 col-sm-12 d-flex <?php echo $custom_css_class; ?>"">
                            <div class="plan-inner">
                                <div class="plan-header">
                                    <?php if (!empty($plan['plan_tag'])): ?>
                                        <h3 class="plan-title"><?php echo esc_html($plan['plan_tag']); ?></h3>
                                    <?php endif; ?>
                                </div>
                                <div class="plan-body">
                                    <div class="title">
                                        <h4><?php echo esc_html(isset($plan['plan_name']) ? $plan['plan_name'] : ''); ?></h4>
                                    </div> 
                                    <div class="plan_tagline">
                                        <p><?php echo esc_html(isset($plan['plan_tagline']) ? $plan['plan_tagline'] : ''); ?></p>
                                    </div>
                                    <ul class="plan-features">
                                        <?php foreach ($features as $feature) :
                                            if (empty($feature)) {
                                                continue;
                                            }
                                        ?>
                                            <li>
                                                <?php if (!empty($feature['feature_image'])) : ?>
                                                    <img src="<?php echo wp_get_attachment_image_url($feature['feature_image'], 'thumbnail'); ?>" alt="<?php echo esc_attr(isset($feature['feature_text']) ? $feature['feature_text'] : ''); ?>" />
                                                <?php endif; ?>
                                                <span><?php echo wp_kses(isset($feature['feature_text']) ? $feature['feature_text'] : '', array(
                                                    'div' => array(
                                                        'class' => true,
                                                    ),
                                                    'span' => array(
                                                        'class' => true,
                                                    ),
                                                    'br' => array(),
                                                )); ?></span>
                                            </li>
                                        <?php endforeach; ?>
                                    </ul>
                                    <div class="plan-price">
                                        <span class="price"><?php echo esc_html(isset($plan['price']) ? $plan['price'] : ''); ?></span>
                                        <span class="billing-period"><?php echo esc_html(isset($plan['billing_period']) ? $plan['billing_period'] : ''); ?></span>
                                    </div>
                                </div>
                                <div class="plan-action">
                                    <a href="<?php echo esc_url($link['url']); ?>" 
                                    title="<?php echo esc_attr($link['title']); ?>" class="btn-lg btn-block">
                                        <?php echo esc_html(isset($plan['button_text']) ? $plan['button_text'] : ''); ?>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <?php if (!empty($section_text)): ?>
                        <div class="section-text">
                            <?php echo wp_kses_post($section_text); ?>
                            <?php if (!empty($video_link['url'])): ?>
                                <a href="<?php echo esc_url($video_link['url']); ?>" title="<?php echo esc_attr($video_link['title']); ?>" class="video-link">
                                    <img src="<?php echo plugin_dir_url(__DIR__); ?>images/playred.png" alt="<?php echo esc_attr($video_link['title']); ?>" /> <?php echo esc_html__('Watch Video', 'text-domain'); ?>
                                </a>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <style>
                .plansliststyle2 .section-heading {
                    font-size:24px;
                    font-weight:400;
                    line-height:36px;
                    text-align:left;
                    color:#011e57;
                }
              
                .plansliststyle2 .section-text {
                    text-align:center;
                    font-size:16px;
                    margin-top:20px;
                    color:#143e8d;
                }
                .plansliststyle2 .section-text .video-link {
                    font-size:15px;
                    font-weight:400;
                    line-height:22.5px;
                    text-align:left;
                    color:#143e8d;
                    text-decoration:none;
                }
                .plansliststyle2 .plan-action a {
                    font-size:15px;
                    font-weight:400;
                    line-height:22.5px;
                    color:#143e8d;
                    border:1px solid #03225d;
                    background-color:#fff;
                    border-radius:0;
                    text-align:center;
                }
                .plansliststyle2 .plan-body {
                    padding:20px;
                    border-bottom:solid 5px #fff;
                }
                .plansliststyle2 .pricing-plan {
                    display:flex;
                    align-items:stretch;
                }
                .plansliststyle2 .plan-inner {
                    display:flex;
                    flex-direction:column;
                    justify-content:space-between;
                    width:100%;
                    background:#154090;
                    background:linear-gradient(90deg,rgba(21,64,144,1) 0%,rgba(1,30,87,1) 100%);
                }
                .plansliststyle2 .plan-header {
                    background-color:#011e57;
                }
                .plansliststyle2 .plan-header h3 {
                    text-align:center;
                    padding:10px;
                    color:#fff;
                    font-size:15px;
                    line-height:22.5px;
                    margin:0;
                }
                .plansliststyle2 .plan-title-wrapper {
                    background:#fff;
                    padding:10px;
                    text-align:center;
                    margin-bottom:10px;
                }
                .plansliststyle2 .plan-body .title h3 {
                    font-size:23px;
                    font-weight:400;
                    line-height:34.5px;
                    text-align:left;
                    color:#fff;
                }
                .plansliststyle2 .plan-features {
                    list-style:none;
                    padding:0;
                    min-height:180px;
                }
                .plansliststyle2 .plan-features li span {
                    font-size:12px;
                    font-weight:400;
                    line-height:18.01px;
                    text-align:left;
                    color:#fff;
                    margin-left:10px;
                }
                .plansliststyle2 .plan-features li {
                    display:flex;
                    align-items:center;
                    margin-bottom:10px;
                }
                .plansliststyle2 .plan-features img {
                    width:13px;
                    height:13px;
                }
                .plansliststyle2 .plan-price .price {
                    color:#fff;
                    font-size:30px;
                    font-weight:400;
                    line-height:45px;
                    text-align:left;
                }
                .plansliststyle2 .plan-price .billing-period {
                    color:#fff;
                    font-size:12px;
                    font-weight:400;
                    line-height:18px;
                    text-align:left;
                }
                .plansliststyle2 .plan-price {
                    text-align:center;
                }
                .plansliststyle2 .plan-action .btn {
                    display:inline-block;
                    padding:10px 20px;
                    color:#fff;
                    background-color:#007bff;
                    border:none;
                    border-radius:5px;
                    text-decoration:none;
                    text-align:center;
                }
            </style>
            <?php
            return ob_get_clean();
        }
    }

    new PlansListStyle2();
}
