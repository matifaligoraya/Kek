<?php
class VCElliottWaveTheoryIntegration {
    public function __construct() {
        add_action('vc_before_init', array($this, 'vc_elliott_wave_theory_sidebar_integrateWithVC'), 45);
        $this->load_dependencies();
    }

    public function load_dependencies() {
        require_once plugin_dir_path(dirname(__FILE__)) . '/widgets/vcelliottwavetheorysidebar.php';
        require_once plugin_dir_path(dirname(__FILE__)) . '/widgets/vcelliottwavetheory.php';
    }

    public function vc_elliott_wave_theory_sidebar_integrateWithVC() {
        vc_map(array(
            'name' => __('Elliott Wave Theory Sidebar', 'text-domain'),
            'base' => 'vc_elliott_wave_theory_sidebar',
            'as_parent' => array('only' => 'vc_elliott_wave_theory_tab'),
            'content_element' => true,
            'show_settings_on_create' => true,
            'category' => __('Content', 'text-domain'),
            'params' => array(
                array(
                    'type' => 'textfield',
                    'heading' => __('Sidebar Title', 'text-domain'),
                    'param_name' => 'sidebar_title',
                    'description' => __('Title of the sidebar', 'text-domain'),
                ),
            ),
            'js_view' => 'VcColumnView',
        ));

        vc_map(array(
            'name' => __('Elliott Wave Theory Tab', 'text-domain'),
            'base' => 'vc_elliott_wave_theory_tab',
            'as_child' => array('only' => 'vc_elliott_wave_theory_sidebar'),
            'content_element' => true,
            'params' => array(
                array(
                    'type' => 'textfield',
                    'heading' => __('Tab Title', 'text-domain'),
                    'param_name' => 'tab_title',
                    'description' => __('Title of the tab', 'text-domain'),
                ),
                array(
                    'type' => 'textfield',
                    'heading' => __('Tab ID', 'text-domain'),
                    'param_name' => 'tab_id',
                    'description' => __('ID of the tab for linking', 'text-domain'),
                ),
                array(
                    'type' => 'textarea_html',
                    'heading' => __('Tab Content', 'text-domain'),
                    'param_name' => 'content',
                    'description' => __('Content of the tab', 'text-domain'),
                ),
            ),
            'js_view' => 'VcColumnView',
        ));
    }
}

// Initialize the integration class
new VCElliottWaveTheoryIntegration();
