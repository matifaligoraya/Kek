<?php 

if (!class_exists('VCSublimeFeaturedPost')) {
    class VCSublimeFeaturedPost extends WPBakeryShortCode {

        function __construct() {
            add_action('init', array($this, 'vc_sublime_featured_post_mapping'), 77);
            add_shortcode('vc_sublime_featured_post', array($this, 'vc_sublime_featured_post_html'));
        }

        function vc_sublime_featured_post_mapping() {
            vc_map(array(
                'name'        => __('Featured Post', 'sublimeplus'),
                'base'        => 'vc_sublime_featured_post',
                'description' => __('Display a featured post or a specific post.', 'sublimeplus'),
                'category' => CUSTOM_ELEMENTS_CATEGORY, // Use a defined constant here
                'params'      => array(
                    array(
                        'type'        => 'textfield',
                        'heading'     => __('Post ID', 'sublimeplus'),
                        'param_name'  => 'post_id',
                        'description' => __('Enter the ID of a specific post to feature, leave empty to show the default featured post.', 'sublimeplus'),
                    ),
                    array(
                        'type'        => 'textfield',
                        'heading'     => __('Custom CSS Class', 'sublimeplus'),
                        'param_name'  => 'custom_css_class',
                        'description' => __('Add a custom CSS class for styling this element.', 'sublimeplus'),
                    ),
                    array(
                        'type' => 'checkbox',
                        'heading' => __('Show Sidebar', 'sublimeplus'),
                        'param_name' => 'show_sidebar',
                        'value' => array(__('Yes', 'sublimeplus') => 'yes'),
                        'description' => __('Check to show the sidebar.', 'sublimeplus'),
                        'std' => 'yes', // Default to checked
                    ),
                )
            ));
        }

        public function vc_sublime_featured_post_html($atts) {
            $atts = shortcode_atts(
                array(
                    'post_id' => '',
                    'custom_css_class' => '',
                    'show_sidebar' => 'yes',
                ), 
                $atts, 'vc_sublime_featured_post'
            );

            $args = array(
                'post_type' => 'post',
                'posts_per_page' => 1,
            );

            if (!empty($atts['post_id'])) {
                $args['p'] = $atts['post_id'];
            } else {
                $args['meta_query'] = array(
                    array(
                        'key'     => '_elliott_wave_featured_post',
                        'value'   => 'on',
                        'compare' => '='
                    )
                );
            }

            $featured_post_query = new WP_Query($args);

            $show_sidebar = $atts['show_sidebar'] === 'yes';
            $column_class = $show_sidebar ? 'col-lg-8' : 'col-lg-12';

            ob_start();
            if ($featured_post_query->have_posts()) {
                while ($featured_post_query->have_posts()) {
                    $featured_post_query->the_post();
                    ?>
                    
                    <div class="news-title wow fadeInUp" data-wow-duration="1.5s">
                        <h2>Featured</h2>
                    </div>
                    <div class="row justify-content-center mb-3 <?php echo esc_attr($atts['custom_css_class']); ?>">
                        <div class="<?php echo esc_attr($column_class); ?>">
                            <article class="news-text mb-4 wow fadeInLeft" data-wow-duration="1.5s">
                                <div class="news-item">
                                    <div class="news-item-image">
                                        <a href="<?php the_permalink(); ?>" class="news-item-image-link" style="background-image: url('<?php echo get_the_post_thumbnail_url(get_the_ID(), 'large'); ?>')"></a>
                                        <div class="news-category">
    <?php
    $categories = get_the_category();
    if (!empty($categories)) {
        foreach ($categories as $category) {
            echo '<span>' . esc_html($category->name) . '</span>';
        }
    }
    ?>
</div>
                                    </div>
                                    <div class="news-item-inner">
                                        <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                                        <p><?php echo wp_trim_words(get_the_content(), 40); ?></p>
                                   
                                    <div class="news-item-bottom">
                                        <div class="news-author">
                                            <a href="<?php echo get_author_posts_url(get_the_author_meta('ID')); ?>" class="news-author-photo" style="background-image: url('<?php echo get_avatar_url(get_the_author_meta('ID')); ?>')"></a>
                                            <span>By <strong><a href="<?php echo get_author_posts_url(get_the_author_meta('ID')); ?>"><?php the_author(); ?></a></strong></span>
                                            <time class="news-date"><?php echo get_the_date(); ?></time>
                                        </div>
                                        <a href="<?php the_permalink(); ?>" class="news-item-more"><i class="fas fa-arrow-right"></i></a>
                                    </div>
                                    </div>
                                </div>
                            </article>
                        </div>
                        <?php 
                        // Sidebar
                        if ($show_sidebar && is_active_sidebar('ewf-blog-sidebar')) {
                            echo '<div class="col-sm-6 col-md-5 col-lg-4">';
                            echo '<aside class="sidebar wow fadeInRight" data-wow-duration="1.5s">';
                            dynamic_sidebar('ewf-blog-sidebar');
                            echo '</aside></div>';
                        }
                        ?>
                    </div>
                    <?php
                }
            } else {
                echo '<div class="news-title wow fadeInUp" data-wow-duration="1.5s"><h2>No Featured Post Found</h2></div>';
            }
            wp_reset_postdata();

            return ob_get_clean();
        }
    }

    new VCSublimeFeaturedPost();
}
?>
