<?php
class VCSublimeCTA extends WPBakeryShortCode {
    function __construct() {
        add_action('init', array($this, 'vc_sublime_cta_mapping'),40);
        add_shortcode('vc_sublime_cta', array($this, 'vc_sublime_cta_html'));
    }

    public function vc_sublime_cta_mapping() {
        if (!defined('WPB_VC_VERSION')) {
            return;
        }

        vc_map(array(
            'name' => __('Call To Action', 'text-domain'),
            'base' => 'vc_sublime_cta',
            'description' => __('Displays a Sublime Call to Action section.', 'text-domain'),
            'category' => CUSTOM_ELEMENTS_CATEGORY,
            'params' => array(
                array(
                    'type' => 'textfield',
                    'heading' => __('Button Text', 'text-domain'),
                    'param_name' => 'button_text',
                    'value' => 'Start 14-Day Trial', // Default value
                    'description' => __('Text on the button.', 'text-domain'),
                ),
                array(
                    'type' => 'textfield',
                    'heading' => __('Trial Cancel Info', 'text-domain'),
                    'param_name' => 'cancel_info',
                    'value' => 'Cancel Anytime', // Default value
                    'description' => __('Small text under the button.', 'text-domain'),
                ),
                array(
                    'type' => 'textfield',
                    'heading' => __('Heading', 'text-domain'),
                    'param_name' => 'heading',
                    'value' => 'Ready to get started?', // Default value
                    'description' => __('Main heading text.', 'text-domain'),
                ),
                array(
                    'type' => 'textarea',
                    'heading' => __('Description', 'text-domain'),
                    'param_name' => 'description',
                    'value' => 'Discover a fast and trusted way to make better decisions and improve your trading', // Default value
                    'description' => __('Description text below the heading.', 'text-domain'),
                ),
                array(
                    'type' => 'attach_image',
                    'heading' => __('Background Image', 'text-domain'),
                    'param_name' => 'bg_image',
                    'description' => __('Background image for the left side.', 'text-domain'),
                ),
            ),
        ));
    }

    public function vc_sublime_cta_html($atts) {
        $atts = shortcode_atts(array(
            'button_text' => 'Start 14-Day Trial',
            'cancel_info' => 'Cancel Anytime',
            'heading' => 'Ready to get started?',
            'description' => 'Discover a fast and trusted way to make better decisions and improve your trading',
            'bg_image' => '',
        ), $atts);

        $bg_image_url = wp_get_attachment_url($atts['bg_image']);

        ob_start(); // Start output buffer capture
        ?>
        <aside class="start">
            <div class="start-inner">
            <div class="container">
                <div class="row align-items-center justify-content-center">
                    <div class="col-xl-6">
                        <div class="start-monitor wow fadeInLeft" data-wow-duration="1.5s" 
                        style="
                         visibility: visible; animation-duration: 1.5s; animation-name: fadeInLeft;">
                        <div class="start-monitor-inner" style="background-image: url('<?php echo esc_url($bg_image_url); ?>');"></div> 
                        </div>
                    </div>
                    <div class="col-md-8 col-lg-7 col-xl-6">
                        <div class="start-text wow zoomIn" data-wow-duration="1.5s" style="visibility: visible; animation-duration: 1.5s; animation-name: zoomIn;">
                            <h2><?php echo esc_html($atts['heading']); ?></h2>
                            <p><?php echo esc_html($atts['description']); ?></p>
                            <div class="trial">
                                <div class="trial-btn">
                                    <a href="trial-login.php" class="btn btn--secondary"><?php echo esc_html($atts['button_text']); ?></a>
                                    <span><?php echo esc_html($atts['cancel_info']); ?></span>
                                </div>
                              <!--   <div class="trial-inner">
                                    <span>Or log in with: </span>
                                    Social links could be dynamically included here if needed 
                                </div>-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </div>
        </aside>
        <?php
        return ob_get_clean(); // Return output buffer contents
    }
}

new VCSublimeCTA();
