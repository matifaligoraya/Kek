<?php

if (!class_exists('VCDailyWeeklyVideos')) {
    class VCDailyWeeklyVideos extends WPBakeryShortCode {
        function __construct() {
            add_action('init', array($this, 'vc_daily_weekly_videos_mapping'),40);
            add_shortcode('vc_daily_weekly_videos', array($this, 'vc_daily_weekly_videos_html'));
        }

        public function vc_daily_weekly_videos_mapping() {
            if (!defined('WPB_VC_VERSION')) {
                return;
            }

            vc_map(array(
                'name' => __('Daily & Weekly Videos', 'text-domain'),
                'base' => 'vc_daily_weekly_videos',
                'description' => __('Display 4 selected posts as Daily & Weekly Videos', 'text-domain'),
                'category' => CUSTOM_ELEMENTS_CATEGORY,
                'params' => array(
                    // Repeat this parameter array for each post selection
                    array(
                        'type' => 'textfield',
                        'heading' => __('Post 1 ID', 'text-domain'),
                        'param_name' => 'post_1_id',
                        'description' => __('Enter the ID of the first post.', 'text-domain'),
                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => __('Post 2 ID', 'text-domain'),
                        'param_name' => 'post_2_id',
                        'description' => __('Enter the ID of the second post.', 'text-domain'),
                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => __('Post 3 ID', 'text-domain'),
                        'param_name' => 'post_3_id',
                        'description' => __('Enter the ID of the third post.', 'text-domain'),
                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => __('Post 4 ID', 'text-domain'),
                        'param_name' => 'post_4_id',
                        'description' => __('Enter the ID of the fourth post.', 'text-domain'),
                    ),
                ),
            ));
        }

        public function vc_daily_weekly_videos_html($atts) {
            $atts = shortcode_atts(array(
                'post_1_id' => '',
                'post_2_id' => '',
                'post_3_id' => '',
                'post_4_id' => '',
            ), $atts);

            $posts = array(
                get_post($atts['post_1_id']),
                get_post($atts['post_2_id']),
                get_post($atts['post_3_id']),
                get_post($atts['post_4_id']),
            );

            ob_start(); // Start output buffer capture
?>
<main class="home">
    <section class="home-videos">
        <div class="container">
            <h2 class="wow fadeInUp" data-wow-duration="1.5s">Daily & Weekly Videos</h2>
            <div class="home-videos-grid">
                <?php foreach ($posts as $post): if(!$post) continue; ?>
                <div class="home-videos-item wow fadeInUp" data-wow-duration="1.5s">
                    <div class="home-videos-image">
                        <div class="home-videos-image-inner">
                            <div style="background-image: url(<?php echo get_the_post_thumbnail_url($post); ?>)"></div>
                        </div>
                    </div>
                    <div class="home-videos-inner">
                        <h3><?php echo get_the_title($post); ?></h3>
                        <a href="<?php echo get_permalink($post); ?>" class="btn">by <img src="img/logo-sub.png" alt=""> Video</a>
                    </div>
                    <div class="home-videos-play">
                        <a href="<?php echo get_permalink($post); ?>"><i class="fas fa-play"></i></a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
</main>
<?php
            return ob_get_clean(); // Return output buffer contents
        }
    }

    new VCDailyWeeklyVideos();
}
