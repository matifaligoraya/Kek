<?php 

if (!class_exists('VCSublimeNotes')) {
    class VCSublimeNotes extends WPBakeryShortCode {

        function __construct() {
            // Initialize the shortcode and map the VC element
            add_action('vc_before_init', array($this, 'vc_sublime_Notes_mapping'),45);
            add_shortcode('vc_sublime_Notes', array($this, 'vc_sublime_Notes_html'));
            add_action('vc_before_init',  array($this,'vc_sublime_register_array_param_note'),40);

        }

        function vc_sublime_register_array_param_note() {
            vc_add_shortcode_param('array_text_note',array($this, 'note_vc_array_text_form_field'));
           // wp_enqueue_script('note_vc_array_text_sortable', get_template_directory_uri() . '/js/note_vc_array_text.js', array('jquery', 'jquery-ui-sortable'), false, true);
        }
        
        function note_vc_array_text_form_field($settings, $value) {
            $decoded_value = json_decode(base64_decode($value), true) ?: [];
            ob_start();
            ?>
            <div class="note_vc_array_text_block">
                 <button type="button" class="btn btn-primary note_vc_array_text_add">Add Note</button>
                <input type="hidden" name="<?php echo esc_attr($settings['param_name']); ?>" class="wpb_vc_param_value wpb-textinput <?php echo esc_attr($settings['param_name']) . ' ' . esc_attr($settings['type']) . '_field'; ?>" value="<?php echo esc_attr($value); ?>">
           
                <ul class="note_vc_array_text_list">
                    <?php foreach ($decoded_value as $item) : ?>
                        <li class="note_vc_array_text_item">
                            <div class="note_vc_array_text_item_header">
                                <span>Note Details</span>
                                <button type="button" class="toggle-button">+</button>
                            </div>
                            <div class="note_vc_array_text_item_content" style="display: none;">
                                <div class="row">
                                    <div class="col-lg-12">
                                        Text: <input type="text" name="text[]" value="<?php echo esc_attr($item['text'] ?? ''); ?>">
                                    </div>
                            </div>
                        </li>
                    <?php endforeach; ?>
                </ul>
                </div>
            <?php
            return ob_get_clean();
        }
        
        

        public function vc_sublime_Notes_mapping() {
            if (!defined('WPB_VC_VERSION')) {
                return;
            }

            vc_map(array(
                'name'        => __('Notes', 'sublimeplus'),
                'base'        => 'vc_sublime_Notes',
                'description' => __('Display subscription Notes in a styled format.', 'sublimeplus'),
                'category' => CUSTOM_ELEMENTS_CATEGORY,
                'params'      => array(
                    array(
                        'type' => 'array_text_note',
                        'heading' => __('Notes', 'sublimeplus'),
                        'param_name' => 'sublime_notes',
                        'description' => __('Add Notes with icon, text, and a link.', 'sublimeplus'),
                    ),array(
                        'type' => 'textfield',
                        'heading' => __('Custom CSS Class', 'sublimeplus'),
                        'param_name' => 'custom_css_class',
                        'value' => '',
                        'description' => __('Add a custom CSS class for styling this element.', 'sublimeplus'),
                    ),
                )
            ));
        }

        public function vc_sublime_Notes_html($atts, $content = null) {
         //   print_r($atts);
            $atts = shortcode_atts(
                array(
                    'sublime_notes' => '',
                    'note_heading' => '',
                    'custom_css_class' => '',
                ), 
                $atts, 'vc_sublime_Notes'
            );
            //print_r( $atts);
         
            $notes = json_decode(base64_decode($atts['sublime_notes']), true) ?: [];
            if (!empty($notes)) {
            $output = '<div> <h3>'. $atts['note_heading'].'</h3>';
            $output .= ' <ul class="plans-notes wow fadeInUp ' . esc_attr($atts['custom_css_class']) . '"  data-wow-duration="1.5s">';
        
            foreach ($notes as $note) {
                $output .= '<li>' . esc_html($note['text']) . '</li>';
            }
        
            $output .= '</ul>
                        </div>';
            }
            return $output;
        }
    }        

    // Initialize the class
    new VCSublimeNotes();
}