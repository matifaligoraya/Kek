<?php 

class VCSublimeRelatedEducationalPackage extends WPBakeryShortCode {
    function __construct() {
        add_action('init', array($this, 'vc_sublime_related_educational_package_mapping'), 40);
        add_shortcode('vc_sublime_related_educational_package', array($this, 'vc_sublime_related_educational_package_html'));
    }

    public function vc_sublime_related_educational_package_mapping() {
        if (!defined('WPB_VC_VERSION')) {
            return;
        }

        vc_map(array(
            'name' => __('Related Educational Packages', 'text-domain'),
            'base' => 'vc_sublime_related_educational_package',
            'description' => __('Displays related educational packages.', 'text-domain'),
            'category' => CUSTOM_ELEMENTS_CATEGORY,
            'params' => array(
                array(
                    'type' => 'textfield',
                    'heading' => __('Section Heading', 'text-domain'),
                    'param_name' => 'section_heading',
                    'value' => 'Other Educational Products you may Like',
                    'description' => __('The heading of the section.', 'text-domain'),
                ),
                array(
                    'type' => 'textfield',
                    'heading' => __('View All Link', 'text-domain'),
                    'param_name' => 'all_link',
                    'value' => '#',
                    'description' => __('URL to view all educational products.', 'text-domain'),
                ),
            ),
        ));
    }

    public function vc_sublime_related_educational_package_html($atts) {
        $atts = shortcode_atts(array(
            'section_heading' => 'Other Educational Products you may Like',
            'all_link' => '#',
        ), $atts);

        global $post;
        $current_post_id = $post->ID;

        $args = array(
            'post_type' => 'educationalpackage',
            'posts_per_page' => -1,
            'post__not_in' => array($current_post_id) // Exclude current post
        );

        $related_packages = new WP_Query($args);

        ob_start(); // Start output buffer capture
        ?>
        <section class="education-block">
            <div class="container container--big">
                <div class="d-flex justify-content-between flex-column flex-sm-row wow fadeInUp" data-wow-duration="1.5s">
                    <h2 class="mb-2"><?php echo esc_html($atts['section_heading']); ?></h2>
                    <a href="<?php echo esc_url($atts['all_link']); ?>" class="education-all mt-3">View All Education Products</a>
                </div>
                <div class="education-slider wow fadeInUp" data-wow-duration="1.5s">
                    <?php if ($related_packages->have_posts()) : ?>
                       
                                <?php while ($related_packages->have_posts()) : $related_packages->the_post(); ?>
                                <?php
                                $post_id = get_the_ID();
                                 $discount = get_post_meta($post_id, '_educational_package_bedge_discount', true);
                                 $new_price = get_post_meta($post_id, '_educational_package_price', true);
                                 $old_price = get_post_meta($post_id, '_educational_package_original_price', true);
                                 if( $discount == "")
                                 {
                                     $discount =  $this->calculate_discount_percentage($old_price, $new_price);
                                 }

                                ?>
                                    <div class="item">
                                        <a href="<?php the_permalink(); ?>" class="education-slider-item">
                                            <?php if ($discount) : ?>
                                                <span class="education-discount"><?php echo esc_html($discount); ?></span>
                                            <?php endif; ?>
                                            <span class="education-slider-image">
                                                <span class="education-slider-image-img" style="background-image: url('<?php echo get_the_post_thumbnail_url(get_the_ID(), 'full') ; ?>')"></span>
                                                <strong class="education-slider-ttl"><?php the_title(); ?></strong>
                                            </span>
                                            <?php if ($slidertext = get_post_meta(get_the_ID(), '_educational_package_educationslidertext', true)) : ?>
                                                <span class="education-slider-text">
                                                <strong><?= $slidertext; ?></strong>
                                            </span>
                                            <?php endif; ?> 
                                        </a>
                                    </div>
                                <?php endwhile; wp_reset_postdata(); ?>
                          
                    <?php endif; ?>
                </div>
            </div>
        </section>
        <?php
        return ob_get_clean(); // Return output buffer contents
    }

    function calculate_discount_percentage($old_price, $new_price) {
        // Remove dollar signs and convert to float
        $old_price = floatval(str_replace('$', '', $old_price));
        $new_price = floatval(str_replace('$', '', $new_price));
    
        // Check if the old price is not zero to avoid division by zero error
        if ($old_price == 0) {
            return 0; // Return 0% discount if old price is zero to avoid division by zero
        }
    
        // Calculate discount
        $difference = $old_price - $new_price;
        $discount_percentage = ($difference / $old_price) * 100;
    
        // Return the discount percentage
        return round($discount_percentage, 2) . ' %'; // Round to 2 decimal places for better readability
    }


}

new VCSublimeRelatedEducationalPackage();
