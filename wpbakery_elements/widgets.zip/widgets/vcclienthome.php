<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

if (!class_exists('VCClientHome')) {

    class VCClientHome extends WPBakeryShortCode {

        function __construct() {
            add_action('init', array($this, 'create_shortcode'), 999);
            add_shortcode('vc_client_home', array($this, 'render_shortcode'));
        }

        public function create_shortcode() {
            // Check if WPBakery Page Builder is active
            if (!defined('WPB_VC_VERSION')) {
                return;
            }

            vc_map(array(
                'name' => __('Client Home', 'text-domain'),
                'base' => 'vc_client_home',
                'description' => __('Display client logos with publication details.', 'text-domain'),
                'category' => CUSTOM_ELEMENTS_CATEGORY, // Use a defined constant here
                'params' => array(
                    array(
                        'type' => 'textfield',
                        'heading' => __('Section Title', 'text-domain'),
                        'param_name' => 'section_title',
                        'value' => __('Published on', 'text-domain'),
                        'admin_label' => true,
                    ),
                    array(
                        'type' => 'param_group',
                        'heading' => __('Client Logos', 'text-domain'),
                        'param_name' => 'client_logos',
                        'params' => array(
                            array(
                                'type' => 'attach_image',
                                'heading' => __('Logo Image', 'text-domain'),
                                'param_name' => 'logo_image',
                                'description' => __('Upload the logo image.', 'text-domain')
                            ),
                            array(
                                'type' => 'textfield',
                                'heading' => __('Alt Text', 'text-domain'),
                                'param_name' => 'alt_text',
                                'description' => __('Enter the alt text for the image.', 'text-domain')
                            ),
                            array(
                                'type' => 'textfield',
                                'heading' => __('CSS Class', 'text-domain'),
                                'param_name' => 'css_class',
                                'description' => __('Enter a custom CSS class for the image.', 'text-domain')
                            ),
                        )
                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => __('Custom CSS Class', 'text-domain'),
                        'param_name' => 'custom_css_class',
                        'value' => '',
                        'description' => __('Add a custom CSS class for styling this element.', 'text-domain'),
                    ),
                ),
            ));
        }

        public function render_shortcode($atts, $content, $tag) {
            $atts = shortcode_atts(array(
                'section_title' => 'Published on',
                'client_logos' => '',
                'custom_css_class' => ''
            ), $atts);

            // Parse client logos
            $logos_list = vc_param_group_parse_atts($atts['client_logos']);
            $logos_output = '';
            foreach ($logos_list as $logo) {
                $logo_url = wp_get_attachment_url(isset($logo['logo_image']) ? $logo['logo_image'] : '');
                $alt_text = esc_attr(isset($logo['alt_text']) ? $logo['alt_text'] : '');
                $css_class = esc_attr(isset($logo['css_class']) ? $logo['css_class'] : '');
                $logos_output .= '
                    <div class="' . $css_class . '">
                        <noscript><img src="' . esc_url($logo_url) . '" alt="' . $alt_text . '" /></noscript>
                        <img class="lazyloaded" src="' . esc_url($logo_url) . '" data-src="' . esc_url($logo_url) . '" alt="' . $alt_text . '">
                    </div>';
            }

            $output = '
            <div class="client-home ' . esc_attr($atts['custom_css_class']) . '">
                <div class="container">
                    <div class="client-inner" style="display:flex; padding:2rem 0 5rem 0;">
                        <h3>' . esc_html($atts['section_title']) . '</h3>' . $logos_output . '
                    </div>
                </div>
            </div>';

            return $output;
        }
    }

    new VCClientHome();
}
