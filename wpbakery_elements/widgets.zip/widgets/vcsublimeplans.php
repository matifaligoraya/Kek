    <?php 

    if (!class_exists('VCSublimePlans')) {
        class VCSublimePlans extends WPBakeryShortCode {

            function __construct() {
                add_action('vc_before_init', array($this, 'vc_sublime_plans_mapping'), 45);
                add_shortcode('vc_sublime_plans', array($this, 'vc_sublime_plans_html'));
            }

            public function vc_sublime_plans_mapping() {
                if (!defined('WPB_VC_VERSION')) {
                    return;
                }

                vc_map(array(
                    'name'        => __('Sublime Plans', 'sublimeplus'),
                    'base'        => 'vc_sublime_plans',
                    'description' => __('Display subscription plans in a styled format.', 'sublimeplus'),
                    'category'    => CUSTOM_ELEMENTS_CATEGORY,
                    'params'      => array(
                        array(
                            'type'        => 'textfield',
                            'heading'     => __('Plan Name', 'sublimeplus'),
                            'param_name'  => 'plan_name',
                            'value'       => 'Silver - 2 for 1',
                            'description' => __('Name of the plan.', 'sublimeplus'),
                            'admin_label' => true,
                        ),
                        array(
                            'type'        => 'textfield',
                            'heading'     => __('Old Price', 'sublimeplus'),
                            'param_name'  => 'old_price',
                            'value'       => '',
                            'description' => __('Original price before discount.', 'sublimeplus'),
                        ),
                        array(
                            'type'        => 'textfield',
                            'heading'     => __('New Price', 'sublimeplus'),
                            'param_name'  => 'new_price',
                            'value'       => '',
                            'description' => __('Discounted price.strong,span,br,em,b,ul,li tags are allowed', 'sublimeplus'),
                        ),

                        array(
                            'type'        => 'textfield',
                            'heading'     => __('New Price Duration', 'sublimeplus'),
                            'param_name'  => 'price_duration',
                            'value'       => '',
                            'description' => __('Discounted price duration.', 'sublimeplus'),
                        ),
                        array(
                            'type'        => 'textfield',
                            'heading'     => __('Sign Up Link', 'sublimeplus'),
                            'param_name'  => 'signup_link',
                            'value'       => '',
                            'description' => __('URL for the sign-up page.', 'sublimeplus'),
                        ),  array(
                            'type' => 'textfield',
                            'heading' => __('Plan Name CSS Class', 'sublimeplus'),
                            'param_name' => 'plan_name_css_class',
                            'description' => __('Add a custom CSS class for the plan name.', 'sublimeplus'),
                        ),
                        array(
                            'type' => 'param_group',
                            'heading' => __('Plan Features', 'sublimeplus'),
                            'param_name' => 'plan_features',
                            'description' => __('Add features with icon, text, and a link.', 'sublimeplus'),
                            'params' => array(
                            
                                array(
                                    'type' => 'textfield',
                                    'heading' => __('Feature Text', 'sublimeplus'),
                                    'param_name' => 'text',
                                    'description' => __('Enter text for the feature.', 'sublimeplus'),
                                    'admin_label' => true,
                                ), array(
                                    'type' => 'attach_image',
                                    'heading' => __('Feature Icon', 'sublimeplus'),
                                    'param_name' => 'icon',
                                    'description' => __('Select an icon for the feature.', 'sublimeplus'),
                                ),
                                array(
                                    'type' => 'textfield',
                                    'heading' => __('Feature Info Hint', 'sublimeplus'),
                                    'param_name' => 'infohint',
                                    'description' => __('Additional information for the feature.', 'sublimeplus'),
                                ),
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => __('Custom CSS Class', 'sublimeplus'),
                            'param_name' => 'custom_css_class',
                            'value' => '',
                            'description' => __('Add a custom CSS class for styling this element.', 'sublimeplus'),
                        ),
                    )
                ));
            }

            public function vc_sublime_plans_html($atts) {
                $atts = shortcode_atts(array(
                    'plan_name'   => 'Silver - 2 for 1',
                    'old_price'   => '$99.99/ per Month',
                    'new_price'   => '$99.99 for 2 months*',
                    'signup_link' => 'trial-login.php',
                    'plan_features' => '',
                    'custom_css_class' => '',
                    'plan_name_css_class' => '',
                    'price_duration' => ''
                ), $atts);

                $allowed_html = array(
                    'strong' => array(),
                    'span' => array('class' => array(),),
                    'br' => array(),
                    'em' => array(),
                    'b' => array(),
                    'ul' => array('class' => array(),),
                    'li' => array('class' => array(),)
                );
                
                $plan_features = vc_param_group_parse_atts($atts['plan_features']);
                $output = '<div class="plans-item wow fadeInUp ' . esc_attr($atts['custom_css_class']) . '" data-wow-duration="1.5s">';
        //     $output .= '<div class="plans-item-status">' . esc_html($atts['plan_name']) . '</div>';
                $output .= '<div class="plans-item-status ' . esc_attr($atts['plan_name_css_class']) . '">' 
                        . esc_html($atts['plan_name']) . '</div>';

                $output .= '<div class="plans-item-price plans-item-price--old">' . esc_html($atts['old_price']) . '</div>';
                $output .= '<div class="plans-item-price plans-item-price--new">' . wp_kses($atts['new_price'], $allowed_html) . '<span>'.esc_html($atts['price_duration']).'</span>' . '</div>';
                $output .= '<a href="' . esc_url($atts['signup_link']) . '" class="btn btn--secondary w-100">Sign Up</a>';
                $output .= '<ul class="plans-item-list">';
                
                foreach ($plan_features as $feature) {
                  //  print_r($feature);
                    $img = "";
                    if (!empty($feature['icon'])) {
                        $img =  'style="background-image: url(\'' . wp_get_attachment_url($feature['icon']) . '\') !important;"';//$feature['icon'] ;
                    }else
                    {
                        $img = 'class="disabled"';
                    }

                //   $icon_url = wp_get_attachment_url($feature['icon']);
                    $output .= '<li ' . $img  . '>';
                    $output .= esc_html($feature['text']);
                    if (!empty($feature['infohint'])) {
                        $output .= '<div class="info"><i class="fas fa-info-circle"></i>';
                        $output .= '<div class="info-tooltip"><p>' . esc_html($feature['infohint']) . '</p></div></div>';
                    }
                    $output .= '</li>';
                }

                $output .= '</ul></div>';

                return $output;
            }
        }

        new VCSublimePlans();
    }
    ?>