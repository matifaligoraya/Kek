<?php 
class VCVideoPosts extends WPBakeryShortCode {

function __construct() {
    // Initialize the shortcode and map it
    add_action('vc_before_init', array($this, 'vc_video_posts_mapping'), 50);
    add_shortcode('vc_video_posts', array($this, 'vc_video_posts_html'));
}

function vc_video_posts_mapping() {
    // Check if Visual Composer is not installed
    if (!defined('WPB_VC_VERSION')) {
        return;
    }

    vc_map(array(
        'name' => __('Video Posts', 'text-domain'),
        'base' => 'vc_video_posts',
        'description' => __('Displays video analysis posts.', 'text-domain'),
        'category' => CUSTOM_ELEMENTS_CATEGORY, // Use a defined constant here
        'params' => array(
            array(
                'type' => 'autocomplete',
                'heading' => __('Select Category', 'text-domain'),
                'param_name' => 'category',
                'settings' => array(
                    'multiple' => false,
                    'sortable' => false,
                    'min_length' => 1,
                    'no_hide' => true,
                    'groups' => true,
                    'unique_values' => true,
                    'display_inline' => true,
                    'values' => $this->getCategories()
                ),
                'description' => __('Select category for video analysis.', 'text-domain'),
            ),
        )
    ));
}

function getCategories() {
    $categories = get_categories(array(
        'hide_empty' => false,
    ));
    $values = array();
    foreach ($categories as $category) {
        $values[] = array(
            'value' => $category->term_id,
            'label' => $category->name,
        );
    }
    return $values;
}

function vc_video_posts_html($atts) {
    // Set default attributes and extract them
    $atts = shortcode_atts(array(
        'category' => '',
    ), $atts);

    // Prepare category filter if a category is selected
    $category_id = !empty($atts['category']) ? intval($atts['category']) : '';

    // Set the query arguments based on the attributes
    $args = array(
        'post_type' => 'post',
        'posts_per_page' => 4,
        'post__not_in' => array(get_the_ID()), // Optionally exclude the current post
        'orderby' => 'date',
        'order' => 'DESC',
        'cat' => $category_id,
    );

    // Query for video posts
    $video_posts = new WP_Query($args);

    // Get the category link for the "View All" button
    $view_all_link = !empty($category_id) ? get_category_link($category_id) : '#';

    ob_start(); // Start output buffering
    ?>
    <div class="news-video">
        <div class="container">
            <div class="news-title wow fadeInUp" data-wow-duration="1.5s">
                <h2>Recent Video Analysis</h2>
            </div>
            <?php
            $first_post = true;
            if ($video_posts->have_posts()) : while ($video_posts->have_posts()) : $video_posts->the_post();
                if ($first_post) {
                    $first_post = false;
                    ?>
                    <div class="news-block">
                        <div class="row justify-content-center align-items-center">
                            <div class="col-md-7 col-lg-6">
                                <div class="news-block-image news-block-image--video wow fadeInLeft" data-wow-duration="1.5s" 
                                style="background-image: url('<?php echo get_the_post_thumbnail_url(get_the_ID(), 'large'); ?>')">
                                    <div class="news-block-image-play">
                                        <a href="<?php the_permalink(); ?>"><i class="fas fa-play"></i></a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <article class="news-block-text wow fadeInRight" data-wow-duration="1.5s">
                                    <h3><?php the_title(); ?></h3>
                                    <p><?php echo wp_trim_words(get_the_content(), 40); ?></p>
                                    <a href="<?php the_permalink(); ?>" class="news-block-text-more">Learn More</a>
                                </article>
                            </div>
                        </div>
                    </div>
                    <div class="news-grid">
                <?php
                } else {
                    ?>
                        
                            <div class="news-item news-item--video wow fadeInUp" data-wow-duration="1.5s">
                                <div class="news-item-image">
                                    <a href="<?php the_permalink(); ?>" class="news-item-image-link" style="background-image: url('<?php echo get_the_post_thumbnail_url(get_the_ID(), 'medium'); ?>')"></a>
                                    <div class="news-category">
                                        <?php
                                        $categories = get_the_category();
                                        if (!empty($categories)) {
                                            foreach ($categories as $category) {
                                                echo '<span>' . esc_html($category->name) . '</span>';
                                            }
                                        }
                                        ?>
                                     </div>
                                     <div class="news-item-play">
                                        <a href="<?php the_permalink(); ?>"><i class="fas fa-play"></i></a>
                                    </div>
                                </div>
                                <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                            </div>
                       
                <?php
                }
            endwhile; ?>
             
            </div> <!-- End Grid Container -->
            <?php endif;
            wp_reset_postdata();
            ?>
            <div class="text-right pt-2 pb-5 wow fadeInUp" data-wow-duration="1.5s">
                <a href="<?php echo esc_url($view_all_link); ?>" class="news-view_all">View All Video Analysis</a>
            </div>
        </div>
    </div>
    <?php
    return ob_get_clean(); // Return the output buffer
}
}

// Instantiate the class
new VCVideoPosts();
