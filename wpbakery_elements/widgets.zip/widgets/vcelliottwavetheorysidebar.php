<?php
if (!class_exists('VCElliottWaveTheorySidebar')) {
    class VCElliottWaveTheorySidebar extends WPBakeryShortCode {
        function __construct() {
            add_shortcode('vc_elliott_wave_theory_sidebar', array($this, 'vc_elliott_wave_theory_sidebar_html'));
        }

        public function vc_elliott_wave_theory_sidebar_html($atts, $content = null) {
            extract(shortcode_atts(array(
                'sidebar_title' => 'Contents',
            ), $atts));

            ob_start();
            ?>
            <div class="row justify-content-center">
                <div class="col-sm-6 col-md-5 col-lg-3">
                    <aside class="sidebar sidebar--sticky mCustomScrollbar _mCS_1">
                        <div id="mCSB_1" class="mCustomScrollBox mCS-dark-thin mCSB_vertical mCSB_inside" style="max-height: 206.819px;" tabindex="0">
                            <div id="mCSB_1_container" class="mCSB_container" style="position:relative; top:0; left:0;" dir="ltr">
                                <button class="open-sidebar"><?php echo esc_html($sidebar_title); ?> <i class="fas fa-ellipsis-v"></i> </button>
                                <h4 class="sidebar-title"><?php echo esc_html($sidebar_title); ?></h4>
                                <ul class="sidebar-contents">
                                    <?php echo do_shortcode($content); ?>
                                </ul>
                            </div>
                            <div id="mCSB_1_scrollbar_vertical" class="mCSB_scrollTools mCSB_1_scrollbar mCS-dark-thin mCSB_scrollTools_vertical" style="display: block;">
                                <div class="mCSB_draggerContainer">
                                    <div id="mCSB_1_dragger_vertical" class="mCSB_dragger" style="position: absolute; min-height: 30px; display: block; height: 31px; max-height: 196.817px; top: 0px;">
                                        <div class="mCSB_dragger_bar" style="line-height: 30px;"></div>
                                    </div>
                                    <div class="mCSB_draggerRail"></div>
                                </div>
                            </div>
                        </div>
                    </aside>
                </div>
                <div class="col-lg-9">
                    <article class="theory-article">
                        <?php echo do_shortcode($content); ?>
                    </article>
                </div>
            </div>
            <?php
            return ob_get_clean();
        }
    }

    new VCElliottWaveTheorySidebar();
}
