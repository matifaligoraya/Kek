<?php 
if (!class_exists('VCSublimeSocialLinks')) {
    class VCSublimeSocialLinks extends WPBakeryShortCode {

        function __construct() {
            add_action('vc_before_init', array($this, 'vc_sublime_social_links_mapping'), 45);
            add_shortcode('vc_sublime_social_links', array($this, 'vc_sublime_social_links_html'));
        }

        public function vc_sublime_social_links_mapping() {
            vc_map(array(
                'name' => __('Social Links', 'sublimeplus'),
                'base' => 'vc_sublime_social_links',
                'category' => __('SublimePlus', 'sublimeplus'),
                'description' => __('Display social media links with different styles.', 'sublimeplus'),
                'params' => array(
                    array(
                        'type' => 'textfield',
                        'heading' => __('Heading', 'sublimeplus'),
                        'param_name' => 'heading',
                        'description' => __('Enter a heading for the social links. Leave empty to not show a heading.', 'sublimeplus')
                    ),
                    array(
                        'type' => 'dropdown',
                        'heading' => __('Style', 'sublimeplus'),
                        'param_name' => 'style',
                        'value' => array(
                            __('Style 1', 'sublimeplus') => 'style1',
                            __('Style 2', 'sublimeplus') => 'style2'
                        ),
                        'description' => __('Select the style for the social links.', 'sublimeplus')
                    )
                )
            ));
        }

        public function vc_sublime_social_links_html($atts, $content = null) {
            $atts = shortcode_atts(
                array(
                    'heading' => '',
                    'style' => 'style1',
                ), 
                $atts, 'vc_sublime_social_links'
            );

            $settings = get_option(sublimeplus_SETTINGS_KEY, true);
            $social_links = isset($settings['social_links']) ? $settings['social_links'] : array();

            if (!empty($social_links)) {
                ob_start();
                
                if (!empty($atts['heading'])) {
                    echo '<h4 class="sidebar-title">' . esc_html($atts['heading']) . '</h4>';
                }

                if ($atts['style'] === 'style1') {
                    ?>
                    <div class="sidebar-social">
                        <?php foreach ($social_links['url'] as $index => $url) : ?>
                            <?php if (!empty($url) && !empty($social_links['icon'][$index])) : ?>
                                <a href="<?php echo esc_url($url); ?>" target="_blank">
                                    <i class="<?php echo esc_attr($social_links['icon'][$index]); ?>"></i>
                                </a>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>
                    <?php
                } else if ($atts['style'] === 'style2') {
                    ?>
                    <div class="about-contacts-social wow fadeInUp" data-wow-duration="1.5s" style="visibility: visible; animation-duration: 1.5s; animation-name: fadeInUp;">
                        <?php foreach ($social_links['url'] as $index => $url) : ?>
                            <?php if (!empty($url) && !empty($social_links['icon'][$index])) : ?>
                                <a href="<?php echo esc_url($url); ?>" target="_blank">
                                    <i class="<?php echo esc_attr($social_links['icon'][$index]); ?>"></i>
                                </a>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>
                    <?php
                }

                return ob_get_clean();
            }
        }
    }

    // Initialize the class
    new VCSublimeSocialLinks();
}
?>
