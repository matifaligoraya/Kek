<?php 

if ( ! class_exists( 'VCSublimeCustomMenu' ) ) {
    class VCSublimeCustomMenu extends WPBakeryShortCode {

        function __construct() {
            // Ensure the VC map gets initialized
            add_action('vc_before_init', array($this, 'vc_sublime_custom_menu_mapping'),30);
            // Register the shortcode
            add_shortcode('vc_sublime_custom_menu', array($this, 'vc_sublime_custom_menu_html'));
        }

        public function vc_sublime_custom_menu_mapping() {
            // Check if WPBakery Page Builder is initialized
            if (!defined('WPB_VC_VERSION')) {
                return;
            }

            // Map the new element
            vc_map(array(
                'name'        => __('Custom Menu', 'sublimeplus'),
                'base'        => 'vc_sublime_custom_menu',
                'description' => __('A custom menu with additional class control.', 'sublimeplus'),
                'category' => CUSTOM_ELEMENTS_CATEGORY, // Use a defined constant here
                'params'      => array(
                    array(
                        'type'        => 'dropdown',
                        'heading'     => __('Select Menu', 'sublimeplus'),
                        'param_name'  => 'nav_menu',
                        'value'       => array_flip(wp_list_pluck(wp_get_nav_menus(), 'name', 'term_id')), // List of menus
                        'description' => __('Choose the menu you want to display.', 'sublimeplus'),
                        'admin_label' => true,
                    ),  array(
                        'type'        => 'textfield',
                        'heading'     => __('Menu Title ', 'sublimeplus'),
                        'param_name'  => 'title',
                        'value'       => '',
                        'description' => __('Add additional classes to the menu container.', 'sublimeplus')
                    ),
                    array(
                        'type'        => 'textfield',
                        'heading'     => __('Extra Class for Menu', 'sublimeplus'),
                        'param_name'  => 'menu_class',
                        'value'       => '',
                        'description' => __('Add additional classes to the menu container.', 'sublimeplus')
                    ),
                )
            ));
        }

        public function vc_sublime_custom_menu_html($atts) {
            // Define the default attributes
            $atts = shortcode_atts(
                array(
                    'menu_class' => '',
                    'nav_menu'   => '',
                    'title'      => 'Forex', // Default title if you want to make it dynamic, add it to the vc_map
                ), 
                $atts, 'vc_sublime_custom_menu'
            );
        
            // Get the menu object
            $menu = wp_get_nav_menu_object($atts['nav_menu']);
            if (!$menu) {
                return '<p>Menu not found!</p>';  // Display error if menu not found
            }
        
            // Setup the output
            $output = '<div class="footer-box">';
            $output .= '<h3>' . esc_html($atts['title']);
            $output .= '<button class="footer-box-open d-sm-none"><i class="fas fa-chevron-down"></i></button></h3>';
            $output .= '<ul class="footer-box-list footer-menu sublime-menu ' . esc_attr($atts['menu_class']) . '">';
        
            // Set up menu arguments to customize the items
            $menu_args = array(
                'menu'        => $menu->term_id,
                'container'   => false,  // Do not wrap the menu in a div or ul
                'items_wrap'  => '%3$s',  // Only wrap items, no container
                'echo'        => false,  // Do not echo the result, we need it returned
            );
        
            // Render the menu
            $menu_html = wp_nav_menu($menu_args);
            // Inject menu HTML into the structure
            $output .= $menu_html;
            $output .= '</ul></div>';
        
            return $output;
        }
        
    }

    // Initialize the class
    new VCSublimeCustomMenu();
}
