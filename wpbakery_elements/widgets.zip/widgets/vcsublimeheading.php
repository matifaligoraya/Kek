<?php

if (!class_exists('VCSublimeHeading')) {
    class VCSublimeHeading {
        function __construct() {
            add_action('init', array($this, 'integrateWithVC'), 44);
        }

        public function integrateWithVC() {
            vc_map(array(
                'name' => __('Sublime Heading', 'my-text-domain'),
                'base' => 'vcsublimeheading',
                'class' => '',
                'category' => CUSTOM_ELEMENTS_CATEGORY, // Use a defined constant here
                'params' => array(
                    array(
                        'type' => 'textfield',
                        'heading' => __('Text', 'my-text-domain'),
                        'param_name' => 'text',
                        'description' => __('Enter the heading text', 'my-text-domain'),
                    ),
                    array(
                        'type' => 'dropdown',
                        'heading' => __('Tag', 'my-text-domain'),
                        'param_name' => 'tag',
                        'value' => array(
                            'H1' => 'h1',
                            'H2' => 'h2',
                            'H3' => 'h3',
                            'H4' => 'h4',
                            'H5' => 'h5',
                            'H6' => 'h6',
                        ),
                        'description' => __('Select the HTML tag for the heading', 'my-text-domain'),
                    ),
                    array(
                        'type' => 'colorpicker',
                        'heading' => __('Color', 'my-text-domain'),
                        'param_name' => 'color',
                        'description' => __('Select the color for the heading text', 'my-text-domain'),
                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => __('Font Size', 'my-text-domain'),
                        'param_name' => 'font_size',
                        'description' => __('Enter the font size for the heading (e.g., 32px)', 'my-text-domain'),
                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => __('Extra Class', 'my-text-domain'),
                        'param_name' => 'extra_class',
                        'description' => __('Add extra class name for styling', 'my-text-domain'),
                    ),
                ),
            ));
            add_shortcode('vcsublimeheading', array($this, 'renderShortcode'));
        }

        public function renderShortcode($atts) {
            extract(shortcode_atts(array(
                'text' => 'Sublime Heading',
                'tag' => 'h2',
                'color' => '#000000',
                'font_size' => '32px',
                'extra_class' => '',
            ), $atts));

            ob_start();
            ?>
            <<?php echo esc_html($tag); ?> class="<?php echo esc_attr($extra_class); ?>" style="color: <?php echo esc_attr($color); ?>; font-size: <?php echo esc_attr($font_size); ?>;">
                <?php echo esc_html($text); ?>
            </<?php echo esc_html($tag); ?>>
            <?php
            return ob_get_clean();
        }
    }

    new VCSublimeHeading();
}
?>
