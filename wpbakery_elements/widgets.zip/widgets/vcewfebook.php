<?php

if (!class_exists('VCEWFEbook')) {
    class VCEWFEbook {
        function __construct() {
            add_action('init', array($this, 'integrateWithVC'),44);
        }

        public function integrateWithVC() {
            vc_map(array(
                'name' => __('EWF eBook', 'my-text-domain'),
                'base' => 'vcewfebook',
                'class' => '',
                'category' => CUSTOM_ELEMENTS_CATEGORY, // Use a defined constant here
                'params' => array(
                    array(
                        'type' => 'textfield',
                        'heading' => __('Title', 'my-text-domain'),
                        'param_name' => 'title',
                        'description' => __('Enter the title of the eBook', 'my-text-domain'),
                    ),
                    array(
                        'type' => 'attach_image',
                        'heading' => __('Image', 'my-text-domain'),
                        'param_name' => 'image',
                        'description' => __('Select the image for the eBook', 'my-text-domain'),
                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => __('Button Text', 'my-text-domain'),
                        'param_name' => 'button_text',
                        'description' => __('Enter the text for the download button', 'my-text-domain'),
                    ),
                    array(
                        'type' => 'vc_link',
                        'heading' => __('Button URL', 'my-text-domain'),
                        'param_name' => 'button_url',
                        'description' => __('Enter the URL for the download button', 'my-text-domain'),
                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => __('Category', 'my-text-domain'),
                        'param_name' => 'category',
                        'description' => __('Enter the category of the eBook', 'my-text-domain'),
                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => __('Extra Class', 'my-text-domain'),
                        'param_name' => 'extra_class',
                        'description' => __('Add extra class name for styling', 'my-text-domain'),
                    ),
                ),
            ));
            add_shortcode('vcewfebook', array($this, 'renderShortcode'));
        }

        public function renderShortcode($atts) {
            extract(shortcode_atts(array(
                'title' => 'The Definitive Guide of Elliott Wave Forecasting Recordings',
                'image' => '',
                'button_text' => 'Download Free',
                'button_url' => '#',
                'category' => 'E-Book',
                'extra_class' => '',
            ), $atts));

            $img_url = wp_get_attachment_image_src($image, 'full')[0];

            $link = vc_build_link($button_url);

            ob_start();
            ?>
            <div class="book-block-item wow zoomIn <?php echo esc_attr($extra_class); ?>" data-wow-duration="1.5s">
                <img src="<?php echo esc_url($img_url); ?>" alt="" class="book-block-img">
                <div class="book-block-hold">
                    <div class="book-block-category"><?php echo esc_html($category); ?></div>
                    <h4><?php echo esc_html($title); ?></h4>
                    <a href="<?php echo esc_url($link['url']); ?>" class="btn btn--blue btn--sm pl-5 pr-5" target="<?php echo esc_attr($link['target']); ?>">
                        <?php echo esc_html($button_text); ?>
                    </a>
                </div>
            </div>
            <?php
            return ob_get_clean();
        }
    }

    new VCEWFEbook();
}
?>
