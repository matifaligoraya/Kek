<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

if (!class_exists('VCBlueBoxHome')) {

    class VCBlueBoxHome extends WPBakeryShortCode {

        function __construct() {
            add_action('init', array($this, 'create_shortcode'), 999);
            add_shortcode('vc_blue_box_home', array($this, 'render_shortcode'));
        }

        public function create_shortcode() {
            // Check if WPBakery Page Builder is active
            if (!defined('WPB_VC_VERSION')) {
                return;
            }

            vc_map(array(
                'name' => __('Blue Box Home', 'text-domain'),
                'base' => 'vc_blue_box_home',
                'description' => __('Display blue box with recent wins and strategy details.', 'text-domain'),
                'category' => CUSTOM_ELEMENTS_CATEGORY, // Use a defined constant here
                'params' => array(
                    array(
                        'type' => 'textfield',
                        'heading' => __('Section Title', 'text-domain'),
                        'param_name' => 'section_title',
                        'value' => __('Recent Blue Box Wins', 'text-domain'),
                        'admin_label' => true,
                    ),
                    array(
                        'type' => 'param_group',
                        'heading' => __('Videos', 'text-domain'),
                        'param_name' => 'videos',
                        'params' => array(
                            array(
                                'type' => 'textfield',
                                'heading' => __('Video URL', 'text-domain'),
                                'param_name' => 'video_url',
                                'description' => __('Enter the video URL.', 'text-domain')
                            ),
                            array(
                                'type' => 'attach_image',
                                'heading' => __('Thumbnail Image', 'text-domain'),
                                'param_name' => 'thumbnail_image',
                                'description' => __('Upload the thumbnail image.', 'text-domain')
                            ),
                            array(
                                'type' => 'textfield',
                                'heading' => __('Alt Text', 'text-domain'),
                                'param_name' => 'alt_text',
                                'description' => __('Enter the alt text for the image.', 'text-domain')
                            ),
                        )
                    ),
                    array(
                        'type' => 'param_group',
                        'heading' => __('Strategy Boxes', 'text-domain'),
                        'param_name' => 'strategy_boxes',
                        'params' => array(
                            array(
                                'type' => 'textfield',
                                'heading' => __('Strategy Title', 'text-domain'),
                                'param_name' => 'strategy_title',
                                'description' => __('Enter the title for the strategy box.', 'text-domain')
                            ),
                            array(
                                'type' => 'textarea',
                                'heading' => __('Strategy Description', 'text-domain'),
                                'param_name' => 'strategy_description',
                                'description' => __('Enter the description for the strategy box.', 'text-domain')
                            ),
                            array(
                                'type' => 'attach_image',
                                'heading' => __('Strategy Image', 'text-domain'),
                                'param_name' => 'strategy_image',
                                'description' => __('Upload the image for the strategy box.', 'text-domain')
                            ),
                            array(
                                'type' => 'textfield',
                                'heading' => __('Alt Text', 'text-domain'),
                                'param_name' => 'strategy_alt_text',
                                'description' => __('Enter the alt text for the strategy image.', 'text-domain')
                            ),
                        )
                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => __('Custom CSS Class', 'text-domain'),
                        'param_name' => 'custom_css_class',
                        'value' => '',
                        'description' => __('Add a custom CSS class for styling this element.', 'text-domain'),
                    ),
                ),
            ));
        }

        public function render_shortcode($atts, $content, $tag) {
            $atts = shortcode_atts(array(
                'section_title' => 'Recent Blue Box Wins',
                'videos' => '',
                'strategy_boxes' => '',
                'custom_css_class' => ''
            ), $atts);

            // Parse videos
            $videos_list = vc_param_group_parse_atts($atts['videos']);
            $videos_output = '';
            $modal_videos = '';
            foreach ($videos_list as $video) {
                $video_url = esc_url(isset($video['video_url']) ? $video['video_url'] : '');
                $thumbnail_url = wp_get_attachment_url(isset($video['thumbnail_image']) ? $video['thumbnail_image'] : '');
                $alt_text = esc_attr(isset($video['alt_text']) ? $video['alt_text'] : '');
                $videos_output .= '
                    <div class="video">
                        <a href="' . $video_url . '" data-toggle="modal" data-target="#modalBlueVideo">
                            <noscript><img src="' . esc_url($thumbnail_url) . '" alt="' . $alt_text . '"/></noscript>
                            <img class="lazyloaded" src="' . esc_url($thumbnail_url) . '" data-src="' . esc_url($thumbnail_url) . '" alt="' . $alt_text . '">
                        </a>
                    </div>';
                $modal_videos .= '
                    <div class="modal modal-video fade" id="modalBlueVideo" tabindex="-1" role="dialog" aria-labelledby="modalBlueVideo" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered" role="document">
                            <div class="modal-video-content">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">×</span>
                                </button>
                                <video controls="" webkit-playsinline="" playsinline="">
                                    <source src="' . $video_url . '" type="video/mp4">
                                </video>
                            </div>
                        </div>
                    </div>';
            }

            // Parse strategy boxes
            $strategy_list = vc_param_group_parse_atts($atts['strategy_boxes']);
            $strategy_output = '';
            foreach ($strategy_list as $strategy) {
                $strategy_title = esc_html(isset($strategy['strategy_title']) ? $strategy['strategy_title'] : '');
                $strategy_description = wp_kses(isset($strategy['strategy_description']) ? $strategy['strategy_description'] : '', getAllowedHTMLTags());
                $strategy_image_url = wp_get_attachment_url(isset($strategy['strategy_image']) ? $strategy['strategy_image'] : '');
                $strategy_alt_text = esc_attr(isset($strategy['strategy_alt_text']) ? $strategy['strategy_alt_text'] : '');
                $strategy_output .= '
                    <div class="box-content">
                        <noscript><img src="' . esc_url($strategy_image_url) . '" alt="' . $strategy_alt_text . '" /></noscript>
                        <img class="lazyloaded" src="' . esc_url($strategy_image_url) . '" data-src="' . esc_url($strategy_image_url) . '" alt="' . $strategy_alt_text . '">
                        <div class="box-text">
                            <h4>' . $strategy_title . '</h4>
                            ' . $strategy_description . '
                        </div>
                    </div>';
            }

            $output = '
            <section class="blue-home ' . esc_attr($atts['custom_css_class']) . '">
                <div class="container">
                    <div class="blue-box-inner">
                        <div class="box-left border-right">
                            <div class="video-slider">
                                <h3>' . esc_html($atts['section_title']) . '</h3>
                                <div class="videos">' . $videos_output . '</div>
                                <div class="dots"> <span class="dot"></span> <span class="dot"></span></div>
                            </div>
                        </div>
                        <div class="box-right">
                            <h3>Our Strategy</h3>' . $strategy_output . '
                        </div>
                    </div>
                </div>
            </section>
            ' . $modal_videos;

            return $output . "<script>
  document.addEventListener('DOMContentLoaded', function() {
    const dots = document.querySelectorAll('.dot');
    const videos = document.querySelector('.videos');
    let currentSlide = 0;

    dots.forEach((dot, index) => {
      dot.addEventListener('click', () => {
        currentSlide = index;
        updateSlider();
      });
    });

    function updateSlider() {
      const videoWidth = document.querySelector('.video').offsetWidth;
      videos.style.transform = 'translateX(-' + (currentSlide * videoWidth) + 'px)';

      dots.forEach(dot => {
        dot.classList.remove('active');
      });
      dots[currentSlide].classList.add('active');
    }
  });
</script>";
        }
    }

    new VCBlueBoxHome();
}
