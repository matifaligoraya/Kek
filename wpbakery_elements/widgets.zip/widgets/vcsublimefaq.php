<?php 

if (!class_exists('VCSublimeFAQ')) {
    class VCSublimeFAQ extends WPBakeryShortCode {

        function __construct() {
            add_action('vc_before_init', array($this, 'vc_sublime_faq_mapping'),45);
            add_shortcode('vc_sublime_faq', array($this, 'vc_sublime_faq_html'));
        }

        function vc_sublime_faq_mapping() {
            vc_map(array(
                'name'        => __('FAQ', 'sublimeplus'),
                'base'        => 'vc_sublime_faq',
                'description' => __('Add FAQ sections to your page.', 'sublimeplus'),
                'category' => CUSTOM_ELEMENTS_CATEGORY,
                'params'      => array(
                    array(
                        'type' => 'param_group',
                        'heading' => __('FAQs', 'sublimeplus'),
                        'param_name' => 'faqs',
                        'description' => __('Add FAQ items.', 'sublimeplus'),
                        'params' => array(
                            array(
                                'type' => 'textfield',
                                'heading' => __('FAQ Title', 'sublimeplus'),
                                'param_name' => 'title',
                                'admin_label' => true,
                            ),

                            array(
                                'type' => 'textarea',
                                'heading' => __('FAQ Content', 'sublimeplus'),
                                'param_name' => 'content', 
                                 'description' => __('FAQ Answer, strong,span,br,em,b,ul,li tags are allowed.', 'sublimeplus'),
                            )
                          
                        )
                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => __('Custom CSS Class', 'sublimeplus'),
                        'param_name' => 'custom_css_class',
                        'value' => '',
                        'description' => __('Add a custom CSS class for styling this element.', 'sublimeplus'),
                    ),
                )
            ));
        }

        public function vc_sublime_faq_html($atts, $content = null) {
            $atts = shortcode_atts(
                array(
                    'faqs' => '',
                    'custom_css_class' => '',
                ), 
                $atts, 'vc_sublime_faq'
            );

            $allowed_html = array(
                'strong' => array(),
                'span' => array('class' => array(),),
                'a' => array(
                    'href' => array(),
                    'title' => array(),
                    'class' => array(),
                    'style' => array(),
                    'target' => array(),
                ),
                'br' => array(),
                'em' => array(),
                'b' => array(),
                'ul' => array('class' => array(),),
                'li' => array('class' => array(),)
            );
            

            $faqs = vc_param_group_parse_atts($atts['faqs']);
            $output = ' <article class="plans-text wow fadeInRight" data-wow-duration="1.5s">
            <div id="accordion" class="faq">';
           // print_r( $faqs); 
           $id = count($faqs);
            foreach ($faqs as $index => $faq) {
                
                
                $faq_id = 'collapse' .  $id;
                $heading_id = 'heading' . $id;
                $id--;
                $output .= '<div class="card ' . esc_attr($atts['custom_css_class']) . '">';
                $output .= '<div class="card-header" id="' . $heading_id . '">';
                $output .= '<button class="card-opener collapsed" data-toggle="collapse" data-target="#' . $faq_id . '" aria-expanded="true" aria-controls="' . $faq_id . '">';
                $output .= esc_html($faq['title']);
                $output .= '</button>';
                $output .= '</div>';
                $output .= '<div id="' . $faq_id . '" class="collapse" aria-labelledby="' . $heading_id . '" data-parent="#accordion">';
                $output .= '<div class="card-body">';
                $output .= apply_filters('the_content',  wp_kses($faq['content'], $allowed_html));
                $output .= '</div>';
                $output .= '</div>';
                $output .= '</div>';
            }

            $output .= '</div></article>';
            return $output;
        }
    }        

    // Initialize the class
    new VCSublimeFAQ();
}
?>
