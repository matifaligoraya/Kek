<?php 

if (!class_exists('VCSublimeSidebar')) {
    class VCSublimeSidebar extends WPBakeryShortCode {

        function __construct() {
            add_action('vc_before_init', array($this, 'vc_sublime_sidebar_mapping'), 45);
            add_shortcode('vc_sublime_sidebar', array($this, 'vc_sublime_sidebar_html'));
        }

        function vc_sublime_sidebar_mapping() {
            vc_map(array(
                'name'        => __('Sidebar', 'sublimeplus'),
                'base'        => 'vc_sublime_sidebar',
                'description' => __('Select a sidebar to display.', 'sublimeplus'),
                'category'    => CUSTOM_ELEMENTS_CATEGORY,
                'params'      => array(
                    array(
                        'type' => 'dropdown',
                        'heading' => __('Select Sidebar', 'sublimeplus'),
                        'param_name' => 'sidebar_id',
                        'value' => $this->get_registered_sidebars(),
                        'description' => __('Select the sidebar to display.', 'sublimeplus'),
                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => __('Custom CSS Class', 'sublimeplus'),
                        'param_name' => 'custom_css_class',
                        'value' => '',
                        'description' => __('Add a custom CSS class for styling this element.', 'sublimeplus'),
                    ),
                )
            ));
        }

        private function get_registered_sidebars() {
            global $wp_registered_sidebars;
            $sidebars = array();
            foreach ($wp_registered_sidebars as $sidebar_id => $sidebar) {
                $sidebars[$sidebar['name']] = $sidebar_id;
            }
            return $sidebars;
        }

        public function vc_sublime_sidebar_html($atts, $content = null) {
          //  print_r($atts);
            $atts = shortcode_atts(
                array(
                    'sidebar_id' => '',
                    'custom_css_class' => '',
                ), 
                $atts, 'vc_sublime_sidebar'
            );

            ob_start();
          //  echo $atts['sidebar_id'];
            if (!empty($atts['sidebar_id'])) {
                echo '<div class="' . esc_attr($atts['custom_css_class']) . '">';
                dynamic_sidebar($atts['sidebar_id']);
                echo '</div>';
            }
            return ob_get_clean();
        }
    }        

    // Initialize the class
    new VCSublimeSidebar();
}
?>
