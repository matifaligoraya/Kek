<?php
class WPBakeryCustomElements {
    public function __construct() {
        add_action('vc_before_init', array($this, 'register_elements'),40);
        add_shortcode('parent_element', array($this, 'render_parent_element'),40);
        add_shortcode('child_element', array($this, 'render_child_element'),40);
    }

    public function register_elements() {
        // Register Parent Element
        vc_map(array(
            'name' => __('Parent Element', 'your-text-domain'),
            'base' => 'parent_element',
            'as_parent' => array('only' => 'child_element'), // Only accept this shortcode as child
            'content_element' => true,
            'show_settings_on_create' => true,
            'category' => __('Custom Elements', 'your-text-domain'),
            'params' => array(
                array(
                    'type' => 'textfield',
                    'heading' => __('Element Title', 'your-text-domain'),
                    'param_name' => 'title',
                    'description' => __('Enter the title of the element.', 'your-text-domain'),
                ),
            ),
            'js_view' => 'VcColumnView'
        ));

        // Register Child Element
        vc_map(array(
            'name' => __('Child Element', 'your-text-domain'),
            'base' => 'child_element',
            'content_element' => true,
            'as_child' => array('only' => 'parent_element'), // Use only inside parent_element
            'params' => array(
                array(
                    'type' => 'textfield',
                    'heading' => __('Child Content', 'your-text-domain'),
                    'param_name' => 'content',
                    'description' => __('Enter the content of the child element.', 'your-text-domain'),
                ),
            ),
        ));
    }

    public function render_parent_element($atts, $content = null) {
        $atts = shortcode_atts(array(
            'title' => '',
        ), $atts);
        
        return '<div class="parent-element">' . esc_html($atts['title']) . do_shortcode($content) . '</div>';
    }

    public function render_child_element($atts) {
        $atts = shortcode_atts(array(
            'content' => '',
        ), $atts);
        
        return '<div class="child-element">' . esc_html($atts['content']) . '</div>';
    }
}

// Instantiate the class
new WPBakeryCustomElements();

// Ensure these classes are defined outside of any other class
if (class_exists('WPBakeryShortCodesContainer')) {
    class WPBakeryShortCode_Parent_Element extends WPBakeryShortCodesContainer {}
}

if (class_exists('WPBakeryShortCode')) {
    class WPBakeryShortCode_Child_Element extends WPBakeryShortCode {}
}
