<?php

if (!class_exists('VCSublimeAboutUsBanner')) {
    class VCSublimeAboutUsBanner extends WPBakeryShortCode {

        function __construct() {
            add_action('init', array($this, 'vc_sublime_about_us_banner_mapping'), 50);
            add_shortcode('vc_sublime_about_us_banner', array($this, 'vc_sublime_about_us_banner_html'));
        }

        public function vc_sublime_about_us_banner_mapping() {
            if (!defined('WPB_VC_VERSION')) {
                return;
            }

            vc_map(array(
                'name' => __('About Us Banner', 'text-domain'),
                'base' => 'vc_sublime_about_us_banner',
                'description' => __('Displays an about section with multiple items.', 'text-domain'),
                'category' => CUSTOM_ELEMENTS_CATEGORY,
                'params' => array(
                    array(
                        'type' => 'textfield',
                        'heading' => __('Section Title', 'text-domain'),
                        'param_name' => 'section_title',
                        'description' => __('Title for the about section.', 'text-domain'),
                        'value' => 'Our key strengths include', // Default value
                    ),
                    array(
                        'type' => 'param_group',
                        'heading' => __('About Items', 'text-domain'),
                        'param_name' => 'about_items',
                        'description' => __('Add items to the about section.', 'text-domain'),
                        'params' => array(
                            array(
                                'type' => 'autocomplete',
                                'heading' => 'Select SVG',
                                'param_name' => 'svg_url',
                                'description' => 'Select an SVG file from the list.',
                                'settings' => array(
                                    'values' => get_svg_files_from_directory(),
                                    'min_length' => 1,
                                    'groups' => true,
                                    'unique_values' => true,
                                    'display_inline' => true,
                                    'delay' => 500,
                                    'auto_focus' => true,
                                    'sortable' => false,
                                    'max_items' => 1  // Ensure only one item can be selected
                            )),
                            array(
                                'type' => 'textfield',
                                'heading' => __('Item Title', 'text-domain'),
                                'param_name' => 'item_title',
                                'description' => __('Title for the about item.', 'text-domain'),
                                'admin_label' => true
                            ),
                            array(
                                'type' => 'textarea',
                                'heading' => __('Item Description', 'text-domain'),
                                'param_name' => 'item_description',
                                'description' => __('Description for the about item.', 'text-domain'),
                            ),
                        )
                    ),
                )
            ));
        }

        public function vc_sublime_about_us_banner_html($atts, $content = null) {
            extract(shortcode_atts(array(
                'section_title' => '',
                'about_items' => '',
            ), $atts));
            
            $items = vc_param_group_parse_atts($atts['about_items']);            
            ob_start();
            ?>
            <section class="about-section">
                <div class="container container--big">
                    <h2 class="wow fadeInUp" data-wow-duration="1.5s"><?php echo esc_html($section_title); ?></h2>
                    <div class="about-section-list">
                        <?php foreach ($items as $item): ?>          
                            <?php
                                $image_src = get_site_url() . "/img/svg/{$item['svg_url']}";    
                            ?>                
                            <div class="about-section-item wow fadeInUp" data-wow-duration="1.5s">
                                <img src="<?php echo esc_url($image_src); ?>" alt="">
                                <h3><?php echo esc_html($item['item_title']); ?></h3>
                                <div class="about-section-item-txt">
                                    <p><?php echo wp_kses_post($item['item_description']); ?></p>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div class="shapes">
                    <div class="shapes-base shapes-base--one"></div>
                    <div class="shapes-base shapes-base--two d-none d-md-block"></div>
                        <!--<div class="shapes-base shapes-base--three d-none d-md-block"></div>-->
                    <div class="decor">
                        <span class="bottom_right"></span>
                        <img src="img/circle-stripe-1.png" alt="">
                    </div>
                    <div class="circles d-none d-md-block">
                        <div class="circles-item circles-item--1"><div></div></div>
                        <div class="circles-item circles-item--2"><div></div></div>
                        <div class="circles-item circles-item--3"><div></div></div>
                        <div class="circles-item circles-item--4"><div></div></div>
                        <div class="circles-item circles-item--5"><div></div></div>
                        <div class="circles-item circles-item--6"><div></div></div>
                        <div class="circles-item circles-item--7"><div></div></div>
                        <div class="circles-item circles-item--8"><div></div></div>
                        <span class="top_right blue"></span>
                        <span class="bottom_left red"></span>
                    </div>
                </div>
            </section>
            <?php
            return ob_get_clean();
        }
    }

    new VCSublimeAboutUsBanner();
}
?>
