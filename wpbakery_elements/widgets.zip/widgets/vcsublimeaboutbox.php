<?php

if (!class_exists('VCSublimeAboutBox')) {
    class VCSublimeAboutBox extends WPBakeryShortCode {
        function __construct() {
            add_action('init', array($this, 'vc_sublime_about_box_mapping'), 31);
            add_shortcode('vc_sublime_about_box', array($this, 'vc_sublime_about_box_html'));
        }

        public function vc_sublime_about_box_mapping() {
            if (!defined('WPB_VC_VERSION')) {
                return;
            }

            vc_map(array(
                'name' => __('About Box', 'text-domain'),
                'base' => 'vc_sublime_about_box',
                'description' => __('Displays an about section for a book.', 'text-domain'),
                'category' => CUSTOM_ELEMENTS_CATEGORY,
                'params' => array(
                    array(
                        'type' => 'textfield',
                        'heading' => __('Title', 'text-domain'),
                        'param_name' => 'title',
                        'value' => 'About this Book', // Default value
                        'description' => __('Title of the book section.', 'text-domain'),
                    ),
                    array(
                        'type' => 'textarea_html',
                        'heading' => __('Content', 'text-domain'),
                        'param_name' => 'content',
                        'value' => 'Lorem Ipsum Dolor Sit Amet.', // Default value
                        'description' => __('Description of the book.', 'text-domain'),
                    ),
                    array(
                        'type' => 'attach_image',
                        'heading' => __('Image', 'text-domain'),
                        'param_name' => 'image',
                        'description' => __('Image for the book.', 'text-domain'),
                    ),
                )
            ));
        }

        public function vc_sublime_about_box_html($atts, $content = null) {
            $atts = shortcode_atts(array(
                'title' => 'About this Book',                
                'image' => '',
            ), $atts);
            $image_url = wp_get_attachment_url($atts['image']);

            ob_start();
            ?>
            <section class="book-about">
                <div class="container container--big">
                    <div class="row justify-content-center justify-content-lg-between align-items-center">
                        <div class="col-sm-7 col-md-7 col-lg-6">
                            <aside class="book-about-image wow zoomIn" data-wow-duration="1.5s">
                                <img src="<?php echo esc_url($image_url); ?>" alt="">
                            </aside>
                        </div>
                    <div class="col-sm-9 col-lg-6">
                    <article class="book-about-text pl-lg-4 wow zoomIn" data-wow-duration="1.5s">
                        <h2><?php echo esc_html($atts['title']); ?></h2>
                        <?php echo wp_kses_post($content); ?>
                    </article>
                </div>
            </div>
        </div>
        <div class="decor">
            <span class="top_right"></span>
            <img src="/img/circle-stripe-1.png" alt="">
        </div>
    </section>
    <?php
        return ob_get_clean(); // Return output buffer contents
    }
}

new VCSublimeAboutBox();
}
