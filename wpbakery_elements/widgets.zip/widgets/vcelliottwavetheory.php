<?php
if (!class_exists('VCElliottWaveTheoryTab')) {
    class VCElliottWaveTheoryTab extends WPBakeryShortCode {
        function __construct() {
            add_shortcode('vc_elliott_wave_theory_tab', array($this, 'vc_elliott_wave_theory_tab_html'));
        }

        private function generate_unique_id() {
            return 'tab-' . uniqid();
        }

        public function vc_elliott_wave_theory_tab_html($atts, $content = null) {
            extract(shortcode_atts(array(
                'tab_title' => '',
                'tab_id' => '',
            ), $atts));

            if (empty($tab_id)) {
                $tab_id = $this->generate_unique_id();
            }

            ob_start();
            ?>
            <li class="vc_tta-tab" data-vc-tab>
                <a href="#<?php echo esc_attr($tab_id); ?>" data-vc-tabs data-vc-container=".vc_tta">
                    <span class="vc_tta-title-text"><?php echo esc_html($tab_title); ?></span>
                </a>
                <ul>
                    <li><a href="#<?php echo esc_attr($tab_id); ?>" class="sidebar-contents-link"><?php echo esc_html($tab_title); ?></a></li>
                </ul>
            </li>
            <div id="<?php echo esc_attr($tab_id); ?>" class="vc_tta-panel" data-vc-content=".vc_tta-panel-body">
                <div class="vc_tta-panel-heading">
                    <h4 class="vc_tta-panel-title vc_tta-controls-icon-position-left">
                        <a href="#<?php echo esc_attr($tab_id); ?>" data-vc-accordion data-vc-container=".vc_tta-container">
                            <span class="vc_tta-title-text"><?php echo esc_html($tab_title); ?></span>
                            <i class="vc_tta-controls-icon vc_tta-controls-icon-plus"></i>
                        </a>
                    </h4>
                </div>
                <div class="vc_tta-panel-body">
                    <div class="vc_tta-panel-body-inner">
                        <?php echo wpb_js_remove_wpautop($content, true); ?>
                    </div>
                </div>
            </div>
            <?php
            return ob_get_clean();
        }
    }

    new VCElliottWaveTheoryTab();
}
