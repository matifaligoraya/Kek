<?php
if (!class_exists('VCChartOfTheDay')) {

    class VCChartOfTheDay extends WPBakeryShortCode {

        function __construct() {
            add_action('init', array($this, 'vc_chart_of_the_day_mapping'), 999);
            add_shortcode('vc_chart_of_the_day', array($this, 'vc_chart_of_the_day_html'));
        }

        public function vc_chart_of_the_day_mapping() {
            if (!defined('WPB_VC_VERSION')) {
                return;
            }

            vc_map(array(
                'name' => __('Chart of the Day', 'text-domain'),
                'base' => 'vc_chart_of_the_day',
                'description' => __('Display selected post as a Chart of the Day', 'text-domain'),
                'category' => CUSTOM_ELEMENTS_CATEGORY,
                'params' => array(
                    array(
                        'type' => 'textfield',
                        'heading' => __('Post ID', 'text-domain'),
                        'param_name' => 'post_id_codp',
                        'description' => __('Enter post ID to display', 'text-domain'),
                    ),
                    array(
                        'type' => 'attach_image',
                        'heading' => __('Custom Image', 'text-domain'),
                        'param_name' => 'custom_image',
                        'description' => __('Select a custom image to override the featured image', 'text-domain'),
                    ),
                ),
            ));
        }

        public function vc_chart_of_the_day_html($atts) {
            $atts = shortcode_atts(array(
                'post_id_codp' => '',
                'custom_image' => '',
            ), $atts);

            $post_id_codp = $atts['post_id_codp'];
            $custom_image = wp_get_attachment_url($atts['custom_image']);
            $post = get_post($post_id_codp);
            $title = $post ? get_the_title($post_id_codp) : '';
            $permalink = get_permalink($post_id_codp);
            $content = $post ? apply_filters('the_content', $post->post_content) : '';
            $featured_image = $custom_image ? $custom_image : get_the_post_thumbnail_url($post_id_codp, 'full');

            $output = <<<HTML
            <section class="home-chart">
                <div class="container">
                   
                    <div class="row">
                    <h2 class="wow fadeInUp" data-wow-duration="1.5s">Chart of the Day</h2>
                        <div class="col-lg-7">
                            <a href="{$permalink}" class="home-chart-image wow fadeInLeft" data-wow-duration="1.5s">
                                <img src="{$featured_image}" alt="">
                            </a>
                        </div>
                        <div class="col-lg-5">
                            <div class="home-chart-text wow fadeInRight" data-wow-duration="1.5s">
                                <h3>{$title}</h3>
                                {$content}
                                <a href="{$permalink}" class="btn btn--gradient"> Learn More > </a>
                            </div>
                        </div>
                    </div>
                </div>
             
            </section>
            HTML;

            return $output;
        }
    }

    new VCChartOfTheDay();
}
