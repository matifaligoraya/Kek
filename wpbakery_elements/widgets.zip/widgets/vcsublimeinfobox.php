<?php

if (!class_exists('VCSublimeInfoBox')) {
    class VCSublimeInfoBox extends WPBakeryShortCode {
        function __construct() {
            add_action('init', array($this, 'vc_sublime_info_box_mapping'), 41);
            add_shortcode('vc_sublime_info_box', array($this, 'vc_sublime_info_box_html'));
        }

        public function vc_sublime_info_box_mapping() {
            if (!defined('WPB_VC_VERSION')) {
                return;
            }

            vc_map(array(
                'name' => __('Info Box', 'text-domain'),
                'base' => 'vc_sublime_info_box',
                'description' => __('Displays a custom banner info section.', 'text-domain'),
                'category' => CUSTOM_ELEMENTS_CATEGORY,
                'params' => array(
                    array(
                        'type' => 'attach_image',
                        'heading' => __('Top Image', 'text-domain'),
                        'param_name' => 'top_image',
                        'description' => __('Select an image for the top section of the banner.', 'text-domain'),
                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => __('Top Image Link', 'text-domain'),
                        'param_name' => 'top_image_link',
                        'description' => __('Link for top image.', 'text-domain'),
                    ),
                    array(
                        'type' => 'attach_image',
                        'heading' => __('Middle Image', 'text-domain'),
                        'param_name' => 'middle_image',
                        'description' => __('Select an image for the middle section of the banner.', 'text-domain'),
                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => __('Middle Image Link', 'text-domain'),
                        'param_name' => 'mid_image_link',
                        'description' => __('Link for middle image.', 'text-domain'),
                    ),
                    array(
                        'type' => 'attach_image',
                        'heading' => __('Bottom Image', 'text-domain'),
                        'param_name' => 'bottom_image',
                        'description' => __('Select an image for the bottom section of the banner.', 'text-domain'),
                    ),      
                    array(
                        'type' => 'textfield',
                        'heading' => __('Bottom Image Link', 'text-domain'),
                        'param_name' => 'bottom_image_link',
                        'description' => __('Link for bottom image.', 'text-domain'),
                    ),          
                )
            ));
        }

        public function vc_sublime_info_box_html($atts, $content = null) {
            $atts = shortcode_atts(array(
                'top_image' => '',
                'mid_image' => '',
                'bottom_image' => '',
                'top_image_link' => '#',
                'mid_image_link' => '#',
                'bottom_image_link' => '#',
            ), $atts);

            $image_url = wp_get_attachment_url($atts['top_image']);
            $image_url2 = wp_get_attachment_url($atts['mid_image']);
            $image_url3 = wp_get_attachment_url($atts['bottom_image']);

            ob_start(); // Start output buffer capture
            ?>
            <div class="banner-info">
                <div class="banner-info-top su-no-padding">
                    <?php if ($image_url): ?>
                        <a href="<?php echo esc_url($atts['top_image_link']); ?>">
                            <img src="<?php echo esc_url($image_url); ?>" class="cover-img-div" alt="Banner Top Image">
                    </a>
                    <?php endif; ?>
                </div>             
                <div class="banner-info-bottom su-no-padding">
                    <?php if ($image_url3): ?>
                        <a href="<?php echo esc_url($atts['bottom_image_link']); ?>">
                            <img src="<?php echo esc_url($image_url3); ?>" class="cover-img-div" alt="Banner Bottom Image">
                        </a>
                    <?php endif; ?>
                </div>
            </div>

            <!-- <div class="banner-info">
                <div class="banner-info-top">
                    <h3>Learn To Trade The Right Side</h3>
                    <ul>
                        <li>78 Instruments Covered</li>
                        <li>Trade Setups</li>
                        <li>Live Chat Rooms</li>
                        <li>Daily Techical Videos</li>
                        <li>Live Analysis Sessions</li>
                    </ul>
                </div>
                <div class="banner-info-bottom">
                    <p>Stocks, ETFs, Indices, Forex, Commodities, Bonds, Crypto</p>
                    <a href="trial-login.php" class="btn btn--secondary w-100">Start 14-Day Trial</a>
                    <span class="banner-info-bottom-note">Cancel Anytime</span>
                </div>
            </div> -->

            <?php
            return ob_get_clean(); // Return output buffer contents
        }
    }

    new VCSublimeInfoBox();
}
?>
