<?php
class VCArticleSlider extends WPBakeryShortCode {

    function __construct() {
        // Initialize the shortcode and map it
        add_action('vc_before_init', array($this, 'vc_article_slider_mapping'),70);
        add_shortcode('vc_article_slider', array($this, 'vc_article_slider_html'));
    }

    function vc_article_slider_mapping() {
        // Check if Visual Composer is not installed
        if (!defined('WPB_VC_VERSION')) {
            return;
        }

        vc_map(array(
            'name' => __('Article Slider', 'text-domain'),
            'base' => 'vc_article_slider',
            'description' => __('Displays a slider of selected articles.', 'text-domain'),
            'category' => CUSTOM_ELEMENTS_CATEGORY, // Use a defined constant here

            'params' => array(
                array(
                    'type' => 'autocomplete',
                    'heading' => __('Select Posts', 'text-domain'),
                    'param_name' => 'post_ids',
                    'settings' => array(
                        'multiple' => true,
                        'sortable' => true,
                        'min_length' => 1,
                        'no_hide' => true,
                        'groups' => true,
                        'unique_values' => true,
                        'display_inline' => true,
                        'values' => $this->getPosts()
                    ),
                    'description' => __('Select posts to display in the slider.', 'text-domain'),
                ),
                array(
                    'type' => 'vc_link',
                    'heading' => __('View All Link', 'text-domain'),
                    'param_name' => 'view_all_link',
                    'description' => __('Add a custom link for the "View All" button.', 'text-domain'),
                ),
            )
        ));
    }

    function getPosts() {
        $posts = get_posts(array(
            'post_type' => 'post',
            'posts_per_page' => -1,
        ));
        $values = array();
        foreach ($posts as $post) {
            $values[] = array(
                'value' => $post->ID,
                'label' => $post->post_title,
            );
        }
        return $values;
    }

    function vc_article_slider_html($atts) {
        // Set default attributes and extract them
        $atts = shortcode_atts(array(
            'post_ids' => '',
            'view_all_link' => '',
        ), $atts);

        // Prepare post IDs
        $post_ids = !empty($atts['post_ids']) ? explode(',', $atts['post_ids']) : array();

        ob_start(); // Start output buffering
        ?>
        <section class="home-articles" style="padding: 3.438rem 0 5.875rem;">
            <div class="container">
                <h2 class="wow fadeInUp" data-wow-duration="1.5s">Featured Articles</h2>
                <div class="home-articles-slider wow fadeInUp" data-wow-duration="1.5s">
                    <?php
                    if (!empty($post_ids)) {
                        $query = new WP_Query(array(
                            'post_type' => 'post',
                            'post__in' => $post_ids,
                            'orderby' => 'post__in', // Preserve the order of selected posts
                        ));

                        if ($query->have_posts()) {
                            while ($query->have_posts()) {
                                $query->the_post();
                                ?>
                                <div class="item">
                                    <div class="home-articles-item">
                                        <div class="home-articles-title">
                                            <?php $categories = get_the_category(); ?>
                                            <?php if (!empty($categories)): ?>
                                                <div class="home-articles-title-mark"><?php echo esc_html($categories[0]->name); ?></div>
                                            <?php endif; ?>
                                            <h3><?php the_title(); ?></h3>
                                        </div>
                                        <div class="home-articles-date"><?php echo get_the_date(); ?></div>
                                        <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                                        <div class="home-articles-text">
                                            <p><?php echo wp_trim_words(get_the_content(), 20); ?></p>
                                        </div>
                                        <div class="home-articles-bottom">
                                            <div class="home-articles-author">
                                                <div class="home-articles-author-photo" style="background-image: url('<?php echo get_avatar_url(get_the_author_meta('ID')); ?>')"></div>
                                                <div class="home-articles-author-name">By <strong><a href="<?php echo get_author_posts_url(get_the_author_meta('ID')); ?>"><?php the_author(); ?></a></strong></div>
                                            </div>
                                            <a href="<?php the_permalink(); ?>" class="home-articles-more"><i class="fas fa-arrow-right"></i></a>
                                        </div>
                                    </div>
                                </div>
                                <?php
                            }
                        }
                        wp_reset_postdata();
                    }
                    ?>
                </div>
                <?php
                // Get the "View All" link
                $view_all_link = vc_build_link($atts['view_all_link']);
                $view_all_url = !empty($view_all_link['url']) ? esc_url($view_all_link['url']) : get_permalink(get_option('page_for_posts'));
                ?>
                <div class="text-center pt-2 wow fadeInUp" data-wow-duration="1.5s">
                    <a href="<?php echo $view_all_url; ?>" class="btn btn--gray-outline">View All</a>
                </div>
            </div>
        </section>
        <?php
        return ob_get_clean(); // Return the output buffer
    }
}

// Instantiate the class
new VCArticleSlider();
?>
