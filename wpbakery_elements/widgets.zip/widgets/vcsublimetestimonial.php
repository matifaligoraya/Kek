<?php 

if (!class_exists('VCSublimeTestimonial')) {
    class VCSublimeTestimonial extends WPBakeryShortCode {

        function __construct() {
            // Initialize the shortcode and map the VC element
            add_action('vc_before_init', array($this, 'vc_sublime_testimonial_mapping'),30);
            add_shortcode('vc_sublime_testimonial', array($this, 'vc_sublime_testimonial_html'));
        }

        function vc_sublime_testimonial_mapping() {
            vc_map(array(
                'name'        => __('Testimonials', 'sublimeplus'),
                'base'        => 'vc_sublime_testimonial',
                'description' => __('Display Testimonials.', 'sublimeplus'),
                'category' => CUSTOM_ELEMENTS_CATEGORY,
                'params'      => array(
                    array(
                        'type'        => 'textfield',
                        'heading'     => __('Section Heading', 'sublimeplus'),
                        'param_name'  => 'section_heading',
                        'value'       => 'What our Customers Said?',
                        'description' => __('The heading of the testimonial section.', 'sublimeplus'),
                    ),
                    array(
                        'type'        => 'dropdown',
                        'heading'     => __('Select Testimonial Category', 'sublimeplus'),
                        'param_name'  => 'testimonial_category',
                        'value'       => array_flip(vc_sublime_get_terms('section')),
                        'description' => __('Choose the category to filter testimonials.', 'sublimeplus'),
                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => __('Custom CSS Class', 'sublimeplus'),
                        'param_name' => 'custom_css_class',
                        'description' => __('Add a custom CSS class for additional styling.', 'sublimeplus'),
                    ),
                )
            ));
        }

        public function vc_sublime_testimonial_html($atts, $content = null) {
            $atts = shortcode_atts(
                array(
                    'section_heading' => 'What our Customers Said?',
                    'testimonial_category' => '',
                    'custom_css_class' => '',
                    'orderby' => 'meta_value_num',  // 'meta_value_num' for numeric sorting
    'meta_key' => '_testimonial_sortingNumber',  // Specify the custom field to sort by
   
                ), 
                $atts, 'vc_sublime_testimonial'
            );
            
            $args = array(
                'post_type' => 'testimonial',
                'posts_per_page' => -1
            );
            
            if (!empty($atts['testimonial_category'])) {
                $args['tax_query'] = array(
                    array(
                        'taxonomy' => 'section',
                        'field'    => 'slug',
                        'terms'    => $atts['testimonial_category']
                    )
                );
            }
            
            $query = new WP_Query($args);

           // print_r($query);
            $output = '<section class="testim-section"><div class="container container--big">';
            $output .= '<h2 class="text-center wow fadeInUp" data-wow-duration="1.5s">' . esc_html($atts['section_heading']) . '</h2>';
            $output .= '<div class="testim-section-slider wow fadeInUp" data-wow-duration="1.5s">';

            if ($query->have_posts()) {
                while ($query->have_posts()) {
                    $query->the_post();
                    $meta = get_post_meta(get_the_ID());
                    $testimonial_date = isset($meta['_testimonial_date'][0]) ? $meta['_testimonial_date'][0] : ' ';
                    $testimonial_company = isset($meta['_testimonial_company'][0]) ? $meta['_testimonial_company'][0] : ' ';
                    $testimonial_content = isset($meta['_testimonial_testimonial'][0]) ? $meta['_testimonial_testimonial'][0] : ' ';
                    $testimonialTitle = isset($meta['_testimonial_testimonialTitle'][0]) ? $meta['_testimonial_testimonialTitle'][0] : ' '; 
                   // $_testimonial_testimonial = isset($meta['_testimonial_testimonial'][0]) ? $meta['_testimonial_testimonial'][0] : ' '; 

                    $output .= '<div class="item"><div class="testim-section-item">';
                    $output .= '<div class="testim-section-photo" 
                                style="background-image: url(' . get_the_post_thumbnail_url(get_the_ID(), 'full') . ')"></div>';
                    $output .= '<div class="testim-section-content">';
                    $output .= '<h3>' . $testimonialTitle . '</h3>';
                    $output .= '<div class="position">' . esc_html($testimonial_date) 
                                . ' - ' . esc_html($testimonial_company) . '</div>';
                    $output .= '<div class="text-scroll">';
                    $output .= '<p>"' . $testimonial_content . '"</p>';
                    $output .= '</div></div>';
                    $output .= '<img src="'. get_site_url() . '/img/'.'quote-2.png" alt="" class="testim-section-quote">';
                    $output .= '</div></div>';
                }
                wp_reset_postdata();
            }

            $output .= '</div></div><div class="decor"><span class="top_right"></span><img src="'. get_site_url() . '/img/'.'circle-stripe-1.png" alt=""></div></section>';
            return $output;
        }
    }

    // Helper function to get taxonomy terms for dropdown
    function vc_sublime_get_terms($taxonomy) {
        $options = [];
        $terms = get_terms(array('taxonomy' => $taxonomy, 'hide_empty' => false));
        if (!is_wp_error($terms)) {
            foreach ($terms as $term) {
                $options[$term->slug] = $term->name;
            }
        }
        return $options;
    }

    new VCSublimeTestimonial();
}
?>
