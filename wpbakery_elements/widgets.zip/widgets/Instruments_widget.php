<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

if (!class_exists('VCInstrumentsWidget')) {

    class VCInstrumentsWidget extends WPBakeryShortCode {
        public string $ListHead = ''; // Initialize the private string variable
        public string $ListTabs = ''; // Initialize the private string variable

        function __construct() {
            add_action('init', array($this, 'create_shortcode'), 999);
            add_shortcode('vc_instruments_widget', array($this, 'render_shortcode'));
        }

        public function create_shortcode() {
            // Stop all if VC is not enabled
            if (!defined('WPB_VC_VERSION')) {
                return;
            }

            vc_map(array(
                'name' => __('Instruments Widget', 'text-domain'),
                'base' => 'vc_instruments_widget',
                'description' => __('A widget to display instruments.', 'text-domain'),
                'category' => CUSTOM_ELEMENTS_CATEGORY, // Use a defined constant here
                'params' => array(
                    array(
                        'type' => 'textfield',
                        'holder' => 'div',
                        'class' => '',
                        'heading' => __('Widget Title', 'text-domain'),
                        'param_name' => 'widget_title',
                        'value' => __('Instruments', 'text-domain'),
                        'description' => __('Title of the widget.', 'text-domain')
                    ), array(
                        'type' => 'textfield',
                        'holder' => 'div',
                        'class' => '',
                        'heading' => __('Widget Title', 'text-domain'),
                        'param_name' => 'widget_description',
                        'value' => __('Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt', 'text-domain'),
                        'description' => __('This Text will be apear after heading', 'text-domain')
                    ),
                    // Additional params for customization as needed...
                ),
            ));
        }

        public function render_shortcode($atts, $content = null) {
            // Shortcode parameters
            $atts = shortcode_atts(array(
                'widget_title' => 'Instruments',
                'widget_description' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt'
            ), $atts, 'vc_instruments_widget');


            $this->GetListHeads();

            $output= '';
//echo  $this->ListHead;
              // Start building the output
    $output .= '
    <section class="home-instruments">
        <div class="container">
            <div class="row mb-4">
                <div class="col-lg-6">
                    <div class="wow fadeInUp" data-wow-duration="1.5s">
                        <h2>' . esc_html($atts['widget_title']) . '</h2>
                        <p>' . esc_html($atts['widget_description']) . '</p>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center wow fadeInUp" data-wow-duration="1.5s">
                <div class="col-md-6 col-lg-4">
                    <ul class="nav nav-tabs" id="myTab" role="tablist">'
                    .  $this->ListHead .
                    '</ul>
                </div>
                <div class="col-lg-8">
                    <div class="tab-content" id="myTabContent">' 
                    . $this->ListTabs . 
                    '</div>
                    <div class="trial">
                        <div class="trial">
                            <div class="trial-btn justify-content-center">
                                <a href="trial-login.php" class="btn btn--secondary">Start 14-Day Trial</a>
                                <span>Cancel Anytime</span>
                            </div>
                            <div class="trial-inner justify-content-center">
                                <span>Or log in with: </span>
                                <a href="#" class="social-link social-link--g"><img src="img/svg/google.svg" alt="">Google</a>
                                <a href="#" class="social-link social-link--fb"><i class="fab fa-facebook-f"></i>Facebook</a>
                                <a href="#" class="social-link social-link--tw"><i class="fab fa-twitter"></i>Twitter</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="shapes">
            <div class="shapes-base shapes-base--one"></div>
            <div class="shapes-base shapes-base--two"></div>
            <div class="shapes-base shapes-base--three"></div>
            <div class="decor">
                <span class="bottom_right"></span>
                <img src="'. get_site_url() . '/img/'.'circle-stripe-1.png" alt="">
            </div>
            <div class="circles d-none d-md-block">
                <div class="circles-item circles-item--1"><div></div></div>
                <div class="circles-item circles-item--2"><div></div></div>
                <div class="circles-item circles-item--3"><div></div></div>
                <div class="circles-item circles-item--4"><div></div></div>
                <div class="circles-item circles-item--5"><div></div></div>
                <div class="circles-item circles-item--6"><div></div></div>
                <div class="circles-item circles-item--7"><div></div></div>
                <div class="circles-item circles-item--8"><div></div></div>
                <span class="top_right blue"></span>
            </div>
        </div>
    </section>';
            
            return $output;
        }
    

        protected function GetListHeads() {
            $args = array(
                'post_type' => 'instrument',
                'posts_per_page' => $settings['instruments_per_page'] ?? -1, // Use setting or default to all
                'post_status' => 'publish',
                'meta_key' => '_instrument_order',
                'orderby' => array(
                    'meta_value_num' => 'ASC',
                    'ID' => 'ASC' // Secondary sort by ID to maintain a consistent order
                ),
            
            );
            
            $firstactive = 'active';
            $firstshow = 'show';
            $instruments_query = get_posts($args);
        
            $this->ListHead = '';
            $this->ListTabs = ''; // Initialize ListTabs as well
        
            if ($instruments_query) {
                foreach ($instruments_query as $instrument) {
                    //print_r($instrument);
                    $icon = get_post_meta($instrument->ID, '_instrument_icon', true);

                    $_instrument_tabbanner = get_post_meta($instrument->ID, '_instrument_tabbanner', true); 
                  //  print_r( $_instrument_tabbanner);
                    $_instrument_tabbanner_url = "";
                    if (!empty($_instrument_tabbanner) && isset($_instrument_tabbanner['id'])) {
                        $_instrument_tabbanner_url = wp_get_attachment_url($_instrument_tabbanner['id']);
                    }
                    $icon_url = "";
                    if (!empty($icon) && isset($icon['id'])) {
                        $icon_url = wp_get_attachment_url($icon['id']);
                    } 
                    
                    //$_instrument_tabbanner = isset($_instrument_tabbanner) ? $_instrument_tabbanner[0] : '';
                  //  $_instrument_tabbanner = get_site_url() . '/img/svg/' . $_instrument_tabbanner;
                    $instrument_name = $instrument->post_title;
                    $safeTabName = preg_replace('/[\s-]/', '_', $instrument_name);
                   // $icon_url = get_site_url() . '/img/svg/' . $icon_url;
        
                    $this->ListHead .= '<li class="nav-item">';
                    $this->ListHead .= '<a class="nav-link ' . $firstshow . ' ' . $firstactive . '" 
                                        id="' . $safeTabName . '-tab" 
                                        data-toggle="tab"
                                        href="#' . $safeTabName . '" role="tab" aria-controls="' . $safeTabName . '" aria-selected="true">';
            
                    if ($icon_url == "") {
                        $icon_url = get_site_url() . '/img/svg/' . esc_html($safeTabName . ".svg");
                    }
                    $this->ListHead .= '<img src="' . esc_url($icon_url) . '" alt="">' . esc_html($safeTabName);
                    $this->ListHead .= '</a>';
                    $this->ListHead .= '</li>';
            
                    // Build tabs
                    $this->ListTabs .= '<div class="tab-pane fade ' . $firstshow . ' ' . $firstactive . '" id="' . $safeTabName . '" role="tabpanel" aria-labelledby="' . $safeTabName . '-tab">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <a class="nav-link" data-toggle="collapse" data-parent=".tab-pane" href="#collapseFirst">
                                    <img src="' . $icon_url . '" alt="">' . $instrument_name . '
                                </a>
                            </div>
                            <div id="collapseFirst" class="panel-collapse collapse in">
                                <div class="panel-body">
                                    <h3>' . $instrument_name . '</h3>
                                    <img src="' .$_instrument_tabbanner_url . '" alt="" class="chart">
                                    <div class="text-scroll-light">
                                        <ul class="list">'
                                            . $this->getPostMeta($instrument->ID) .
                                        '</ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>';
        
                    $firstshow = "";
                    $firstactive = "";
                }
            }
        }
        
        

        protected function getPostMeta($id)
        {
            $meta_values = get_post_meta($id, '_instrument_values', true); // Assuming your meta field is '_instrument_values'
            $metaValuesList = "";
        
            // Error handling if `_instrument_values` is not an array
            if (!is_array($meta_values)) {
                $meta_values = array(); // Set to an empty array if not an array
            }
        
            foreach ($meta_values as $element) {
                // Extract description and image URLs from each element
                $_instrument_desc_1 = array_key_exists('_instrument_desc_1', $element) ? esc_html($element['_instrument_desc_1']) : '';
                $_instrument_desc_2 = array_key_exists('_instrument_desc_2', $element) ? esc_html($element['_instrument_desc_2']) : '';
        
                $_instrument_image_1_url = '';
                if (!empty($element['_instrument_image_1']) && isset($element['_instrument_image_1']['id'])) {
                    $_instrument_image_1_url = wp_get_attachment_url($element['_instrument_image_1']['id']);
                }
        
                $_instrument_image_2_url = '';
                if (!empty($element['_instrument_image_2']) && isset($element['_instrument_image_2']['id'])) {
                    $_instrument_image_2_url = wp_get_attachment_url($element['_instrument_image_2']['id']);
                }
        
                $metaValuesList .= '<li><div class="flags">';
                $metaValuesList .= $_instrument_image_1_url != "" ? '<img src="' . esc_url($_instrument_image_1_url) . '" alt="' . $_instrument_desc_1 . '">' : '';
                $metaValuesList .= $_instrument_image_2_url != "" ? '<img src="' . esc_url($_instrument_image_2_url) . '" alt="' . $_instrument_desc_2 . '">' : '';
                $metaValuesList .= '</div>';
                $metaValuesList .= '<span>' . $_instrument_desc_1 . ' ' . $_instrument_desc_2 . '</span>';
                $metaValuesList .= '</li>';
            }
        
            return $metaValuesList;
        }

        

    }
       
    new VCInstrumentsWidget();
}
