<?php

if (!class_exists('VCSublimePackageTile')) {
    class VCSublimePackageTile extends WPBakeryShortCode {
        function __construct() {
            // Initialize the shortcode and map the VC element
            add_action('vc_before_init', array($this, 'vc_sublime_packageTile_mapping'), 30);
            add_shortcode('vc_sublime_packageTile', array($this, 'vc_sublime_packageTile_html'));
        }

        function vc_sublime_packageTile_mapping() {
            vc_map(array(
                'name'        => __('Package Tile', 'sublimeplus'),
                'base'        => 'vc_sublime_packageTile',
                'description' => __('Display a package tile with custom content.', 'sublimeplus'),
                'category' => CUSTOM_ELEMENTS_CATEGORY,
                
                'params'      => array(
                    array(
                        'type' => 'textfield',
                        'heading' => __('Custom CSS Class', 'sublimeplus'),
                        'param_name' => 'custom_css_class',
                        'value' => '',
                        'description' => __('Add a custom CSS class for styling this element.', 'sublimeplus'),
                    ),
                    array(
                        'type' => 'param_group',
                        'heading' => __('Tile Grid', 'sublimeplus'),
                        'param_name' => 'tile_grid',
                        'description' => __('Add features with icon, text, and a link.', 'sublimeplus'),
                        'params' => array(
                            array(
                                'type'        => 'textfield',
                                'heading'     => __('Title', 'sublimeplus'),
                                'param_name'  => 'title',
                                'description' => __('Title of the package.', 'sublimeplus'),
                                'value'       => '',
                                'admin_label' => true,
                            ),
                            array(
                                'type'        => 'colorpicker',
                                'heading'     => __('Badge Background', 'sublimeplus'),
                                'param_name'  => 'background',
                                'description' => __('Badge background color', 'sublimeplus'),
                                'value'       => '#E35143',
                                'edit_field_class' => 'vc_col-sm-6 vc_column',
                            ),
                            array(
                                'type'        => 'colorpicker',
                                'heading'     => __('Badge Text Color', 'sublimeplus'),
                                'param_name'  => 'textcolor',
                                'description' => __('Badge Text color', 'sublimeplus'),
                                'value'       => '#FFF', 'edit_field_class' => 'vc_col-sm-6 vc_column',
                            ),
                            array(
                                'type'        => 'textfield',
                                'heading'     => __('Discount', 'sublimeplus'),
                                'param_name'  => 'discount',
                                'description' => __('Discount offered on the package.', 'sublimeplus'),
                                'value'       => '20% off', 'edit_field_class' => 'vc_col-sm-6 vc_column',
                            ),
                            array(
                                'type' => 'autocomplete',
                                'heading' => 'Select SVG',
                                'param_name' => 'svg_url',
                                'description' => 'Select an SVG file from the list.', 'edit_field_class' => 'vc_col-sm-6 vc_column',
                                'settings' => array(
                                    'values' => get_svg_files_from_directory(),
                                    'min_length' => 1,
                                    'groups' => true,
                                    'unique_values' => true,
                                    'display_inline' => true,
                                    'delay' => 500,
                                    'auto_focus' => true,
                                    'sortable' => false,
                                    'max_items' => 1  // Ensure only one item can be selected
                                )
                            ),
                            array(
                                'type'        => 'textfield',
                                'heading'     => __('Link URL', 'sublimeplus'),
                                'param_name'  => 'link',
                                'description' => __('Link to the package details.', 'sublimeplus'),
                                'value'       => '',
                            ),
                          
                            
                           
                        )
                    ),
                    


                )
            ));
        }

        function vc_sublime_packageTile_html($atts) {
            $atts = shortcode_atts(array(
                'tile_grid' => '',
            ), $atts);

            $tiles = vc_param_group_parse_atts($atts['tile_grid']);
            $output = '<div class="education-grid">';


            // <a href="{$link}" class="education-item">                
            // <span id="{$tile_id}" class="education-discount" style="background: {$background} !important; color: {$textcolor} !important;">{$discount}</span>
            // <img src="{$image_src}" alt="{$title}">
            // <h3>{$title}</h3>
            // </a>
            
            foreach ($tiles as $tile) {
             
                $tile_id = "package-tile-" . rand();
                $background = $tile['background'];
                $textcolor = $tile['textcolor'];
                $img_url = $tile['svg_url']; 
                $img_url =   get_site_url() . '/img/svg/'. $img_url;
                $title = $tile['title'];
                $discount = $tile['discount'];
                $link = $tile['link'];


                $output .= "<style>
                #{$tile_id} .education-discount:before {
                    border-left: .75rem solid $background !important;
                }
                 </style>";

                $output .= "<a id='{$tile_id}' href='{$link}' class='education-item'>";
                $output .= "<span class='education-discount' style='background: {$background} !important; color: {$textcolor} !important;'>{$discount}</span>";
                $output .= "<img src='{$img_url}' alt='{$title}'>";
                $output .= "<h3>{$title}</h3>";
                $output .= "</a>";
            }

            $output .= '</div>';

            return $output;
        }
    }
    
    new VCSublimePackageTile();
}
?>
